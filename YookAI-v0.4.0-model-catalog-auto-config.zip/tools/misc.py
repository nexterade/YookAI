"""Miscellaneous file/folder utilities for the YookAI CLI."""
from __future__ import annotations
import hashlib, html, os, re, shutil, sqlite3, subprocess, textwrap, zipfile, sys, unicodedata
from datetime import datetime
from pathlib import Path
from tools.terminal import clear_screen

SKIP_DIRS = {'.git', '.venv', '__pycache__', 'node_modules', '.pytest_cache'}

class _MenuColor:
    """TTY-aware palette for the Miscellaneous terminal menu."""
    enabled = bool(getattr(sys.stdout, "isatty", lambda: False)()) and not bool(os.environ.get("NO_COLOR")) and os.environ.get("TERM") != "dumb"
    RESET = "\033[0m"; CYAN = "\033[36m"; BLUE = "\033[34m"; DIM = "\033[2m"; GREEN = "\033[32m"; YELLOW = "\033[33m"
    @classmethod
    def paint(cls, value: str, color: str) -> str:
        return f"{color}{value}{cls.RESET}" if cls.enabled else value


def _files(root: Path):
    root = Path(root).resolve()
    for base, dirs, names in os.walk(root, followlinks=False):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not (Path(base)/d).is_symlink()]
        for name in names:
            p = Path(base)/name
            if not p.is_symlink() and p.is_file(): yield p

def file_hash(path: Path, algorithm='sha256') -> str:
    h = hashlib.new(algorithm)
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def tree_report(root: Path) -> tuple[list[str], list[str]]:
    root = Path(root).resolve(); lines=[]; files=list(_files(root)); known={p.relative_to(root).as_posix() for p in files}
    pyfiles=[p for p in files if p.suffix=='.py']; imported=set()
    for p in pyfiles:
        try: text=p.read_text(encoding='utf-8')
        except (UnicodeError,OSError): continue
        for mod in re.findall(r'^\s*(?:from|import)\s+([\w.]+)', text, re.M):
            imported.add(mod.replace('.', '/')+'.py')
    for p in sorted(root.rglob('*')):
        if any(part in SKIP_DIRS for part in p.relative_to(root).parts) or p.is_symlink(): continue
        rel=p.relative_to(root).as_posix(); lines.append(('📁 ' if p.is_dir() else '📄 ')+rel)
    orphan=[p.relative_to(root).as_posix() for p in pyfiles if p.name!='__init__.py' and p.relative_to(root).as_posix() not in imported and p.name not in {'server.py'}]
    return lines, sorted(orphan)

def ghost_grep(root: Path, pattern: str, *, regex=False, limit=300) -> list[str]:
    rx=re.compile(pattern if regex else re.escape(pattern), re.I); out=[]
    for p in _files(Path(root)):
        try:
            with p.open('r',encoding='utf-8') as f:
                for n,line in enumerate(f,1):
                    if rx.search(line):
                        out.append(f'{p.relative_to(root)}:{n}: {line.rstrip()[:300]}')
                        if len(out)>=limit: return out
        except (UnicodeError,OSError): continue
    return out

def make_backup(root: Path, backup_dir: Path, keep=5) -> Path:
    root=Path(root).resolve(); backup_dir=Path(backup_dir).resolve(); backup_dir.mkdir(parents=True,exist_ok=True)
    target=backup_dir/f"project-{datetime.now():%Y%m%d-%H%M%S-%f}.zip"
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for p in _files(root):
            if backup_dir==p.parent or backup_dir in p.parents: continue
            z.write(p,p.relative_to(root))
    archives=sorted(backup_dir.glob('project-*.zip'),key=lambda p:p.stat().st_mtime,reverse=True)
    for old in archives[max(1,keep):]: old.unlink(missing_ok=True)
    return target

def _validate_sync_dirs(source: Path, dest: Path) -> tuple[Path,Path]:
    source=Path(source).expanduser().resolve(); dest=Path(dest).expanduser().resolve()
    if not source.is_dir() or not dest.is_dir(): raise NotADirectoryError('Source dan destination harus folder yang sudah ada.')
    if source == dest or source in dest.parents or dest in source.parents:
        raise ValueError('Source dan destination tidak boleh sama atau saling berada di dalam folder lain.')
    return source,dest

def sync_diff(source: Path, dest: Path) -> dict[str,list[Path]]:
    source,dest=_validate_sync_dirs(source,dest); result={'new':[],'changed':[],'same':[]}
    for p in _files(source):
        rel=p.relative_to(source); q=dest/rel
        if not q.exists(): result['new'].append(rel)
        elif q.is_file() and not q.is_symlink() and file_hash(p)==file_hash(q): result['same'].append(rel)
        else: result['changed'].append(rel)
    return result

def sync_copy(source: Path, dest: Path, *, overwrite=False) -> int:
    source,dest=_validate_sync_dirs(source,dest); count=0
    for p in _files(source):
        q=dest/p.relative_to(source)
        if q.exists() and not overwrite: continue
        q.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,q); count+=1
    return count

def remote_copy(local: Path, remote: str, *, rclone='rclone') -> subprocess.CompletedProcess:
    local=Path(local).expanduser().resolve()
    if not local.is_dir(): raise NotADirectoryError('Local path harus folder yang sudah ada.')
    if not shutil.which(rclone): raise FileNotFoundError('rclone tidak ditemukan; install rclone dahulu.')
    if not remote.strip() or remote.startswith('-'): raise ValueError('Remote rclone tidak valid.')
    return subprocess.run([rclone,'copy',str(Path(local).resolve()),remote],capture_output=True,text=True,check=False)

def export_colornote(db_path: Path, out_dir: Path) -> list[Path]:
    """Export text-like SQLite tables; adapts to common ColorNote schemas."""
    db_path=Path(db_path).resolve(); out_dir=Path(out_dir).resolve(); out_dir.mkdir(parents=True,exist_ok=True)
    conn=sqlite3.connect(f'file:{db_path}?mode=ro',uri=True); exports=[]; notes=[]
    try:
        tables=[r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        for table in tables:
            cols=[r[1] for r in conn.execute(f'PRAGMA table_info("{table.replace(chr(34), chr(34)*2)}")')]
            textcols=[c for c in cols if any(k in c.lower() for k in ('content','text','title','note','body'))]
            if not textcols: continue
            quoted='"'+table.replace('"','""')+'"'; qcols=','.join('"'+c.replace('"','""')+'"' for c in textcols)
            for row in conn.execute(f'SELECT {qcols} FROM {quoted}'):
                vals=[str(v) for v in row if v not in (None,'')]
                if vals: notes.append('\n'.join(vals))
    finally: conn.close()
    md=out_dir/'colornote-export.md'; md.write_text('# ColorNote Export\n\n'+'\n\n---\n\n'.join(notes),encoding='utf-8')
    page='<!doctype html><meta charset="utf-8"><title>ColorNote Export</title><h1>ColorNote Export</h1>'+''.join('<article><pre>'+html.escape(n)+'</pre></article>' for n in notes)
    hp=out_dir/'colornote-export.html'; hp.write_text(page,encoding='utf-8'); return [md,hp]

def _display_width(value: str) -> int:
    return sum(2 if unicodedata.east_asian_width(ch) in {"W", "F"} else 1 for ch in value)

def _tail_terminal(value: str, width: int) -> str:
    chars = []; used = 0
    for char in reversed(str(value)):
        char_width = 2 if unicodedata.east_asian_width(char) in {"W", "F"} else 1
        if used + char_width > max(0, width):
            break
        chars.append(char); used += char_width
    return "".join(reversed(chars)) + " " * max(0, width - used)

def _fit_terminal(value: str, width: int) -> str:
    out = ""; used = 0
    for char in str(value):
        char_width = 2 if unicodedata.east_asian_width(char) in {"W", "F"} else 1
        if used + char_width > max(0, width):
            break
        out += char; used += char_width
    return out + " " * max(0, width - used)

def _menu_width(minimum=24, maximum=76):
    try: columns=shutil.get_terminal_size((minimum+2,24)).columns
    except OSError: columns=minimum+2
    return max(minimum,min(maximum,columns-2))

def _run_semut_tool(module_name: str) -> None:
    """Delegate utility execution through Semut's stable integration boundary."""
    from semut_suite.adapter import run_tool
    run_tool(module_name)


def _pause(): input('\nEnter untuk kembali...')
def miscellaneous(root: Path|None=None):
    from semut_suite.core.storage import location_label
    root=Path(root or Path.cwd()).resolve()
    items=[('🌳','Tree Printer','Scan dependency tree + deteksi orphan file'),('👁','Ghost Grep','Smart search pattern di project (grep pintar)'),('🔐','File Hasher','Hash file + verifikasi integritas backup'),('💾','Backup Rotator','Backup pintar + ZIP arsip dengan rotation'),('🔄','Sync Helper','Sync 2 folder dengan hash-based diff'),('🌐','Sync Remote','Sync folder lokal dengan remote rclone'),('📝','ColorNote Exporter','Export note ColorNote (SQLite) ke Markdown + HTML')]
    while True:
        clear_screen()
        width=_menu_width(); inner=width-4
        print(_MenuColor.paint('\n┌'+'─'*(width-2)+'┐', _MenuColor.CYAN))
        def row(value: str, color: str = ""):
            print(_MenuColor.paint("│ " + _fit_terminal(value, inner) + " │", color) if color else "│ " + _fit_terminal(value, inner) + " │")
        row("📁 FILE & FOLDER MANAGEMENT", _MenuColor.CYAN + "\033[1m")
        output_root, is_shared = location_label()
        storage_state = "Shared: verified writable" if is_shared else "Private fallback: shared unavailable"
        row("Project: " + _tail_terminal(str(root), max(1, inner - 9)), _MenuColor.DIM)
        row("Output:  " + _tail_terminal(str(output_root), max(1, inner - 9)), _MenuColor.DIM)
        row("Status:  " + storage_state, _MenuColor.GREEN if is_shared else _MenuColor.YELLOW)
        print(_MenuColor.paint('├'+'─'*(width-2)+'┤', _MenuColor.DIM))
        for i,(ico,name,desc) in enumerate(items,1):
            title=f'[{i}] {ico}  {name}'
            # Keep emoji and labels on a stable visual column, accounting for wide glyphs.
            row(title, _MenuColor.GREEN)
            for line in textwrap.wrap(desc, width=max(8, inner-4)) or ['']:
                row("    " + line, _MenuColor.DIM)
        print(_MenuColor.paint('├'+'─'*(width-2)+'┤', _MenuColor.DIM))
        row('[Q] Back', _MenuColor.YELLOW)
        print(_MenuColor.paint('└'+'─'*(width-2)+'┘', _MenuColor.CYAN))
        c=input('Choose: ').strip().lower()
        if c=='q': return
        tool_modules = {
            '1': 'tree_printer',
            '2': 'ghost_grep',
            '3': 'file_hasher',
            '4': 'backup_rotator',
            '5': 'sync_helper',
            '6': 'sync_remote',
            '7': 'color_note_exporter',
        }
        if c in tool_modules:
            try:
                _run_semut_tool(tool_modules[c])
            except (ImportError, RuntimeError, OSError, ValueError) as e:
                print(_MenuColor.paint(f"Tool gagal dijalankan: {e}", _MenuColor.YELLOW))
        else:
            print(_MenuColor.paint("Pilihan tidak dikenal. Masukkan 1-7 atau Q.", _MenuColor.YELLOW))
        _pause()

if __name__=='__main__': miscellaneous()
