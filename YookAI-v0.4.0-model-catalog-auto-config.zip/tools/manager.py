"""Interactive, safety-conscious manager for YookAI's ~/.yookai data."""
from __future__ import annotations
import os
import shlex
import shutil
import subprocess
import sys
import textwrap
import unicodedata
import zipfile
from datetime import datetime
from pathlib import Path
from core import paths

class _Color:
    """TTY-aware ANSI colors for readable, low-noise terminal output."""
    enabled = bool(getattr(sys.stdout, "isatty", lambda: False)()) and not bool(os.environ.get("NO_COLOR")) and os.environ.get("TERM") != "dumb"
    RESET = "\033[0m"
    CYAN = "\033[36m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    MAGENTA = "\033[35m"
    DIM = "\033[2m"
    BOLD = "\033[1m"

    @classmethod
    def paint(cls, value: str, color: str) -> str:
        return f"{color}{value}{cls.RESET}" if cls.enabled else value


AREAS = {
    "config": paths.CONFIG_DIR,
    "sessions": paths.SESSIONS_DIR,
    "prompts": paths.PROMPTS_DIR,
    "cache": paths.CACHE_DIR,
    "memory": paths.MEMORY_DIR,
    "attachments": paths.ATTACHMENTS_DIR,
    "workspace": paths.WORKSPACE_DIR,
}


def _inside_root(path: Path, root: Path | None = None) -> bool:
    root = Path(root or paths.ROOT).resolve()
    try:
        Path(path).resolve().relative_to(root)
        return True
    except (ValueError, OSError):
        return False


def directory_size(path: Path) -> int:
    """Return regular-file bytes without following symlinks."""
    path = Path(path)
    if path.is_symlink() or not path.exists():
        return 0
    if path.is_file():
        try:
            return path.stat().st_size
        except OSError:
            return 0
    total = 0
    for item in path.rglob("*"):
        if item.is_symlink() or not item.is_file():
            continue
        try:
            total += item.stat().st_size
        except OSError:
            continue
    return total


def _human_size(value: int) -> str:
    size = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


def overview() -> dict[str, int]:
    return {name: directory_size(path) for name, path in AREAS.items()}


def backup(root: Path | None = None, backup_dir: Path | None = None) -> Path:
    root = Path(root or paths.ROOT)
    if not root.exists():
        raise FileNotFoundError(f"YookAI data directory not found: {root}")
    backup_dir = Path(backup_dir or (root / "backups"))
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    target = backup_dir / f"yookai-backup-{stamp}.zip"
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for item in root.rglob("*"):
            if item.is_symlink() or not item.is_file() or backup_dir in item.parents:
                continue
            archive.write(item, item.relative_to(root))
    return target


def clear_area(name: str, *, root: Path | None = None) -> int:
    """Delete contents of a known data area; never delete its directory or follow symlinks."""
    if name not in AREAS:
        raise ValueError("Unknown data area")
    root = Path(root or paths.ROOT)
    area = (root / AREAS[name].relative_to(paths.ROOT)).resolve()
    if not _inside_root(area, root):
        raise ValueError("Refusing to operate outside YookAI data directory")
    if not area.exists() or area.is_symlink():
        return 0
    removed = 0
    for item in list(area.iterdir()):
        if item.is_symlink() or item.is_file():
            try:
                item.unlink()
                removed += 1
            except OSError:
                continue
        elif item.is_dir():
            removed += sum(1 for p in item.rglob("*") if p.is_file() and not p.is_symlink())
            shutil.rmtree(item)
    return removed


def _display_width(value: str) -> int:
    return sum(2 if unicodedata.east_asian_width(ch) in {"W", "F"} else 1 for ch in value)

def _tail_terminal(value: str, width: int) -> str:
    chars = []; used = 0
    for char in reversed(str(value)):
        char_width = 2 if unicodedata.east_asian_width(char) in {"W", "F"} else 1
        if used + char_width > max(0, width):
            break
        chars.append(char); used += char_width
    return "".join(reversed(chars)) + " " * max(0, width - used)

def _fit_terminal(value: str, width: int) -> str:
    out = ""; used = 0
    for char in str(value):
        char_width = 2 if unicodedata.east_asian_width(char) in {"W", "F"} else 1
        if used + char_width > max(0, width):
            break
        out += char; used += char_width
    return out + " " * max(0, width - used)

def _term_width(minimum: int = 24, maximum: int = 76) -> int:
    """Fit panels to the available terminal columns, including narrow phones."""
    try:
        columns = shutil.get_terminal_size((minimum + 2, 24)).columns
    except OSError:
        columns = minimum + 2
    return max(20, min(maximum, columns - 2))


def _panel(title: str, width: int) -> None:
    inner = max(1, width - 4)
    label = f" {title} "[:inner]
    print(_Color.paint("┌" + label + "─" * max(0, width - len(label) - 2) + "┐", _Color.CYAN))


def _browse(root: Path) -> None:
    current = root
    while True:
        if not _inside_root(current, root):
            print("Lokasi di luar .yookai ditolak.")
            current = root
        width = _term_width()
        print()
        _panel("📁 BROWSER", width)
        path_width = max(1, width - 9)
        print("│ Path: " + _tail_terminal(str(current), path_width) + "│")
        print(_Color.paint("├" + "─" * (width - 2) + "┤", _Color.DIM))
        entries = sorted(current.iterdir(), key=lambda p: (not (p.is_dir() and not p.is_symlink()), p.name.lower())) if current.exists() else []
        if not entries:
            print("│ " + _fit_terminal("(folder kosong)", width - 4) + "│")
        for i, item in enumerate(entries, 1):
            kind = "LINK" if item.is_symlink() else ("DIR " if item.is_dir() else "FILE")
            size = "—" if kind in {"DIR ", "LINK"} else _human_size(directory_size(item))
            label = f"{i:>2}. [{kind}] {item.name}"
            suffix = f"  {size}"
            available = max(1, width - len(suffix) - 5)
            for line_no, line in enumerate(textwrap.wrap(label, width=available) or [label]):
                tail = suffix if line_no == 0 else ""
                tail_width = max(0, width - available - len(suffix) - 4)
                shown = "│ " + _fit_terminal(line, available) + _fit_terminal(tail, len(suffix)) + " " * tail_width + " │"
                if line_no == 0:
                    shown = _Color.paint(shown, _Color.CYAN if kind == "DIR " else (_Color.YELLOW if kind == "LINK" else _Color.GREEN))
                print(shown)
        print(_Color.paint("├" + "─" * (width - 2) + "┤", _Color.DIM))
        hint = "[U] Up  [E] Edit  [#] Open/preview  [Q] Back"
        for line in textwrap.wrap(hint, width=width - 4):
            print(f"│ {line:<{width - 4}} │")
        print(_Color.paint("└" + "─" * (width - 2) + "┘", _Color.CYAN))
        choice = input("Select: ").strip().lower()
        if choice == "q":
            return
        if choice == "u":
            if current != root:
                current = current.parent
            continue
        if choice == "e":
            raw = input("Nomor file atau nama/path relatif: ").strip()
            if raw.isdigit() and 1 <= int(raw) <= len(entries):
                candidate_raw = entries[int(raw) - 1]
            else:
                relative = Path(raw)
                if not raw or relative.is_absolute():
                    print("Masukkan nomor file atau path relatif di dalam .yookai.")
                    continue
                candidate_raw = current / relative
            if candidate_raw.is_symlink():
                print("Symlink tidak diedit demi keamanan.")
                continue
            candidate = candidate_raw.resolve()
            if not _inside_root(candidate, root) or not candidate.is_file():
                print("File tidak valid / di luar .yookai. Gunakan nomor atau nama file yang tampil.")
                continue
            if candidate.stat().st_size > 2_000_000:
                print("File terlalu besar untuk editor teks manager.")
                continue
            editor = os.environ.get("EDITOR") or shutil.which("nano") or shutil.which("vi")
            if not editor:
                print("Editor tidak ditemukan. Set EDITOR atau install nano.")
                continue
            print(f"Membuka editor: {candidate.name}")
            result = subprocess.call(shlex.split(editor) + [str(candidate)])
            print("Editor ditutup; perubahan tersimpan jika editor menyimpannya." if result == 0 else f"Editor selesai dengan kode {result}.")
            continue
        if choice.isdigit() and 1 <= int(choice) <= len(entries):
            selected = entries[int(choice)-1]
            if selected.is_symlink():
                print("Symlink tidak dibuka demi keamanan.")
            elif selected.is_dir() and _inside_root(selected, root):
                current = selected
            elif selected.is_file() and selected.stat().st_size <= 256_000:
                print(f"\n--- Preview: {selected.name} (read-only) ---")
                try:
                    content = selected.read_text(encoding="utf-8")[:12000]
                    for line in content.splitlines()[:300]:
                        print(textwrap.shorten(line, width=width, placeholder="…"))
                except (UnicodeError, OSError):
                    print("Bukan file teks UTF-8 yang dapat ditampilkan.")
                input("\nEnter untuk lanjut...")
            else:
                print("Preview hanya mendukung file reguler di bawah 256 KB.")
        else:
            print("Pilihan tidak dikenal. Masukkan nomor yang tampil, U, E, atau Q.")


def manager(root: Path | None = None) -> None:
    root = Path(root or paths.ROOT)
    root.mkdir(parents=True, exist_ok=True)
    while True:
        width = _term_width()
        data = overview()
        total = sum(data.values())
        print()
        _panel(_Color.paint("✦ YookAI  /  DATA MANAGER", _Color.BOLD + _Color.CYAN), width)
        loc_width = max(1, width - 13)
        print("│ Location: " + _tail_terminal(str(root), loc_width) + "│")
        summary = f"Total: {_human_size(total)}  Areas: {len(AREAS)}"
        print(_Color.paint("│ " + _fit_terminal(summary, width - 4) + " │", _Color.MAGENTA + _Color.BOLD))
        print(_Color.paint("├" + "─" * (width - 2) + "┤", _Color.DIM))
        bar_width = max(5, min(12, width - 45))
        for i, (name, size) in enumerate(data.items(), 1):
            ratio = (size / total) if total else 0
            filled = round(ratio * bar_width)
            bar = "█" * filled + "░" * (bar_width - filled)
            label = f"{i:>2}. {name.title():<12} {_human_size(size):>8} {bar} {ratio:>3.0%}"
            print(_Color.paint("│ " + _fit_terminal(label, width - 4) + " │", _Color.GREEN if ratio < .75 else _Color.YELLOW))
        print(_Color.paint("├" + "─" * (width - 2) + "┤", _Color.DIM))
        actions = ["[B] Backup data", "[V] Browse / view / edit", "[C] Clear cache", "[D] Clear data", "[Q] Back"]
        for action in actions:
            tone = _Color.GREEN if action.startswith("[B]") else (_Color.RED if action.startswith("[D]") else (_Color.YELLOW if action.startswith("[C]") else _Color.CYAN))
            print(_Color.paint("│ " + _fit_terminal(action, width - 4) + " │", tone))
        print(_Color.paint("└" + "─" * (width - 2) + "┘", _Color.CYAN))
        choice = input("Choose: ").strip().lower()
        if choice == "q":
            return
        if choice == "b":
            try:
                path = backup(root)
                print(_Color.paint(f"\n[OK] Backup created: {path}", _Color.GREEN))
            except OSError as exc:
                print(_Color.paint(f"\n[ERROR] Backup gagal: {exc}", _Color.RED))
        elif choice == "v":
            _browse(root)
        elif choice.isdigit() and 1 <= int(choice) <= len(AREAS):
            area_name = list(AREAS)[int(choice) - 1]
            area = root / AREAS[area_name].relative_to(paths.ROOT)
            if area.is_symlink():
                print("Symlink tidak dibuka demi keamanan.")
            else:
                area.mkdir(parents=True, exist_ok=True)
                _browse(area)
        elif choice == "c":
            print("\n[INFO] Cache akan dihapus; sesi, konfigurasi, dan memory tetap disimpan.")
            if input("Ketik CLEAR CACHE untuk konfirmasi: ").strip() == "CLEAR CACHE":
                print(f"[OK] Cache items removed: {clear_area('cache', root=root)}")
            else:
                print("[CANCELLED] Tidak ada data yang dihapus.")
        elif choice == "d":
            names = list(AREAS)
            print("\nPilih data yang akan dihapus:")
            for i, name in enumerate(names, 1):
                print(f"  [{i}] {name.title()}")
            print("  [A] Semua data (kecuali backup)")
            selected = input("Pilihan (comma-separated): ").strip().lower()
            chosen = names if selected == "a" else [names[int(x)-1] for x in selected.split(",") if x.strip().isdigit() and 1 <= int(x.strip()) <= len(names)]
            if not chosen:
                print("[WARN] Tidak ada pilihan valid.")
                continue
            print("[WARN] Tindakan ini menghapus data yang dipilih secara permanen.")
            if input("Ketik DELETE untuk konfirmasi: ").strip() != "DELETE":
                print("[CANCELLED] Tidak ada data yang dihapus.")
                continue
            if input("Buat backup terbaru sebelum menghapus? [Y/n]: ").strip().lower() != "n":
                try:
                    print(f"[OK] Backup: {backup(root)}")
                except OSError as exc:
                    print(f"[ERROR] Backup gagal ({exc}); penghapusan dibatalkan.")
                    continue
            for name in chosen:
                print(f"[OK] {name}: removed {clear_area(name, root=root)} items")
        else:
            print("[WARN] Pilihan tidak dikenal.")


if __name__ == "__main__":
    manager()
