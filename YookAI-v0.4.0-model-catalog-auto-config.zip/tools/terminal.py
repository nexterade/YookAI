"""Small terminal presentation helpers shared by interactive YookAI menus."""
from __future__ import annotations

import os
import sys


def clear_screen(*, stream=None, force: bool = False) -> bool:
    """Clear the visible screen and, where supported, terminal scrollback.

    No escape sequences are emitted for pipes, redirected output, or dumb
    terminals unless ``force`` is explicitly requested. Returns whether a
    clear sequence was written.
    """
    stream = stream or sys.stdout
    is_tty = bool(getattr(stream, "isatty", lambda: False)())
    if not force and (not is_tty or os.environ.get("TERM", "") == "dumb"):
        return False
    # CSI 2J clears the screen, CSI 3J clears scrollback on supporting
    # terminals (including Termux), and CSI H homes the cursor.
    stream.write("\033[2J\033[3J\033[H")
    stream.flush()
    return True
