"""Interactive startup configuration for YookAI."""
from __future__ import annotations

import getpass
import os
import sys
import threading
import time
import socket
from urllib.parse import urlparse
from typing import Any

import requests

from core.config import save_config, load_config, ensure_config
from core.latency import get_result, put_result
from providers.openrouter import OpenRouterProvider
from providers.ollama import OllamaProvider
from providers.openai import OpenAIProvider
from providers.anthropic import AnthropicProvider
from providers.gemini import GeminiProvider
from tools.manager import manager as _yookai_manager
from tools.misc import miscellaneous as _miscellaneous
from tools.terminal import clear_screen

PROVIDER_LABELS={"openrouter":"OpenRouter","openai":"OpenAI","anthropic":"Anthropic","gemini":"Google Gemini","ollama":"Ollama API"}
PROVIDER_DEFAULT_MODELS = {"openrouter":"qwen/qwen3.8-27b:free", "gemini":"gemini-3.8-flash", "openai":"gpt-4o-mini", "anthropic":"claude-3-5-haiku-20241022", "ollama":"llama3.2"}

class _Spinner:
    """Animated terminal status that never blocks the work it represents."""
    FRAMES = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")

    def __init__(self, message: str, interval: float = 0.1) -> None:
        self.message = message
        self.interval = interval
        self.enabled = (bool(getattr(sys.stdout, "isatty", lambda: False)())
                        and os.environ.get("TERM", "") != "dumb")
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def __enter__(self):
        if self.enabled:
            self._thread = threading.Thread(target=self._animate, name="yookai-cli-spinner", daemon=True)
            self._thread.start()
        else:
            print(self.message, flush=True)
        return self

    def _animate(self) -> None:
        index = 0
        while not self._stop.is_set():
            frame = self.FRAMES[index % len(self.FRAMES)]
            sys.stdout.write(f"\r\033[2K{frame} {self.message}")
            sys.stdout.flush()
            index += 1
            self._stop.wait(self.interval)

    def __exit__(self, exc_type, exc_value, traceback) -> bool:
        if self._thread is not None:
            self._stop.set()
            self._thread.join(timeout=max(1.0, self.interval * 3))
            sys.stdout.write("\r\033[2K")
            sys.stdout.flush()
        return False


class _Style:
    """Small ANSI palette that safely degrades on non-interactive terminals."""
    enabled = bool(getattr(sys.stdout, "isatty", lambda: False)()) and not bool(__import__("os").environ.get("NO_COLOR"))
    RESET = "\033[0m"; BOLD = "\033[1m"; DIM = "\033[2m"
    CYAN = "\033[36m"; BLUE = "\033[34m"; GREEN = "\033[32m"
    YELLOW = "\033[33m"; MAGENTA = "\033[35m"; RED = "\033[31m"

    @classmethod
    def paint(cls, value: str, color: str) -> str:
        return f"{color}{value}{cls.RESET}" if cls.enabled else value


def _banner() -> None:
    title = _Style.paint("✦ YookAI", _Style.CYAN + _Style.BOLD)
    version = _Style.paint("v0.4.0", _Style.MAGENTA)
    print(f"\n{title}  {version}  {_Style.paint('AI CONTROL CENTER', _Style.DIM)}")
    print(_Style.paint("Configure your assistant before the server starts", _Style.DIM))


def _yes_no(prompt: str, default: bool) -> bool:
    suffix = "Y/n" if default else "y/N"
    value = input(f"{prompt} [{suffix}]: ").strip().lower()
    if not value:
        return default
    return value in {"y", "yes", "1", "true"}


PROVIDER_GUIDES = {
    "openrouter": (
        "OpenRouter [GRATIS*] — tersedia model free dan model berbayar.",
        "Catatan: pilih model bertanda :free untuk free tier; ketersediaan, rate limit, dan kuota dapat berubah.",
        "1. Buka https://openrouter.ai/ dan buat akun / masuk.",
        "2. Buka https://openrouter.ai/keys lalu pilih Create API Key.",
        "3. Salin key dan masukkan di Credentials / URL. Jangan bagikan key.",
        "4. Pilih model dari https://openrouter.ai/models (filter Free bila perlu).",
        "Base URL: https://openrouter.ai/api/v1",
    ),
    "openai": (
        "[BAYAR] OpenAI API — berbayar sesuai penggunaan; ChatGPT Plus tidak termasuk kredit API.",
        "1. Masuk atau daftar di https://platform.openai.com/.",
        "2. Buka https://platform.openai.com/api-keys, buat secret key, lalu salin.",
        "3. Pastikan billing / project API sudah disiapkan di dashboard OpenAI.",
        "4. Masukkan key di Credentials / URL dan pilih model yang tersedia untuk project.",
        "Base URL: https://api.openai.com/v1",
    ),
    "anthropic": (
        "[BAYAR] Anthropic API — akses Claude melalui Console; umumnya memerlukan billing / credits.",
        "1. Masuk atau daftar di https://console.anthropic.com/.",
        "2. Buka bagian API Keys, buat key, lalu salin saat ditampilkan.",
        "3. Siapkan billing / credits bila diminta, lalu masukkan key di konfigurasi.",
        "4. Gunakan ID model Claude yang tersedia untuk akun Anda.",
        "Base URL: https://api.anthropic.com",
    ),
    "gemini": (
        "Google Gemini [GRATIS*] — beberapa model memiliki free tier dengan batas penggunaan.",
        "Catatan: penggunaan di luar kuota atau model tertentu dapat memerlukan billing.",
        "1. Buka https://aistudio.google.com/app/apikey dan masuk dengan akun Google.",
        "2. Pilih Create API key, tentukan project jika diminta, lalu salin key.",
        "3. Masukkan key di Credentials / URL. Gunakan Model > Auto untuk memuat katalog model yang tersedia.",
        "4. Jika Auto tidak dapat memuat katalog, masukkan Model ID aktif secara manual (contoh awal: gemini-3.8-flash).",
        "5. Periksa batas penggunaan dan ketentuan API di Google AI Studio.",
        "Supported Base URL: https://generativelanguage.googleapis.com/v1beta",
        "Endpoint resmi Gemini yang didokumentasikan: v1beta. Custom gateway hanya untuk endpoint yang kompatibel dengan Gemini REST API.",
    ),
    "ollama": (
        "Ollama API [SELF-HOSTED] — YookAI terhubung ke server Ollama melalui HTTP API.",
        "1. Jalankan Ollama di PC/laptop/server dan unduh model: ollama pull llama3.2.",
        "2. Pastikan server bisa dijangkau dari perangkat YookAI; untuk Termux gunakan IP LAN server.",
        "3. Contoh URL: http://192.168.1.10:11434 (localhost hanya jika Ollama berjalan di HP yang sama).",
        "4. Pilih menu Model untuk memuat daftar model yang sudah tersedia di server.",
        "Catatan: API Ollama umumnya tanpa API key. Jangan ekspos port ke internet tanpa autentikasi/proteksi.",
    ),
}

def _show_provider_guide(name: str) -> None:
    guide = PROVIDER_GUIDES.get(name)
    if not guide:
        return
    print("\nQuick setup guide")
    for line in guide:
        print(f"  {line}")

def _provider_menu(config: dict[str, Any]) -> None:
    provider=config.setdefault("provider", {})
    names=[("openrouter","OpenRouter [GRATIS*]"),("ollama","Ollama API [SELF-HOSTED]"),("gemini","Google Gemini [GRATIS*]"),("openai","OpenAI [BAYAR]"),("anthropic","Anthropic [BAYAR]")]
    current=provider.get("default","openrouter")
    print("\nProvider")
    for i,(name,label) in enumerate(names,1): print(f"  {i}) {label}")
    choice=input(f"Select [{next((i for i,(n,_) in enumerate(names,1) if n==current),1)}]: ").strip()
    if choice.isdigit() and 1<=int(choice)<=len(names):
        old_name = current
        new_name = names[int(choice)-1][0]
        chat = config.setdefault("chat", {})
        model_map = chat.setdefault("provider_models", {})
        if chat.get("default_model") and old_name:
            model_map[old_name] = chat["default_model"]
        provider["default"] = new_name
        defaults = PROVIDER_DEFAULT_MODELS
        saved_model = model_map.get(new_name, "")
        compatible = {
            "gemini": lambda model: model.startswith("gemini-"),
            "openai": lambda model: model.startswith(("gpt-", "o1", "o3", "o4", "chatgpt-")),
            "anthropic": lambda model: model.startswith("claude-"),
            "ollama": lambda model: bool(model) and "/" not in model,
            "openrouter": lambda model: bool(model),
        }
        if saved_model and not compatible.get(new_name, lambda model: True)(saved_model):
            saved_model = ""
        chat["default_model"] = saved_model or defaults.get(new_name, "")
        if chat["default_model"]:
            model_map[new_name] = chat["default_model"]
        chat["model_strategy"] = "manual"
        _show_provider_guide(new_name)


def _credentials_menu(config: dict[str, Any]) -> None:
    name=config.setdefault("provider",{}).get("default","openrouter")
    settings=config["provider"].setdefault(name,{})
    label=PROVIDER_LABELS.get(name,name) if 'PROVIDER_LABELS' in globals() else name.title()
    print(f"\n{label} configuration")
    if name != "ollama":
        current=settings.get("api_key","")
        masked=(current[:7]+"…"+current[-4:]) if current else "not configured"
        print(f"API key: {masked}")
        value=getpass.getpass("New API key (Enter keeps current): ").strip()
        if value: settings["api_key"]=value
    else:
        print("API key tidak diperlukan. Masukkan URL server Ollama yang bisa dijangkau dari YookAI.")
    default_url=settings.get("base_url") or ("http://127.0.0.1:11434" if name == "ollama" else "")
    if name == "gemini":
        official = "https://generativelanguage.googleapis.com/v1beta"
        print("\nGemini Base URL options:")
        print(f"  1) Official Gemini REST API — {official}")
        print("  2) Custom Gemini-compatible gateway / proxy")
        current_choice = "1" if not default_url or default_url == official else "2"
        choice = input(f"Select [{current_choice}]: ").strip() or current_choice
        if choice == "1":
            settings["base_url"] = official
        elif choice == "2":
            value = input(f"Custom Base URL [{default_url if default_url != official else ''}]: ").strip()
            settings["base_url"] = value.rstrip("/") if value else (default_url or official)
        else:
            settings["base_url"] = default_url or official
    else:
        value=input(f"Base URL [{default_url}]: ").strip()
        settings["base_url"] = value.rstrip("/") if value else default_url



NETWORK_ENDPOINTS = {
    "OpenRouter": "https://openrouter.ai/api/v1",
    "Google Gemini": "https://generativelanguage.googleapis.com/v1beta",
    "OpenAI": "https://api.openai.com/v1",
    "Anthropic": "https://api.anthropic.com",
}

def _classify_http_status(code: int) -> tuple[str, str]:
    """Describe an unauthenticated base-URL probe without treating 404 as API success."""
    if 200 <= code < 300:
        return "HTTP OK", "HTTP endpoint returned success (API/model access not verified)"
    if 300 <= code < 400:
        return "REDIRECT", "host responded with a redirect"
    if code in {401, 403}:
        return "AUTH REQUIRED", "host and API route responded; credentials or permission required"
    if code == 404:
        return "ROUTE 404", "host reachable, but this URL path has no route; API/model not verified"
    if code == 429:
        return "RATE LIMITED", "host reachable; request was rate-limited"
    if 400 <= code < 500:
        return f"HTTP {code}", "host reachable; request rejected (API/model not verified)"
    if 500 <= code < 600:
        return f"HTTP {code}", "host reachable; remote server reported an error"
    return f"HTTP {code}", "unexpected HTTP response"


def _network_test(config: dict[str, Any]) -> list[dict[str, Any]]:
    """Probe provider base URLs from this device, without sending API credentials."""
    endpoints = dict(NETWORK_ENDPOINTS)
    providers = config.get("provider", {})
    for name, settings in providers.items():
        if not isinstance(settings, dict):
            continue
        custom = settings.get("base_url")
        if custom:
            label = PROVIDER_LABELS.get(name, name.title())
            endpoints[f"{label} (configured)"] = str(custom).rstrip("/")
    results = []
    print("\nNetwork connectivity test (no API key is sent)")
    print("Tests DNS + TCP/HTTPS + an unauthenticated GET to each Base URL.")
    print("A reachable host does not guarantee that its API route, key, or model works.")
    for label, url in endpoints.items():
        started = time.perf_counter()
        dns_ms = None
        try:
            parsed = urlparse(url)
            if parsed.scheme not in {"http", "https"} or not parsed.hostname:
                raise ValueError("Invalid HTTP(S) URL")
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
            dns_started = time.perf_counter()
            socket.getaddrinfo(parsed.hostname, port, type=socket.SOCK_STREAM)
            dns_ms = round((time.perf_counter() - dns_started) * 1000)
            response = requests.get(url, timeout=(4, 6), allow_redirects=True)
            elapsed = round((time.perf_counter() - started) * 1000)
            status, detail = _classify_http_status(response.status_code)
            host_reachable = True
            http_code = response.status_code
        except socket.gaierror:
            elapsed = round((time.perf_counter() - started) * 1000)
            host_reachable, status, detail, http_code = False, "DNS FAILED", "domain could not be resolved", None
        except requests.exceptions.SSLError:
            elapsed = round((time.perf_counter() - started) * 1000)
            host_reachable, status, detail, http_code = False, "TLS FAILED", "secure connection failed", None
        except requests.exceptions.ConnectTimeout:
            elapsed = round((time.perf_counter() - started) * 1000)
            host_reachable, status, detail, http_code = False, "TIMEOUT", "connection timed out", None
        except requests.exceptions.ReadTimeout:
            elapsed = round((time.perf_counter() - started) * 1000)
            host_reachable, status, detail, http_code = False, "READ TIMEOUT", "server did not respond in time", None
        except requests.exceptions.ConnectionError:
            elapsed = round((time.perf_counter() - started) * 1000)
            host_reachable, status, detail, http_code = False, "CONNECT FAILED", "connection refused or network unavailable", None
        except Exception as exc:
            elapsed = round((time.perf_counter() - started) * 1000)
            host_reachable, status, detail, http_code = False, "ERROR", str(exc), None
        result = {
            "name": label, "url": url, "reachable": host_reachable,
            "host_reachable": host_reachable, "status": status,
            "http_status": http_code, "dns_ms": dns_ms,
            "latency_ms": elapsed, "detail": detail,
        }
        results.append(result)
        mark = "HOST OK" if host_reachable else "FAIL"
        dns_text = f"DNS {dns_ms} ms" if dns_ms is not None else "DNS n/a"
        print(f"[{mark}] {label}")
        print(f"    Result: {status}  |  Total: {elapsed} ms  |  {dns_text}")
        print(f"    URL: {url}")
        print(f"    Note: {detail}")
    return results


def _benchmark(config: dict[str, Any], force: bool = False) -> dict[str, Any] | None:
    settings = config.get("provider", {}).get("openrouter", {})
    key = settings.get("api_key", "")
    if not key:
        print("\nCannot benchmark: OpenRouter API key is not configured.")
        return None
    base_url = settings.get("base_url", "https://openrouter.ai/api/v1")
    if not force:
        cached = get_result("openrouter", base_url)
        if cached:
            best = cached.get("best_model")
            print(f"\nUsing latency cache: {best} ({cached.get('best_ttft_ms')} ms TTFT)")
            chat = config.setdefault("chat", {})
            chat["default_model"] = best
            chat.setdefault("provider_models", {})["openrouter"] = best
            return cached
    provider = OpenRouterProvider(key, base_url)
    try:
        with _Spinner("Checking free OpenRouter models (streaming probes)..."):
            models = provider.list_models()
            results = provider.benchmark_models(models, max_candidates=5, timeout=(4, 8))
    except Exception as exc:
        print(f"Benchmark failed: {exc}")
        return None
    valid = [r for r in results if r.get("ttft_ms") is not None]
    for result in results:
        if result.get("ttft_ms") is not None:
            print(f"  {result['name']}: {result['ttft_ms']} ms")
        else:
            print(f"  {result['name']}: failed ({result.get('error', 'unknown')})")
    if not valid:
        print("No free model completed the latency probe; keeping the current model.")
        return {"results": results}
    best = valid[0]
    chat = config.setdefault("chat", {})
    chat["default_model"] = best["id"]
    chat.setdefault("provider_models", {})["openrouter"] = best["id"]
    config.setdefault("chat", {})["model_strategy"] = "latency-best-free"
    result = {"best_model": best["id"], "best_ttft_ms": best["ttft_ms"], "results": results}
    put_result("openrouter", base_url, result)
    print(f"Selected default: {best['name']} ({best['ttft_ms']} ms TTFT)")
    return result


def _model_menu(config: dict[str, Any]) -> None:
    """Select a provider model from its live catalog in the terminal."""
    provider_name = config.setdefault("provider", {}).get("default", "openrouter")
    chat = config.setdefault("chat", {})
    model_map = chat.setdefault("provider_models", {})
    active_model = model_map.get(provider_name) or chat.get("default_model") or PROVIDER_DEFAULT_MODELS.get(provider_name, "")
    settings = config.setdefault("provider", {}).setdefault(provider_name, {})
    provider_types = {
        "openrouter": OpenRouterProvider,
        "openai": OpenAIProvider,
        "anthropic": AnthropicProvider,
        "gemini": GeminiProvider,
        "ollama": OllamaProvider,
    }
    provider_cls = provider_types.get(provider_name)
    if provider_cls is None:
        print(f"Unsupported provider: {provider_name}")
        return

    kwargs = {"base_url": settings.get("base_url") or ("http://127.0.0.1:11434" if provider_name == "ollama" else None)}
    if provider_name != "ollama":
        kwargs["api_key"] = settings.get("api_key", "")
    kwargs = {key: value for key, value in kwargs.items() if value is not None}
    print(f"\nAvailable {PROVIDER_LABELS.get(provider_name, provider_name)} models")
    try:
        with _Spinner("Loading model catalog..."):
            models = provider_cls(**kwargs).list_models()
        models = [m for m in models if isinstance(m, dict) and m.get("id")]
    except Exception as exc:
        print(f"Could not load model catalog: {exc}")
        models = []

    if provider_name == "gemini":
        models = [m for m in models if m["id"] != "gemini-2.5-flash"]
    if not models:
        print("No model list is available. Check provider credentials / URL / connection, then retry.")
        provider_default = PROVIDER_DEFAULT_MODELS.get(provider_name, "")
        if provider_default and (not active_model or (provider_name == "gemini" and not active_model.startswith("gemini-")) or active_model == "gemini-2.5-flash"):
            chat["default_model"] = provider_default
            model_map[provider_name] = provider_default
            chat["model_strategy"] = "manual"
            print(f"Using {PROVIDER_LABELS.get(provider_name, provider_name)} fallback: {provider_default}")
        else:
            print(f"Keeping current model: {active_model or '(provider default)'}")
        return

    # Keep the CLI usable on providers with large catalogs (notably OpenRouter).
    display_models = models[:50]
    for index, model in enumerate(display_models, 1):
        model_id = str(model["id"])
        label = str(model.get("name") or model_id).replace("\n", " ").strip()
        suffix = f" — {model_id}" if label != model_id else ""
        print(f"  {index:>2}) {label}{suffix}")
    if len(models) > len(display_models):
        print(f"  Showing first {len(display_models)} of {len(models)} models.")
    print("  A) Auto — choose a recommended available model")
    print("  K) Keep current model")
    current_index = next((i for i, m in enumerate(display_models, 1) if m["id"] == active_model), 1)
    choice = input(f"Select model [{current_index}]: ").strip()
    selected = None
    if not choice or choice.upper() == "K":
        selected = active_model if any(m["id"] == active_model for m in models) else None
    elif choice.upper() == "A":
        preferred = {
            "openrouter": ("qwen/qwen3.8-27b:free",),
            "gemini": ("gemini-3.8-flash", "gemini-3.0-flash", "gemini-2.0-flash"),
            "openai": ("gpt-4o-mini", "gpt-4.1-mini"),
            "anthropic": ("claude-3-5-haiku-20241022", "claude-3-haiku-20240307"),
            "ollama": ("llama3.2",),
        }.get(provider_name, ())
        selected = next((m["id"] for candidate in preferred for m in models if m["id"] == candidate), None)
        selected = selected or display_models[0]["id"]
    elif choice.isdigit() and 1 <= int(choice) <= len(display_models):
        selected = display_models[int(choice) - 1]["id"]
    else:
        print("Invalid selection; keeping current model.")
        return

    if selected:
        chat["default_model"] = selected
        model_map[provider_name] = selected
        chat["model_strategy"] = "provider-auto" if choice.upper() == "A" else "manual"
        print(f"Selected {PROVIDER_LABELS.get(provider_name, provider_name)} model: {selected}")
    else:
        print("Current model is not in the loaded catalog; select a model number or A for Auto.")


def _memory_menu(config: dict[str, Any]) -> None:
    memory = config.setdefault("memory", {})
    current = memory.get("mode", "default")
    print(f"\nMemory mode: {current}")
    print("  1) Default memory — shared across chats")
    print("  2) Project-only memory — isolated to this project")
    choice = input("Select [current]: ").strip()
    if choice == "1": memory["mode"] = "default"
    elif choice == "2": memory["mode"] = "project-only"


def _server_menu(config: dict[str, Any]) -> None:
    server = config.setdefault("server", {})
    host = input(f"Host [{server.get('host', '127.0.0.1')}]: ").strip()
    port = input(f"Port [{server.get('port', 8000)}]: ").strip()
    if host: server["host"] = host
    if port:
        try: server["port"] = int(port)
        except ValueError: print("Invalid port; keeping current value.")


def _theme_menu(config: dict[str, Any]) -> None:
    ui = config.setdefault("ui", {})
    value = input(f"Theme dark/light [{ui.get('theme', 'dark')}]: ").strip().lower()
    if value in {"dark", "light"}: ui["theme"] = value


def interactive_config(config: dict[str, Any], *, force: bool = False) -> dict[str, Any] | None:
    """Run the pre-listen setup menu. Returns None when the user cancels."""
    if not sys.stdin.isatty() and not force:
        return config
    # Migrate the old hard-coded DeepSeek R1 default to the new automatic
    # strategy. Existing users keep their config, but future starts select the
    # fastest free model measured from this device.
    chat_config = config.setdefault("chat", {})
    if chat_config.get("default_model") == "deepseek/deepseek-r1" and "model_strategy" not in chat_config:
        chat_config["model_strategy"] = "latency-best-free"

    # Auto mode is intentionally benchmarked once per cache window so the
    # configured default tracks the user's current OpenRouter routing/latency
    # rather than being hard-coded to a particular model.
    if (config.get("provider", {}).get("default", "openrouter") == "openrouter"
            and config.get("chat", {}).get("model_strategy") == "latency-best-free"
            and config.get("provider", {}).get("openrouter", {}).get("api_key")):
        base_url = config.get("provider", {}).get("openrouter", {}).get("base_url", "https://openrouter.ai/api/v1")
        cached = get_result("openrouter", base_url)
        if cached and cached.get("best_model"):
            config.setdefault("chat", {})["default_model"] = cached["best_model"]
            print(f"Latency cache: {cached['best_model']} ({cached.get('best_ttft_ms')} ms TTFT)")
        else:
            _benchmark(config)
    while True:
        clear_screen()
        _banner()
        print(_Style.paint("\nSTARTUP CONFIGURATION", _Style.BLUE + _Style.BOLD))
        print(_Style.paint("Changes are saved before the HTTP server starts.\n", _Style.DIM))
        provider_name=config.get("provider",{}).get("default","openrouter")
        provider=config.get("provider",{}).get(provider_name,{})
        chat=config.get("chat",{}); memory=config.get("memory",{}); server=config.get("server",{})
        key_state="URL required / no API key" if provider_name=="ollama" else ("configured" if provider.get("api_key") else "NOT configured")
        print(_Style.paint("─"*62, _Style.DIM))
        rows = [
            ("1", "Provider", PROVIDER_LABELS.get(provider_name,provider_name)),
            ("2", "Credentials / URL", f"{key_state} / {provider.get('base_url') or ('http://127.0.0.1:11434' if provider_name == 'ollama' else '')}"),
            ("3", "Model", f"{chat.get('default_model','none')} ({chat.get('model_strategy','manual')})"),
            ("4", "Memory", memory.get('mode','default')),
            ("5", "Server", f"{server.get('host','127.0.0.1')}:{server.get('port',8000)}"),
            ("6", "Theme", config.get('ui',{}).get('theme','dark')),
        ]
        for number, label, value in rows:
            print(f"{_Style.paint('['+number+']', _Style.CYAN)} {label:<19}: {_Style.paint(str(value), _Style.GREEN)}")
        print(_Style.paint("[7]", _Style.CYAN) + " Benchmark latency  : OpenRouter free models")
        print(f"{_Style.paint('[8]', _Style.CYAN)} {'Network test':<19}: provider Base URLs")
        print(f"{_Style.paint('[9]', _Style.CYAN)} {'.yookai Manager':<19}: storage / memory / backup")
        print(f"{_Style.paint('[10]', _Style.CYAN)} {'Miscellaneous':<19}: file / folder management")
        print(_Style.paint("[S]", _Style.GREEN + _Style.BOLD) + " Save & start server")
        print(_Style.paint("[Q]", _Style.RED + _Style.BOLD) + " Quit")
        choice=input(_Style.paint("\nChoose an option: ", _Style.YELLOW + _Style.BOLD)).strip().lower()
        if choice=="1": _provider_menu(config)
        elif choice=="2": _credentials_menu(config)
        elif choice=="3": _model_menu(config)
        elif choice=="4": _memory_menu(config)
        elif choice=="5": _server_menu(config)
        elif choice=="6": _theme_menu(config)
        elif choice=="7": _benchmark(config,force=True)
        elif choice=="8": _network_test(config)
        elif choice=="9":
            _yookai_manager()
            try:
                ensure_config()
                config.clear(); config.update(load_config())
            except (OSError, ValueError) as exc:
                print(f"Config reload failed; current in-memory settings retained: {exc}")
        elif choice=="10":
            _miscellaneous()
        elif choice=="s":
            if provider_name!="ollama" and not provider.get("api_key"):
                print(f"Warning: {PROVIDER_LABELS.get(provider_name,provider_name)} API key is not configured; chat requests may fail until it is set.")
            save_config(config); return config
        elif choice=="q": return None
        else: print("Unknown option.")
