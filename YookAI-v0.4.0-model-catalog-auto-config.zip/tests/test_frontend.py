import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TEMPLATES = ROOT / "templates"


class FrontendTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model = (TEMPLATES / "partials" / "model-selector.html").read_text(encoding="utf-8")
        cls.thinking = (TEMPLATES / "partials" / "thinking-block.html").read_text(encoding="utf-8")
        cls.app = (TEMPLATES / "app.js").read_text(encoding="utf-8")
        cls.css = (TEMPLATES / "style.css").read_text(encoding="utf-8")
        cls.api = (TEMPLATES / "api.js").read_text(encoding="utf-8")
        cls.index = (TEMPLATES / "index.html").read_text(encoding="utf-8")
        cls.base = (TEMPLATES / "_shared" / "base.html").read_text(encoding="utf-8")

    def test_model_selector_required_markup(self):
        for value in ('id="model-selector"', 'id="model-dropdown"', 'id="model-search"', 'id="model-list-recommended"'):
            self.assertIn(value, self.model)

    def test_thinking_block_required_markup(self):
        self.assertIn('class="thinking-block"', self.thinking)
        self.assertIn('data-thinking-body', self.thinking)
        self.assertIn('data-thinking-timer', self.thinking)
        self.assertIn('data-thinking-status', self.thinking)
        self.assertIn('aria-live="polite"', (TEMPLATES / 'partials' / 'thinking-block.html').read_text(encoding='utf-8'))

    def test_app_modules(self):
        self.assertRegex(self.app, r"const\s+ModelSelector\s*=")
        self.assertRegex(self.app, r"const\s+ThinkingBlock\s*=")
        self.assertRegex(self.app, r"const\s+RECOMMENDED\s*=")

    def test_css_selectors(self):
        for selector in ('.model-selector', '.model-dropdown', '.thinking-block', '.thinking-summary'):
            self.assertIn(selector, self.css)

    def test_api_list_models(self):
        self.assertIn('listModels', self.api)
        self.assertIn("/api/providers/${encodeURIComponent(provider)}/models", self.api)

    def test_index_extends_shared_base(self):
        self.assertRegex(self.index, r"\{\%\s*extends\s+['_\"]_shared/base\.html['_\"]\s*%\}")


    def test_mobile_sidebar_starts_closed(self):
        init = self.app[self.app.index('async function init()'):]
        self.assertIn("if (isCompactLayout()) {", init)
        self.assertIn("classList.remove('sidebar-open')", init)
        self.assertIn("setAttribute('aria-expanded', 'false')", init)
        self.assertNotIn("state.config.ui?.sidebar_default === 'open'", init)

    def test_start_page_and_refresh_resume_policy(self):
        app = (TEMPLATES / "app.js").read_text(encoding="utf-8")
        self.assertIn("ACTIVE_SESSION_KEY = 'yookai-active-session'", app)
        self.assertIn("SERVER_INSTANCE_KEY = 'yookai-server-instance'", app)
        self.assertIn("const isReload = nav?.type === 'reload'", app)
        self.assertIn("priorServer === serverInstance && isReload", app)
        self.assertIn("updateSidebarActive(null)", app)
        self.assertIn("sessionStorage.removeItem(ACTIVE_SESSION_KEY)", app)

    def test_base_has_anti_fouc_script(self):
        self.assertIn("localStorage.getItem('yookai-theme')", self.base)
        self.assertIn("prefers-color-scheme: dark", self.base)
        self.assertIn("data-theme", self.base)

    def test_402_message_does_not_assume_balance_is_empty(self):
        self.assertIn("Kredit yang tersedia untuk request", self.app)
        self.assertIn("fewer max_tokens|can only afford", self.app)
        self.assertIn("[tautan disembunyikan]", self.app)
        self.assertNotIn("periksa saldo/kredit atau billing akun", self.app)

    def test_markdown_has_unresolved_internal_placeholder_fallback(self):
        markdown = (TEMPLATES / "markdown.js").read_text(encoding="utf-8")
        self.assertIn("[blok kode tidak tersedia]", markdown)
        self.assertNotIn("normalizedText", markdown)


# PR X static checks
class FrontendPolishTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.index = (TEMPLATES / "index.html").read_text(encoding="utf-8")
        cls.base = (TEMPLATES / "_shared" / "base.html").read_text(encoding="utf-8")
        cls.app = (TEMPLATES / "app.js").read_text(encoding="utf-8")
        cls.css = (TEMPLATES / "style.css").read_text(encoding="utf-8")
        cls.model = (TEMPLATES / "partials" / "model-selector.html").read_text(encoding="utf-8")
        cls.thinking = (TEMPLATES / "partials" / "thinking-block.html").read_text(encoding="utf-8")
        cls.api = (TEMPLATES / "api.js").read_text(encoding="utf-8")
        cls.empty = (TEMPLATES / "partials" / "empty-state.html").read_text(encoding="utf-8")

    def test_anti_fouc_and_jinja_comment_configuration_markers(self):
        self.assertIn("localStorage.getItem('yookai-theme')", self.base)
        self.assertIn("prefers-color-scheme: dark", self.base)
        self.assertIn("{% block styles %}", self.base)
        self.assertIn("{% include 'style.css' %}", self.index)

    def test_provider_model_selection_is_provider_scoped(self):
        self.assertIn("function providerModel(provider = state.currentProvider)", self.app)
        self.assertIn("localStorage.getItem(`${MODEL_KEY}:${state.currentProvider}`)", self.app)
        self.assertIn("rememberProviderModel(state.currentProvider,model.id)", self.app)

    def test_settings_saves_model_under_selected_provider(self):
        self.assertIn("config.chat.provider_models[providerName]=selectedModel", self.app)
        self.assertIn("provider_models?.[name]", self.app)

    def test_model_selector_keyboard_nav(self):
        self.assertRegex(self.app, r"handleKeydown\(e\)")
        self.assertIn("ArrowDown", self.app)
        self.assertIn("ArrowUp", self.app)
        self.assertIn("Escape", self.app)

    def test_thinking_timer_and_finalize(self):
        self.assertIn("startTimer(block)", self.app)
        self.assertIn("formatDuration(ms)", self.app)
        self.assertIn("setStatus(block, status)", self.app)
        self.assertIn("'Menulis jawaban'", self.app)
        self.assertIn("'Terhenti karena error'", self.app)
        self.assertIn("this.formatDuration(Date.now() - started)", self.app)
        self.assertIn("setTimeout(() =>", self.app)

    def test_toast_auto_dismiss(self):
        self.assertRegex(self.app, r"setTimeout\(hideToast,\s*2200\)")

    def test_empty_state_variants_are_present_in_frontend(self):
        self.assertIn("session-empty", self.app)
        self.assertIn("model-empty", self.model)
        self.assertIn("error-state", self.app)
        self.assertIn("empty-state", self.empty)

    def test_touch_accessibility_and_reduced_motion_css(self):
        self.assertIn(":focus-visible", self.css)
        self.assertIn("prefers-reduced-motion:reduce", self.css)
        self.assertIn("min-height:44px", self.css)
        self.assertIn("safe-area-inset-bottom", self.css)

    def test_audit_features_markup(self):
        self.assertIn('id="attachment-input"', (TEMPLATES / 'partials' / 'composer.html').read_text(encoding='utf-8'))
        self.assertIn('id="stats-modal"', self.index)
        self.assertIn('id="settings-memory-mode"', self.index)
        self.assertIn('id="sidebar-collapse"', (TEMPLATES / 'partials' / 'sidebar.html').read_text(encoding='utf-8'))
        self.assertIn("uploadAttachment", self.api)
        self.assertIn("getSessionStats", self.api)

    def test_version_meta_present(self):
        self.assertIn('application-version" content="0.3.39"', self.base)
        self.assertIn('v0.3.39', (TEMPLATES / "partials" / "header.html").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()

class V021PolishTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = (TEMPLATES / "app.js").read_text(encoding="utf-8")
        cls.css = (TEMPLATES / "style.css").read_text(encoding="utf-8")
        cls.thinking = (TEMPLATES / "partials" / "thinking-block.html").read_text(encoding="utf-8")
        cls.header = (TEMPLATES / "partials" / "header.html").read_text(encoding="utf-8")
        cls.composer = (TEMPLATES / "partials" / "composer.html").read_text(encoding="utf-8")

    def test_thinking_spinner_is_present_and_starts_before_first_chunk(self):
        self.assertIn('class="thinking-spinner"', self.thinking)
        self.assertIn('let thinking = ThinkingBlock.create(aiRow);', self.app)
        self.assertIn('send-btn.loading::after', self.css)

    def test_ui_icons_use_svg_not_legacy_unicode_glyphs(self):
        for source in (self.header, self.composer):
            self.assertIn('<svg', source)
        for glyph in ('⧉', '✎', '↻', '↗', '☆', '⋯', '☰', '⚙', '＋'):
            self.assertNotIn(glyph, self.app + self.header + self.composer)

    def test_mojibake_repair_exists_at_render_boundary(self):
        self.assertIn('repairMojibake', self.app)
        self.assertIn('repairMojibake(msg.content', self.app)

class FinalMobileRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = (TEMPLATES / "app.js").read_text(encoding="utf-8")
        cls.css = (TEMPLATES / "style.css").read_text(encoding="utf-8")

    def test_assistant_avatar_removed_from_render_markup(self):
        self.assertNotIn('class="ai-avatar"', self.app)
        self.assertIn('.ai-avatar{display:none!important}', self.css)

    def test_stream_completion_releases_composer_before_session_save(self):
        completion = self.app.index("state.messages[aiIndex].completed_at =")
        release = self.app.index("state.isStreaming = false;", completion)
        persist = self.app.index("await saveSession();", completion)
        self.assertLess(release, persist)
        self.assertIn("send.hidden = streaming", self.app)

class ThinkingPersistenceRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = (TEMPLATES / "app.js").read_text(encoding="utf-8")

    def test_completed_thinking_is_not_hidden(self):
        self.assertNotIn("thinking.hidden = true", self.app)
        self.assertNotIn("if (msg.completed_at) block.hidden = true", self.app)

    def test_thinking_is_finalized_on_done_and_stop(self):
        self.assertIn("// Preserve the thinking transcript after completion; only stop its live timer/animation.", self.app)
        self.assertIn("document.querySelectorAll('.thinking-block').forEach((block) => ThinkingBlock.finalize(block, 'stopped'));", self.app)

    def test_thinking_statuses_are_observed_not_fabricated_reasoning(self):
        self.assertIn('Menunggu model', self.app)
        self.assertIn('Menerima data Thinking', self.app)
        self.assertIn('Menulis jawaban', self.app)
        self.assertIn('Terhenti karena error', self.app)
        self.assertIn('Model tidak mengirimkan data Thinking pada respons ini.', self.app)
        self.assertIn('aria-live="polite"', (TEMPLATES / 'partials' / 'thinking-block.html').read_text(encoding='utf-8'))

    def test_reasoning_content_remains_under_thinking_label(self):
        self.assertIn("if (label) label.textContent = 'Thinking';", self.app)
        self.assertIn("body.innerHTML = window.renderMarkdown ? renderMarkdown(body.dataset.raw)", self.app)


class ProviderModelDropdownTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = (TEMPLATES / "app.js").read_text(encoding="utf-8")
        cls.index = (TEMPLATES / "index.html").read_text(encoding="utf-8")

    def test_default_model_setting_uses_select(self):
        self.assertIn('id="settings-default-model"', self.index)
        self.assertIn('Default model<select id="settings-default-model"', self.index)
        self.assertNotIn('Default model<input id="settings-default-model"', self.index)

    def test_dropdown_loads_provider_catalog_and_preserves_saved_model(self):
        self.assertIn('async function loadSettingsModels(providerName, selectedModel=', self.app)
        self.assertIn('client.listModels(providerName)', self.app)
        self.assertIn('if(selectedModel&&!unique.some(m=>m.id===selectedModel))', self.app)
        self.assertIn('loadSettingsModels(name,selected)', self.app)


class V033BlueprintRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = (TEMPLATES / "app.js").read_text(encoding="utf-8")
        cls.index = (TEMPLATES / "index.html").read_text(encoding="utf-8")
        cls.header = (TEMPLATES / "partials" / "header.html").read_text(encoding="utf-8")

    def test_general_settings_has_single_headerless_entry_point(self):
        self.assertNotIn('id="header-settings"', self.header)
        self.assertNotIn("$('header-settings')", self.app)
        self.assertIn('data-brand-action="settings"', self.header)
        self.assertNotIn('id="brand-home"', (TEMPLATES / "partials" / "sidebar.html").read_text(encoding="utf-8"))

    def test_session_model_profile_uses_provider_aware_dropdown(self):
        self.assertIn('<label>Model<select id="model-settings-model"', self.index)
        self.assertIn('async function loadModelProfileModels(provider, selectedModel)', self.app)
        self.assertIn('client.listModels(request)', self.app)
        self.assertIn("applyModelProfileFields(state.currentProvider,e.target.value)", self.app)

    def test_profile_selection_updates_active_provider_and_model(self):
        self.assertIn('state.currentProvider=provider; state.currentModel=selectedModel;', self.app)
        self.assertIn('ModelSelector.currentModelId=selectedModel;', self.app)
        self.assertIn('provider: state.currentProvider, model: state.currentModel', self.app)

    def test_provider_errors_have_specific_user_messages(self):
        self.assertIn('error.status===402', self.app)
        self.assertIn('error.status===429', self.app)

    def test_stream_error_status_is_preserved_for_friendly_message(self):
        self.assertIn("failure.status=Number(chunk.status||chunk.status_code||(match&&match[1])||0)", self.app)
        self.assertIn("const detail=error.status===402", self.app)
