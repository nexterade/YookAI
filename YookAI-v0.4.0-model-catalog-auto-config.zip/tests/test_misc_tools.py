import sqlite3
import tempfile
import unittest
from pathlib import Path
from tools.misc import file_hash, tree_report, ghost_grep, make_backup, sync_diff, sync_copy, export_colornote

class MiscToolsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)/'project'; self.root.mkdir()
    def tearDown(self): self.tmp.cleanup()
    def test_hash_and_grep(self):
        f=self.root/'hello.py'; f.write_text('import os\nneedle here\n')
        self.assertEqual(len(file_hash(f)),64)
        self.assertTrue(any('needle here' in x for x in ghost_grep(self.root,'needle')))
    def test_tree_reports_files_and_possible_orphans(self):
        (self.root/'a.py').write_text('print("a")')
        lines,orphans=tree_report(self.root)
        self.assertTrue(any('a.py' in x for x in lines)); self.assertIn('a.py',orphans)
    def test_backup_rotation(self):
        (self.root/'a.txt').write_text('one'); backups=self.root/'backups'
        first=make_backup(self.root,backups,keep=1)
        (self.root/'a.txt').write_text('two'); second=make_backup(self.root,backups,keep=1)
        self.assertTrue(first.exists() is False); self.assertTrue(second.exists())
    def test_hash_sync_diff_and_copy(self):
        src=self.root/'src'; dst=self.root/'dst'; src.mkdir(); dst.mkdir()
        (src/'new').write_text('new'); (src/'change').write_text('new value'); (dst/'change').write_text('old')
        diff=sync_diff(src,dst); self.assertEqual(len(diff['new']),1); self.assertEqual(len(diff['changed']),1)
        self.assertEqual(sync_copy(src,dst),1); self.assertEqual((dst/'new').read_text(),'new')
        self.assertEqual(sync_copy(src,dst,overwrite=True),2); self.assertEqual((dst/'change').read_text(),'new value')
    def test_sync_rejects_overlapping_directories(self):
        src=self.root/'src'; src.mkdir(); nested=src/'nested'; nested.mkdir()
        with self.assertRaises(ValueError): sync_diff(src,nested)
        with self.assertRaises(NotADirectoryError): sync_diff(src,self.root/'missing')
    def test_colornote_export(self):
        db=self.root/'notes.db'; conn=sqlite3.connect(db)
        conn.execute('CREATE TABLE notes (id INTEGER, title TEXT, content TEXT)')
        conn.execute('INSERT INTO notes VALUES (1, ?, ?)',('Title','<hello>')); conn.commit(); conn.close()
        outputs=export_colornote(db,self.root/'export')
        self.assertEqual(len(outputs),2); self.assertIn('Title',(self.root/'export'/'colornote-export.md').read_text())
        self.assertIn('&lt;hello&gt;',(self.root/'export'/'colornote-export.html').read_text())

if __name__=='__main__': unittest.main()
