import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class SidebarMenuTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sidebar = (ROOT / 'templates/partials/sidebar.html').read_text(encoding='utf-8')
        cls.header = (ROOT / 'templates/partials/header.html').read_text(encoding='utf-8')
        cls.app = (ROOT / 'templates/app.js').read_text(encoding='utf-8')
        cls.css = (ROOT / 'templates/style.css').read_text(encoding='utf-8')

    def test_brand_version_has_accessible_menu_trigger(self):
        self.assertIn('id="brand-home"', self.header)
        self.assertIn('aria-haspopup="menu"', self.sidebar)
        self.assertIn('aria-controls="brand-menu"', self.header)
        self.assertIn('id="brand-menu" role="menu"', self.header)

    def test_brand_menu_actions_are_bound(self):
        self.assertIn('data-brand-action="about"', self.header)
        self.assertIn('data-brand-action="settings"', self.header)
        self.assertIn("$('brand-home')?.addEventListener('click'", self.app)
        self.assertIn("$('brand-menu')?.addEventListener('click'", self.app)

    def test_workspace_menu_actions_are_bound(self):
        self.assertIn('id="workspace-menu-trigger"', self.sidebar)
        self.assertIn('id="workspace-menu" role="menu"', self.sidebar)
        self.assertIn('data-workspace-action="new-chat"', self.sidebar)
        self.assertIn('data-workspace-action="export"', self.sidebar)
        self.assertIn("$('workspace-menu-trigger')?.addEventListener('click'", self.app)
        self.assertIn("$('workspace-menu')?.addEventListener('click'", self.app)

    def test_touch_and_keyboard_support(self):
        self.assertIn('min-height:44px;min-width:44px;touch-action:manipulation', self.css)
        self.assertIn("'ArrowDown','ArrowUp','Home','End'", self.app)
        self.assertIn("if (e.key === 'Escape') { const menuWasOpen", self.app)
        self.assertIn("document.addEventListener('click'", self.app)

    def test_settings_has_single_sidebar_entry_and_no_header_gear(self):
        self.assertEqual(self.header.count('data-brand-action="settings"'), 1)
        self.assertNotIn('id="brand-home"', self.sidebar)
        self.assertNotIn('id="open-settings"', self.sidebar)
        self.assertNotIn('data-workspace-action="settings"', self.sidebar)
        self.assertNotIn('id="settings-toggle"', self.header)


if __name__ == '__main__':
    unittest.main()
