import io
import re
import unittest
from unittest.mock import patch

from semut_suite.ui.spinner import Progress


class ProgressSingleLineTests(unittest.TestCase):
    def test_tty_progress_updates_in_place_without_milestone_lines(self):
        output = io.StringIO()
        output.isatty = lambda: True
        with patch('semut_suite.ui.spinner.sys.stdout', output), \
             patch('semut_suite.ui.spinner._terminal_columns', return_value=48):
            progress = Progress('Hashing files', total=100, width=18)
            progress.__enter__()
            progress.update(25)
            progress.update(70)
            progress.done()
        rendered = output.getvalue()
        self.assertIn('25%', rendered)
        self.assertIn('70%', rendered)
        self.assertIn('100%', rendered)
        self.assertEqual(rendered.count('\n'), 1)
        self.assertIn('\r\033[2K', rendered)

    def test_non_tty_emits_only_final_summary(self):
        output = io.StringIO()
        output.isatty = lambda: False
        with patch('semut_suite.ui.spinner.sys.stdout', output):
            progress = Progress('Hashing files', total=4)
            progress.__enter__()
            progress.update(1)
            progress.update(4)
            progress.done()
        rendered = output.getvalue()
        self.assertEqual(rendered.count('\n'), 1)
        self.assertIn('Hashing files — 4 file', rendered)
        plain = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", rendered)
        self.assertNotIn('[Hashing', plain)

    def test_narrow_terminal_progress_fits_one_line(self):
        output = io.StringIO()
        output.isatty = lambda: True
        with patch('semut_suite.ui.spinner.sys.stdout', output), \
             patch('semut_suite.ui.spinner._terminal_columns', return_value=24):
            progress = Progress('A very long progress label', total=12)
            progress.__enter__()
            progress.update(6)
            progress.done()
        rendered = output.getvalue()
        visible = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", rendered)
        update_lines = [line for line in visible.split("\r") if '50%' in line]
        self.assertTrue(update_lines)
        self.assertLessEqual(len(update_lines[-1]), 24)
        self.assertEqual(rendered.count('\n'), 1)


if __name__ == '__main__':
    unittest.main()
