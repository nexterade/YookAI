import tempfile
import unittest
import zipfile
from unittest.mock import patch
from pathlib import Path
from tools.manager import directory_size, backup, clear_area, _inside_root, _browse, manager
from core import paths

class StorageManagerTests(unittest.TestCase):
    def test_directory_size_counts_files_without_following_symlinks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'a').write_text('123'); (root/'sub').mkdir(); (root/'sub'/'b').write_text('4567')
            self.assertEqual(directory_size(root), 7)
            self.assertEqual(directory_size(root/'a'), 3)

    def test_backup_contains_data_and_not_nested_backup(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'.yookai'; root.mkdir(); (root/'config').mkdir(); (root/'config'/'settings.json').write_text('{"ok":true}')
            path=backup(root)
            with zipfile.ZipFile(path) as zf:
                self.assertIn('config/settings.json', zf.namelist())
                self.assertFalse(any('yookai-backup' in n for n in zf.namelist()))

    def test_clear_known_area_preserves_area_and_other_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'.yookai'; cache=root/'cache'; cache.mkdir(parents=True); (cache/'tmp').write_text('x')
            sessions=root/'sessions'; sessions.mkdir(); (sessions/'keep.json').write_text('{}')
            self.assertEqual(clear_area('cache', root=root), 1)
            self.assertTrue(cache.is_dir()); self.assertEqual(list(cache.iterdir()), [])
            self.assertTrue((sessions/'keep.json').exists())


    def test_manager_accepts_numbered_area(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / ".yookai"
            with patch("tools.manager.overview", return_value={name: 0 for name in ("config", "sessions", "prompts", "cache", "memory", "attachments", "workspace")}), patch("builtins.input", side_effect=["2", "q"]), patch("tools.manager._browse") as browse:
                manager(root=root)
            self.assertTrue((root / "sessions").is_dir())
            browse.assert_called_once_with(root / "sessions")

    def test_browser_edit_accepts_displayed_file_number(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / ".yookai"
            root.mkdir()
            target = root / "default.json"
            target.write_text("{}", encoding="utf-8")
            with patch("builtins.input", side_effect=["e", "1", "q"]), patch.dict("os.environ", {"EDITOR": "nano"}), patch("tools.manager.subprocess.call") as call:
                _browse(root)
            call.assert_called_once_with(["nano", str(target)])

    def test_browser_edit_accepts_relative_filename_and_rejects_absolute(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / ".yookai"
            root.mkdir()
            target = root / "note.txt"
            target.write_text("hello", encoding="utf-8")
            with patch("builtins.input", side_effect=["e", str(target), "e", "note.txt", "q"]), patch.dict("os.environ", {"EDITOR": "nano"}), patch("tools.manager.subprocess.call") as call:
                _browse(root)
            call.assert_called_once_with(["nano", str(target)])

    def test_reject_unknown_area(self):
        with self.assertRaises(ValueError): clear_area('../outside')

    def test_inside_root_rejects_escape(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'root'; root.mkdir()
            self.assertTrue(_inside_root(root/'sub', root))
            self.assertFalse(_inside_root(root.parent/'outside', root))

if __name__ == '__main__': unittest.main()
