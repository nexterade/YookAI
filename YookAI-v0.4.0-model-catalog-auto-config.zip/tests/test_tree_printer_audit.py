import tempfile
import unittest
from pathlib import Path
from semut_suite.tools.tree_printer import parse_imports, resolve_import, scan_dependencies, classify_status, export_json

class TreePrinterAuditTests(unittest.TestCase):
    def test_relative_import_resolves_within_package(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'pkg').mkdir()
            (root / 'pkg' / '__init__.py').write_text('')
            (root / 'pkg' / 'main.py').write_text('from . import helper\nfrom .sub import thing\n')
            (root / 'pkg' / 'helper.py').write_text('VALUE = 1\n')
            (root / 'pkg' / 'sub').mkdir()
            (root / 'pkg' / 'sub' / '__init__.py').write_text('')
            (root / 'pkg' / 'sub' / 'thing.py').write_text('VALUE = 2\n')
            imports = parse_imports(str(root / 'pkg' / 'main.py'))['imports']
            self.assertIn('.helper', imports)
            self.assertIn('.sub.thing', imports)
            self.assertEqual(resolve_import('.helper', str(root), 'pkg/main.py'), 'pkg/helper.py')
            self.assertEqual(resolve_import('.sub.thing', str(root), 'pkg/main.py'), 'pkg/sub/thing.py')

    def test_importlib_dynamic_literal_is_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / 'main.py'
            source.write_text("import importlib\nimportlib.import_module('pkg.worker')\n")
            self.assertIn('pkg.worker', parse_imports(str(source))['imports'])

    def test_orphan_export_warns_not_safe_to_delete(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'main.py').write_text('print("ok")\n')
            (root / 'unused.py').write_text('VALUE = 1\n')
            (root / 'template.html').write_text('<p>hi</p>')
            tree = scan_dependencies('main.py', str(root))
            statuses = classify_status(tree['visited'], ['main.py', 'unused.py', 'template.html'])
            self.assertEqual(statuses['unused.py'], 'orphan')
            self.assertEqual(statuses['template.html'], 'orphan')
            # Review metadata is validated in payload through public export in integration tests.

if __name__ == '__main__':
    unittest.main()
