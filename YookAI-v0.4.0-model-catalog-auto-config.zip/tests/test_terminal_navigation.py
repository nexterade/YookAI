import io
import unittest
from unittest.mock import patch

from tools.terminal import clear_screen


class FakeTTY(io.StringIO):
    def isatty(self):
        return True


class FakePipe(io.StringIO):
    def isatty(self):
        return False


class TerminalNavigationTests(unittest.TestCase):
    def test_clear_screen_clears_screen_scrollback_and_homes_cursor(self):
        stream = FakeTTY()
        self.assertTrue(clear_screen(stream=stream))
        self.assertEqual(stream.getvalue(), "\033[2J\033[3J\033[H")

    def test_non_tty_output_is_not_polluted(self):
        stream = FakePipe()
        self.assertFalse(clear_screen(stream=stream))
        self.assertEqual(stream.getvalue(), "")

    def test_dumb_terminal_is_not_cleared(self):
        stream = FakeTTY()
        with patch.dict("os.environ", {"TERM": "dumb"}):
            self.assertFalse(clear_screen(stream=stream))
        self.assertEqual(stream.getvalue(), "")

    def test_force_can_clear_non_tty(self):
        stream = FakePipe()
        self.assertTrue(clear_screen(stream=stream, force=True))
        self.assertEqual(stream.getvalue(), "\033[2J\033[3J\033[H")


if __name__ == "__main__":
    unittest.main()
