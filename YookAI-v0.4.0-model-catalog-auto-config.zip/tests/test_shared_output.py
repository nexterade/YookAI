import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from semut_suite.core.storage import output_dir, shared_root, location_label, TOOL_FOLDERS

class SharedOutputTests(unittest.TestCase):
    def test_categories_create_distinct_folders_in_shared_yookai_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            shared = Path(tmp) / 'shared'
            shared.mkdir()
            with patch.dict(os.environ, {'YOOKAI_SHARED_DIR': str(shared)}):
                for category, folder in TOOL_FOLDERS.items():
                    self.assertEqual(output_dir(category), shared / 'YookAI' / folder)
                    self.assertTrue((shared / 'YookAI' / folder).is_dir())
                root, is_shared = location_label()
                self.assertEqual(root, shared / 'YookAI')
                self.assertTrue(is_shared)

    def test_unavailable_shared_storage_uses_private_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            with patch('pathlib.Path.home', return_value=home), patch.dict(os.environ, {'YOOKAI_SHARED_DIR': str(home / 'missing')}):
                self.assertEqual(shared_root(), home / '.yookai' / 'semut_suite' / 'output')
                self.assertEqual(output_dir('ghost_grep'), home / '.yookai' / 'semut_suite' / 'output' / 'SearchReports')

    def test_shared_storage_detection_uses_verified_path_not_parent_name(self):
        with tempfile.TemporaryDirectory() as tmp:
            mounted = Path(tmp) / "emulated" / "0"
            mounted.mkdir(parents=True)
            alias = Path(tmp) / "storage" / "shared"
            alias.parent.mkdir()
            alias.symlink_to(mounted, target_is_directory=True)
            with patch("pathlib.Path.home", return_value=Path(tmp)), patch.dict(os.environ, {}, clear=True):
                root, is_shared = location_label()
                self.assertEqual(root, mounted / "YookAI")
                self.assertTrue(is_shared)

    def test_unwritable_shared_mount_falls_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            shared = Path(tmp) / "shared"
            shared.mkdir()
            with patch("semut_suite.core.storage.tempfile.NamedTemporaryFile", side_effect=PermissionError("read-only")), \
                 patch("pathlib.Path.home", return_value=Path(tmp)), \
                 patch.dict(os.environ, {"YOOKAI_SHARED_DIR": str(shared)}):
                root, is_shared = location_label()
                self.assertFalse(is_shared)
                self.assertEqual(root, Path(tmp) / ".yookai" / "semut_suite" / "output")

    def test_unknown_category_rejected(self):
        with self.assertRaises(ValueError):
            output_dir('../outside')

if __name__ == '__main__':
    unittest.main()
