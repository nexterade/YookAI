import unittest
from unittest.mock import Mock, patch
from types import SimpleNamespace

from semut_suite import __maintainer__, __version__
from semut_suite.adapter import load_tool, run_tool
from tools.misc import _run_semut_tool


class SemutIntegrationTests(unittest.TestCase):
    def test_vendored_metadata_is_explicit(self):
        self.assertEqual(__version__, "0.4.0-alpha")
        self.assertEqual(__maintainer__, "@nexterade")

    def test_each_semut_tool_dispatches_through_adapter(self):
        names = (
            "tree_printer", "ghost_grep", "file_hasher", "backup_rotator",
            "sync_helper", "sync_remote", "color_note_exporter",
        )
        for name in names:
            with self.subTest(name=name):
                runner = Mock()
                module = Mock(run_wizard=runner)
                with patch("semut_suite.adapter.import_module", return_value=module) as load:
                    run_tool(name)
                load.assert_called_once_with(f"semut_suite.tools.{name}")
                runner.assert_called_once_with()

    def test_yookai_dispatch_delegates_to_adapter(self):
        with patch("semut_suite.adapter.run_tool") as run:
            _run_semut_tool("tree_printer")
        run.assert_called_once_with("tree_printer")

    def test_unknown_tool_is_rejected(self):
        for name in ("../server", "", "server"):
            with self.subTest(name=name), self.assertRaises(ValueError):
                load_tool(name)

    def test_missing_wizard_is_reported(self):
        with patch("semut_suite.adapter.import_module", return_value=SimpleNamespace()):
            with self.assertRaisesRegex(RuntimeError, "no interactive entry point"):
                run_tool("tree_printer")


if __name__ == "__main__":
    unittest.main()
