import unittest
from unittest.mock import patch

from semut_suite.tools import backup_rotator as backup


class BackupRotationPolicyTests(unittest.TestCase):
    def test_rotation_does_not_prune_under_default_limit(self):
        entries = [
            {"project": "YookAI", "name": f"YookAI_v{i}_03-10-2026.zip",
             "path": f"/tmp/{i}.zip", "backed_up": f"2026-10-03 17:{i:02d}:00", "type": "zip"}
            for i in range(1, 8)
        ]
        with patch.object(backup, "_list_project_backups", return_value=entries), \
             patch.object(backup, "_remove_backup_files") as remove:
            self.assertEqual(backup._prune_project_backups(), [])
            remove.assert_not_called()

    def test_rotation_removes_oldest_timestamp_not_lexical_tag(self):
        entries = [
            {"project": "YookAI", "name": f"YookAI_v{tag}_03-10-2026.zip",
             "path": f"/tmp/{tag}.zip", "backed_up": stamp, "type": "zip",
             "basename": f"YookAI_v{tag}_03-10-2026"}
            for tag, stamp in [("new", "2026-10-03 17:05:00"),
                               ("old", "2026-10-03 17:01:00"),
                               ("mid", "2026-10-03 17:03:00")]
        ]
        with patch.object(backup, "_list_project_backups", return_value=entries), \
             patch.object(backup, "_remove_backup_files", return_value=True) as remove:
            removed = backup._prune_project_backups(max_keep=2)
        self.assertEqual(removed, ["/tmp/old.zip"])
        remove.assert_called_once_with(entries[1])

    def test_zero_retention_is_clamped_to_one(self):
        with patch.object(backup, "_list_project_backups", return_value=[]) as listing:
            self.assertEqual(backup._prune_project_backups(max_keep=0), [])
        listing.assert_called_once()


if __name__ == "__main__":
    unittest.main()
