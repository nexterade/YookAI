import io
import unittest
from unittest.mock import patch, Mock

from tools.configure import NETWORK_ENDPOINTS, _network_test, _classify_http_status


class NetworkTestCliTests(unittest.TestCase):
    @patch('tools.configure.requests.get')
    @patch('tools.configure.socket.getaddrinfo')
    def test_lists_known_urls_and_marks_http_response_reachable(self, dns, get):
        response = Mock(status_code=404)
        get.return_value = response
        output = io.StringIO()
        with patch('sys.stdout', output):
            results = _network_test({"provider": {}})
        self.assertEqual(len(results), len(NETWORK_ENDPOINTS))
        self.assertTrue(all(item['reachable'] for item in results))
        self.assertTrue(all(item['status'] == 'ROUTE 404' for item in results))
        self.assertTrue(all(item['host_reachable'] for item in results))
        self.assertTrue(all(item['http_status'] == 404 for item in results))
        self.assertIn('host reachable', results[0]['detail'])
        self.assertIn('Google Gemini', output.getvalue())
        self.assertIn('no API key is sent', output.getvalue())
        self.assertEqual(get.call_count, len(NETWORK_ENDPOINTS))

    def test_http_status_classification_is_not_a_simple_ok_fail(self):
        self.assertEqual(_classify_http_status(200)[0], "HTTP OK")
        self.assertEqual(_classify_http_status(401)[0], "AUTH REQUIRED")
        self.assertEqual(_classify_http_status(404)[0], "ROUTE 404")
        self.assertEqual(_classify_http_status(429)[0], "RATE LIMITED")
        self.assertEqual(_classify_http_status(503)[0], "HTTP 503")

    @patch('tools.configure.requests.get')
    @patch('tools.configure.socket.getaddrinfo', side_effect=__import__('socket').gaierror('no dns'))
    def test_dns_failure_is_reported_unreachable(self, dns, get):
        output = io.StringIO()
        with patch('sys.stdout', output):
            results = _network_test({"provider": {}})
        self.assertTrue(all(not item['reachable'] for item in results))
        self.assertTrue(all(item['status'] == 'DNS FAILED' for item in results))
        get.assert_not_called()

    @patch('tools.configure.requests.get')
    @patch('tools.configure.socket.getaddrinfo')
    def test_custom_configured_url_is_included(self, dns, get):
        get.return_value = Mock(status_code=200)
        results = _network_test({"provider": {"gemini": {"base_url": "https://proxy.example/api"}}})
        self.assertIn('Google Gemini (configured)', [item['name'] for item in results])
        self.assertIn('https://proxy.example/api', [item['url'] for item in results])

    @patch('tools.configure.requests.get', side_effect=__import__('requests').exceptions.ConnectTimeout())
    @patch('tools.configure.socket.getaddrinfo')
    def test_connection_timeout_is_reported(self, dns, get):
        results = _network_test({"provider": {}})
        self.assertTrue(all(not item['reachable'] for item in results))
        self.assertTrue(all(item['status'] == 'TIMEOUT' for item in results))


if __name__ == '__main__':
    unittest.main()
