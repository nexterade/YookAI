from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "templates" / "app.js"
CSS = Path(__file__).resolve().parents[1] / "templates" / "style.css"


def test_curated_image_models_have_distinct_badges():
    source = APP.read_text(encoding="utf-8")
    expected = {
        "google/gemini-3.1-flash-image": "⚡ Cepat",
        "openai/gpt-image-2": "🎯 Instruksi detail",
        "bytedance-seed/seedream-4.5": "💎 Detail tinggi",
        "google/gemini-3-pro-image": "🔤 Teks & infografik",
    }
    for model_id, badge in expected.items():
        assert model_id in source
        assert badge in source


def test_model_dropdown_renders_badges_accessibly():
    source = APP.read_text(encoding="utf-8")
    assert "imageModelBadge(model)" in source
    assert 'class="model-special-badge"' in source
    assert 'title="${escapeHtml(badge.detail)}"' in source
    assert "model-option-title" in source
    assert ".model-special-badge" in CSS.read_text(encoding="utf-8")


def test_badges_are_descriptive_not_runtime_guarantees():
    source = APP.read_text(encoding="utf-8")
    assert "not runtime capability guarantees" in source


def test_rich_model_cards_render_metadata_and_selection():
    source = APP.read_text(encoding="utf-8")
    for token in ["model-option-card", "model-art", "model-option-id", "model-capabilities", "model-option-description", "model-selected"]:
        assert token in source
    css = CSS.read_text(encoding="utf-8")
    assert ".model-option-card" in css
    assert "max-height:calc(100dvh - 76px)" in css


def test_gemini_image_model_aliases_are_supported():
    source = APP.read_text(encoding="utf-8")
    assert "gemini-2.5-flash-image" in source
    assert "google/gemini-3-pro-image" in source


def test_provider_switch_ignores_stale_model_responses():
    source = APP.read_text(encoding="utf-8")
    assert "providerRequestId" in source
    assert "requestId!==this.providerRequestId||provider!==state.currentProvider" in source


def test_model_auto_config_uses_declared_output_limit_only():
    source = APP.read_text(encoding="utf-8")
    assert "max_output_tokens" in source
    assert "Math.min(Number(profile.max_tokens)||2048,model.max_output_tokens)" in source
    assert '"max_output_tokens": (model.get("top_provider") or {}).get("max_completion_tokens")' in (APP.parents[1] / "providers" / "openrouter.py").read_text(encoding="utf-8")


def test_model_categories_are_collapsible():
    source = (APP.parents[1] / "templates" / "partials" / "model-selector.html").read_text(encoding="utf-8")
    assert '<details class="model-group" data-group="free">' in source
    assert '<details class="model-group" data-group="all">' in source
