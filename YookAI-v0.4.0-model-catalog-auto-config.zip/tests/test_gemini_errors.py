import unittest
from unittest.mock import Mock, patch

from providers.gemini import GeminiProvider
from providers.errors import ProviderHTTPError


class GeminiUpstreamErrorTests(unittest.TestCase):
    def setUp(self):
        self.provider = GeminiProvider("secret-key")

    def test_raise_includes_google_message_status_and_safe_endpoint(self):
        response = Mock(status_code=404, url="https://generativelanguage.googleapis.com/v1beta/models/missing:streamGenerateContent?key=secret-key")
        response.json.return_value = {"error": {"code": 404, "status": "NOT_FOUND", "message": "models/missing not found"}}
        with self.assertRaises(ProviderHTTPError) as caught:
            self.provider._raise(response)
        message = str(caught.exception)
        self.assertIn("404 NOT_FOUND", message)
        self.assertIn("models/missing not found", message)
        self.assertIn("/v1beta/models/missing:streamGenerateContent", message)
        self.assertNotIn("secret-key", message)
        self.assertEqual(caught.exception.status_code, 404)

    @patch("providers.gemini.requests.post")
    def test_stream_error_chunk_preserves_upstream_message(self, mock_post):
        response = Mock(status_code=404, url="https://generativelanguage.googleapis.com/v1beta/models/missing:streamGenerateContent?key=secret-key")
        response.json.return_value = {"error": {"status": "NOT_FOUND", "message": "model unavailable"}}
        mock_post.return_value = response
        chunks = list(self.provider.stream_chat([{"role": "user", "content": "hi"}], "missing"))
        self.assertEqual(chunks[0]["type"], "error")
        self.assertIn("model unavailable", chunks[0]["message"])
        self.assertNotIn("secret-key", chunks[0]["message"])

    def test_non_json_error_still_reports_status(self):
        response = Mock(status_code=503, url="https://generativelanguage.googleapis.com/v1beta/test?key=secret-key")
        response.json.side_effect = ValueError("not json")
        with self.assertRaises(ProviderHTTPError) as caught:
            self.provider._raise(response)
        self.assertIn("Gemini HTTP error (503)", str(caught.exception))
        self.assertIn("/v1beta/test", str(caught.exception))
        self.assertNotIn("secret-key", str(caught.exception))


if __name__ == "__main__":
    unittest.main()
