"""Stable dispatch boundary between YookAI and the Semut utility suite."""
from __future__ import annotations

from importlib import import_module
from types import ModuleType

# Explicit allowlist: UI code must not be able to import arbitrary modules.
TOOL_MODULES = {
    "tree_printer",
    "ghost_grep",
    "file_hasher",
    "backup_rotator",
    "sync_helper",
    "sync_remote",
    "color_note_exporter",
}


def load_tool(name: str) -> ModuleType:
    """Load a supported Semut tool by its public utility name."""
    if name not in TOOL_MODULES:
        raise ValueError(f"Unknown Semut utility: {name}")
    return import_module(f"semut_suite.tools.{name}")


def run_tool(name: str) -> None:
    """Run a supported utility's interactive entry point."""
    # Start each utility on a clean screen; keep its final output visible
    # until the caller handles Back/pause and renders the parent menu again.
    from tools.terminal import clear_screen
    clear_screen()
    module = load_tool(name)
    runner = getattr(module, "run_wizard", None)
    if not callable(runner):
        raise RuntimeError(f"Semut tool {name} has no interactive entry point")
    runner()
