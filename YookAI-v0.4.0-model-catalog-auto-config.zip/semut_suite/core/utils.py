"""
core/utils.py — Helper bersama buat project semut.

Kumpulan fungsi utility yang dipake di banyak tempat.
Dimulai dari wait_for_file() buat handle FUSE lag di
Android shared storage.
"""

import os
import time
import json
import tempfile


# ============================================================
# FILE SYSTEM HELPERS
# ============================================================

def wait_for_file(
    path: str,
    timeout: float = 1.5,
    interval: float = 0.5,
    check_dir: bool = False,
    verbose: bool = False,
) -> bool:
    """
    Tunggu sampai file (atau folder) ada.

    Berguna buat handle FUSE lag di Android shared storage —
    kadang file yang baru di-save di Acode butuh waktu
    beberapa ratus ms sebelum "keliatan" dari Termux.

    Args:
        path      : path yang ditunggu
        timeout   : total waktu tunggu (detik), default 1.5s
        interval  : jeda antar check (detik), default 500ms
        check_dir : True = cek folder, False = cek file
        verbose   : True = print info kalau file belum ada

    Returns:
        True  kalau file/folder ada dalam timeout
        False kalau timeout (file emang gak ada)
    """
    checker = os.path.isdir if check_dir else os.path.isfile

    # Fast path — kalau file udah ada, langsung return
    if checker(path):
        return True

    # Kalau gak ada, baru tunggu
    deadline = time.time() + timeout
    attempts = 0

    while time.time() < deadline:
        attempts += 1
        if verbose:
            print(f"  ⏳  Menunggu: {os.path.basename(path)} ({attempts}x)")

        time.sleep(interval)

        if checker(path):
            if verbose:
                print(f"  ✓  File muncul setelah {attempts * interval:.1f}s")
            return True

    # Final check — mungkin muncul di detik terakhir
    return checker(path)


# ============================================================
# SIZE HELPERS
# ============================================================

def format_size(size_bytes: int) -> str:
    """
    Format size jadi human-readable.

    Contoh:
        1234      → "1.2 KB"
        1234567   → "1.2 MB"
        1234567890 → "1.15 GB"

    Args:
        size_bytes : ukuran dalam bytes

    Returns:
        String human-readable
    """
    if size_bytes < 0:
        return "—"

    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"


# ============================================================
# JSON HELPERS
# ============================================================

def read_json(path: str, default=None):
    """
    Baca file JSON dengan aman.
    Return default kalau file gak ada / error.
    """
    if not os.path.isfile(path):
        return default if default is not None else {}

    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default if default is not None else {}


def write_json(path: str, data, indent: int = 2) -> bool:
    """
    Tulis file JSON dengan aman (atomic write).
    Return True kalau sukses, False kalau gagal.
    """
    tmp_path = path + ".tmp"

    try:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=indent, ensure_ascii=False)
        os.replace(tmp_path, path)
        return True
    except (OSError, ValueError, TypeError):
        # Cleanup tmp file kalau gagal
        try:
            if os.path.isfile(tmp_path):
                os.remove(tmp_path)
        except OSError:
            pass
        return False



# ============================================================
# PROJECT / TOOL OUTPUT HELPERS
# ============================================================

def get_semut_root() -> str:
    """Return YookAI's persistent data subdirectory for Semut utilities."""
    return os.path.join(os.path.expanduser("~"), ".yookai", "semut_suite")


def get_output_dir(category: str = "sync_helper") -> str:
    """Return/create the categorized shared output directory (private fallback)."""
    from semut_suite.core.storage import output_dir
    return str(output_dir(category))


def file_size(path: str) -> int:
    """Return file size in bytes, atau 0 kalau gagal."""
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def is_junk(name: str) -> bool:
    """Return True untuk nama file sementara/backup umum."""
    import re
    patterns = (
        r".*\.bak$", r".*\.bak[._].*$", r".*\.old$", r".*\.orig$",
        r".*\.tmp$", r".*\.swp$", r".*\.swo$", r".*~$",
        r".*\.pyc$", r".*\.pyo$", r".*_bak\..*$",
    )
    return any(re.match(pattern, str(name)) for pattern in patterns)


def should_exclude(path: str) -> bool:
    """Fallback exclude berdasarkan nama folder."""
    from pathlib import Path
    from semut_suite.core.exclude import FALLBACK_EXCLUDE
    return any(part in FALLBACK_EXCLUDE for part in Path(path).parts)

# ============================================================
# SELF-TEST (jalanin: python3 -m core.utils)
# ============================================================

if __name__ == "__main__":
    print("=" * 60)
    print("  CORE UTILS SELF-TEST")
    print("=" * 60)
    print()

    # Test format_size
    print("  ── format_size() ──")
    test_sizes = [0, 500, 1024, 12345, 1234567, 1234567890]
    for s in test_sizes:
        print(f"    {s:>12} bytes  →  {format_size(s)}")
    print()

    # Test wait_for_file (file yang pasti ada)
    print("  ── wait_for_file() ──")
    this_file = os.path.abspath(__file__)
    result = wait_for_file(this_file, timeout=1.0, verbose=True)
    print(f"    File ini ada? {result}")
    print()

    # Test wait_for_file (file yang pasti gak ada)
    fake_path = os.path.join(
        tempfile.gettempdir(),
        "__file_ga_ada_12345__.txt"
    )
    result = wait_for_file(fake_path, timeout=1.0)
    print(f"    File fiktif ada? {result}  (harusnya False)")
    print()

    # Test read_json / write_json
    print("  ── read_json / write_json ──")
    test_data = {"name": "semut", "version": "0.1.0", "items": [1, 2, 3]}
    test_path = os.path.join(
        tempfile.gettempdir(),
        "__semut_test__.json"
    )

    write_ok = write_json(test_path, test_data)
    print(f"    write_json: {write_ok}")

    read_data = read_json(test_path)
    print(f"    read_json:  {read_data}")
    print(f"    Match:      {read_data == test_data}")

    # Cleanup
    try:
        if os.path.isfile(test_path):
            os.remove(test_path)
    except OSError:
        pass
    print()

    print("  ✓ Semua test selesai!")
    print()
