"""Centralized, non-sensitive output locations for Semut tools in YookAI."""
from __future__ import annotations
import os
import tempfile
from pathlib import Path

TOOL_FOLDERS = {
    "backups": "Backups",
    "tree_printer": "TreeReports",
    "ghost_grep": "SearchReports",
    "file_hasher": "FileHashes",
    "sync_helper": "Sync",
    "sync_remote": "Sync",
    "color_note_exporter": "ColorNote",
    "imports": "Imports",
    "logs": "Logs",
}


def _shared_base() -> Path | None:
    """Return a writable mounted shared-storage directory, if verified.

    Android may expose shared storage through symlinks and FUSE mounts, so
    parent-directory names and os.access() alone are not reliable signals.
    A short-lived probe verifies actual create/delete access.
    """
    override = os.environ.get("YOOKAI_SHARED_DIR", "").strip()
    candidate = Path(override).expanduser() if override else Path.home() / "storage" / "shared"
    try:
        if not candidate.is_dir():
            return None
        with tempfile.NamedTemporaryFile(prefix=".yookai-write-check-", dir=candidate, delete=True):
            pass
        return candidate.resolve()
    except (OSError, PermissionError):
        return None


def shared_root() -> Path:
    """Return Android shared storage root when writable, else private fallback."""
    base = _shared_base()
    if base is not None:
        return base / "YookAI"
    return Path.home() / ".yookai" / "semut_suite" / "output"


def output_dir(tool: str) -> Path:
    """Create and return a tool-specific output directory."""
    folder = TOOL_FOLDERS.get(tool)
    if not folder:
        raise ValueError(f"Unknown output category: {tool}")
    root = shared_root()
    path = root / folder if root.name == "YookAI" else root / folder
    path.mkdir(parents=True, exist_ok=True)
    return path


def location_label() -> tuple[Path, bool]:
    """Return output root and whether it is shared Android storage."""
    base = _shared_base()
    if base is not None:
        return base / "YookAI", True
    return Path.home() / ".yookai" / "semut_suite" / "output", False
