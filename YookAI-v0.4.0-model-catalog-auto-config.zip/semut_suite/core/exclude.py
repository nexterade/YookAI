"""
core/exclude.py — Manajemen exclude global untuk semua tool Semut.

File config: semut/.exclude.json (hidden file di root project)
Format:
    {
        "version": 1,
        "updated_at": "...",
        "patterns": ["backups/", "output/", ...],
        "notes": {"backups/": "Folder backup", ...}
    }

Pattern syntax:
    - fnmatch-style: *.log, *.tmp, test_*.py
    - Trailing slash: "backups/" → match folder & isinya
    - Case-insensitive
    - Path matching: relatif ke root project
"""

import fnmatch
import os
import time
from pathlib import Path

from semut_suite.core.utils import read_json, write_json


EXCLUDE_FILENAME = ".exclude.json"
EXCLUDE_VERSION = 1

DEFAULT_PATTERNS = [
    "backups/",
    "output/",
    "Releases/",
    "__pycache__/",
    ".git/",
    ".venv/",
    "venv/",
    "node_modules/",
    ".path_history.json",
    "*.log",
    "*.tmp",
    "*.bak",
    "*.pyc",
    "*.pyo",
    ".DS_Store",
    "Thumbs.db",
]

FALLBACK_EXCLUDE = {
    "__pycache__", ".git", ".idea", ".vscode",
    "node_modules", "venv", ".venv", "env",
    "backups", "_backups", "output", "cache",
    ".semut", "public", "Releases",
}

DEFAULT_NOTES = {
    "backups/": "Folder backup Semut",
    "output/": "Output auto-generated",
    "Releases/": "ZIP versi siap upload",
    "__pycache__/": "Cache Python",
    ".git/": "Git folder",
    ".venv/": "Virtual env",
    "venv/": "Virtual env",
    "node_modules/": "Node modules",
    ".path_history.json": "Privacy — jangan di-sync",
    "*.log": "Log file",
    "*.tmp": "Temp file",
    "*.bak": "Backup file lama",
    "*.pyc": "Python bytecode",
    "*.pyo": "Python bytecode",
    ".DS_Store": "macOS junk",
    "Thumbs.db": "Windows junk",
}


def _project_root() -> Path:
    """Return isolated Semut utility data root under YookAI storage."""
    return Path.home() / ".yookai" / "semut_suite"


def get_exclude_path() -> Path:
    """Return lokasi file exclude global Semut."""
    return _project_root() / EXCLUDE_FILENAME


def _exclude_path() -> Path:
    """Backward-compatible internal alias."""
    return get_exclude_path()


def _default_data() -> dict:
    return {
        "version": EXCLUDE_VERSION,
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        "patterns": list(DEFAULT_PATTERNS),
        "notes": dict(DEFAULT_NOTES),
    }


def _load() -> dict:
    """Baca .exclude.json. Auto-generate default kalau gak ada / rusak."""
    path = _exclude_path()
    if not path.is_file():
        data = _default_data()
        _save(data)
        return data
    data = read_json(str(path), default=None)
    if not isinstance(data, dict):
        data = _default_data()
        _save(data)
        return data
    if not isinstance(data.get("patterns"), list):
        data["patterns"] = list(DEFAULT_PATTERNS)
    if not isinstance(data.get("notes"), dict):
        data["notes"] = dict(DEFAULT_NOTES)
    data.setdefault("version", EXCLUDE_VERSION)
    data.setdefault("updated_at", "")
    return data


def _save(data: dict) -> bool:
    data["version"] = EXCLUDE_VERSION
    data["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    return write_json(str(_exclude_path()), data)


# ============================================================
# PUBLIC API
# ============================================================

def get_patterns() -> list:
    """Return list pattern exclude (case-insensitive, dedup, urut)."""
    data = _load()
    seen = set()
    result = []
    for p in data["patterns"]:
        if not isinstance(p, str):
            continue
        key = p.casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(p)
    return result


def get_notes() -> dict:
    """Return dict {pattern: note}."""
    data = _load()
    return dict(data.get("notes", {}))


def add_pattern(pattern: str, note: str = "") -> tuple:
    """Tambah pattern. Return (ok, message)."""
    pattern = str(pattern or "").strip()
    if not pattern:
        return False, "Pattern kosong."
    data = _load()
    existing_keys = {p.casefold() for p in data["patterns"]}
    if pattern.casefold() in existing_keys:
        return False, f"Pattern '{pattern}' udah ada."
    data["patterns"].append(pattern)
    if note:
        data["notes"][pattern] = str(note).strip()
    _save(data)
    return True, f"Pattern '{pattern}' ditambahkan."


def remove_pattern(pattern: str) -> tuple:
    """Hapus pattern. Return (ok, message)."""
    pattern = str(pattern or "").strip()
    if not pattern:
        return False, "Pattern kosong."
    data = _load()
    keys = {p.casefold(): p for p in data["patterns"]}
    if pattern.casefold() not in keys:
        return False, f"Pattern '{pattern}' gak ditemukan."
    original = keys[pattern.casefold()]
    data["patterns"] = [
        p for p in data["patterns"] if p.casefold() != pattern.casefold()
    ]
    data["notes"].pop(original, None)
    _save(data)
    return True, f"Pattern '{original}' dihapus."


def update_note(pattern: str, note: str) -> tuple:
    """Update catatan pattern. Return (ok, message)."""
    pattern = str(pattern or "").strip()
    if not pattern:
        return False, "Pattern kosong."
    data = _load()
    keys = {p.casefold(): p for p in data["patterns"]}
    if pattern.casefold() not in keys:
        return False, f"Pattern '{pattern}' gak ditemukan."
    original = keys[pattern.casefold()]
    data["notes"][original] = str(note or "").strip()
    _save(data)
    return True, f"Catatan '{original}' diupdate."


def reset_default() -> tuple:
    """Reset ke default. Return (ok, message)."""
    _save(_default_data())
    return True, "Exclude direset ke default."


def is_excluded(rel_path: str, patterns: list = None) -> bool:
    """Cek apakah rel_path ke-exclude.

    Args:
        rel_path: path relatif ke root project (pake / sebagai separator)
        patterns: optional list pattern. Kalau None, baca dari file.

    Returns:
        True kalau ke-exclude.
    """
    if not rel_path:
        return False
    if patterns is None:
        patterns = get_patterns()

    # Normalisasi: pake / sebagai separator, hilangkan leading ./
    rel = str(rel_path).replace(os.sep, "/").lstrip("./")
    if not rel:
        return False
    rel_lower = rel.casefold()
    rel_parts = rel_lower.split("/")
    basename = rel_parts[-1]

    for raw in patterns:
        if not isinstance(raw, str):
            continue
        pattern = raw.strip().replace(os.sep, "/")
        if not pattern:
            continue
        is_dir_pattern = pattern.endswith("/")
        if is_dir_pattern:
            pattern = pattern.rstrip("/")
        pat_lower = pattern.casefold()
        if not pat_lower:
            continue

        # Cek match di tiap level path (biar "backups/" match "backups/x/y")
        if is_dir_pattern:
            for i in range(len(rel_parts)):
                segment = rel_parts[i]
                subpath = "/".join(rel_parts[:i + 1])
                if fnmatch.fnmatchcase(segment, pat_lower):
                    return True
                if fnmatch.fnmatchcase(subpath, pat_lower):
                    return True
            # Cek full path juga (buat pattern kayak "src/backups/")
            if fnmatch.fnmatchcase(rel_lower, pat_lower + "/*"):
                return True
            if rel_lower == pat_lower:
                return True
            continue

        # Pattern file (bukan folder)
        if fnmatch.fnmatchcase(basename, pat_lower):
            return True
        if fnmatch.fnmatchcase(rel_lower, pat_lower):
            return True
        # Kalau pattern ada slash, cek full path
        if "/" in pat_lower and fnmatch.fnmatchcase(rel_lower, pat_lower):
            return True

    return False


def filter_excluded(rel_paths: list, patterns: list = None) -> list:
    """Filter list path — buang yang ke-exclude. Return list baru."""
    if patterns is None:
        patterns = get_patterns()
    return [p for p in rel_paths if not is_excluded(p, patterns)]


def get_excluded_paths(rel_paths: list, patterns: list = None) -> list:
    """Return list path yang ke-exclude aja (buat preview)."""
    if patterns is None:
        patterns = get_patterns()
    return [p for p in rel_paths if is_excluded(p, patterns)]