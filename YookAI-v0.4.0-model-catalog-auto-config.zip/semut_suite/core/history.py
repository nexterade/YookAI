"""
core/history.py — Path History System (Global)

Simpen history path yang pernah di-input user, biar gak perlu
ketik ulang tiap kali pake tool.

Fitur:
    - Simpen path individual (buat auto-complete di prompt)
    - Simpen pasangan source-target (buat quick sync)
    - Max 20 path + 20 pairs (auto-prune yang paling lama)
    - Fungsi prompt_path_with_history() buat tool

Filosofi:
    Sekali input, selamanya kepake. Hemat waktu, hemat energi.
    Global — satu file buat semua tool, biar gak duplikat.

File: semut/.path_history.json
"""

import os
import json
import time

from semut_suite.ui import printer
from semut_suite.ui.theme import get_theme
from semut_suite.ui.prompt import (
    prompt_input, prompt_choice, prompt_yes_no,
    is_cancelled, CANCEL_SENTINEL,
)


# ============================================================
# CONSTANTS
# ============================================================

HISTORY_FILENAME = ".path_history.json"
HISTORY_VERSION = 1

MAX_RECENT_PATHS = 20
MAX_RECENT_PAIRS = 20
MAX_DISPLAY = 10


# ============================================================
# INTERNAL — PATH
# ============================================================

def _get_semut_root() -> str:
    """Return isolated persistent data root under ~/.yookai."""
    return os.path.join(os.path.expanduser("~"), ".yookai", "semut_suite")


def _get_history_path() -> str:
    """Return path file history: semut/.path_history.json"""
    return os.path.join(_get_semut_root(), HISTORY_FILENAME)


# ============================================================
# INTERNAL — LOAD & SAVE
# ============================================================

def _empty_history() -> dict:
    """Return struktur history kosong."""
    return {
        "version": HISTORY_VERSION,
        "paths":   [],
        "pairs":   [],
    }


def _load_history() -> dict:
    """
    Load history dari file. Kalau belum ada / corrupt, return kosong.
    """
    path = _get_history_path()

    if not os.path.isfile(path):
        return _empty_history()

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, dict):
            return _empty_history()

        if "paths" not in data or not isinstance(data["paths"], list):
            data["paths"] = []
        if "pairs" not in data or not isinstance(data["pairs"], list):
            data["pairs"] = []

        data["version"] = data.get("version", HISTORY_VERSION)

        return data

    except (OSError, ValueError, UnicodeDecodeError):
        return _empty_history()


def _save_history(data: dict) -> bool:
    """Save history ke file. Return True kalau sukses."""
    path = _get_history_path()

    try:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

        tmp_path = path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        os.replace(tmp_path, path)
        return True

    except OSError:
        return False


def get_history_path() -> str:
    """Return lokasi file history untuk consumer di luar modul."""
    return _get_history_path()


def load_history() -> dict:
    """Load history lewat public API."""
    return _load_history()


def save_history(data: dict) -> bool:
    """Save history lewat public API."""
    return _save_history(data)


# ============================================================
# PUBLIC — ADD PATH
# ============================================================

def _now_str() -> str:
    """Return timestamp string."""
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def _find_path_entry(history: dict, path: str) -> dict:
    """Cari entry path di history. Return None kalau gak ada."""
    for entry in history["paths"]:
        if entry.get("path") == path:
            return entry
    return None


def add_path(path: str, tool_id: str = "") -> None:
    """
    Tambah path ke history (atau update kalau udah ada).

    Args:
        path:    absolute path
        tool_id: id tool yang pake path ini (opsional)
    """
    if not path:
        return

    path = os.path.abspath(os.path.expanduser(path.strip()))

    history = _load_history()
    entry = _find_path_entry(history, path)

    if entry:
        entry["last_used"] = _now_str()
        entry["use_count"] = entry.get("use_count", 0) + 1

        used_in = entry.get("used_in", [])
        if tool_id and tool_id not in used_in:
            used_in.append(tool_id)
        entry["used_in"] = used_in
    else:
        history["paths"].append({
            "path":      path,
            "last_used": _now_str(),
            "use_count": 1,
            "used_in":   [tool_id] if tool_id else [],
        })

    if len(history["paths"]) > MAX_RECENT_PATHS:
        history["paths"].sort(
            key=lambda x: x.get("last_used", ""),
            reverse=True,
        )
        history["paths"] = history["paths"][:MAX_RECENT_PATHS]

    _save_history(history)


# ============================================================
# PUBLIC — ADD PAIR
# ============================================================

def _find_pair_entry(history: dict, source: str, target: str) -> dict:
    """Cari entry pair di history. Return None kalau gak ada."""
    for entry in history["pairs"]:
        if entry.get("source") == source and entry.get("target") == target:
            return entry
    return None


def add_pair(source: str, target: str, tool_id: str = "") -> None:
    """
    Tambah pasangan source-target ke history.
    """
    if not source or not target:
        return

    source = os.path.abspath(os.path.expanduser(source.strip()))
    target = os.path.abspath(os.path.expanduser(target.strip()))

    history = _load_history()
    entry = _find_pair_entry(history, source, target)

    if entry:
        entry["last_used"] = _now_str()
        entry["use_count"] = entry.get("use_count", 0) + 1

        used_in = entry.get("used_in", [])
        if tool_id and tool_id not in used_in:
            used_in.append(tool_id)
        entry["used_in"] = used_in
    else:
        history["pairs"].append({
            "source":    source,
            "target":    target,
            "last_used": _now_str(),
            "use_count": 1,
            "used_in":   [tool_id] if tool_id else [],
        })

    if len(history["pairs"]) > MAX_RECENT_PAIRS:
        history["pairs"].sort(
            key=lambda x: x.get("last_used", ""),
            reverse=True,
        )
        history["pairs"] = history["pairs"][:MAX_RECENT_PAIRS]

    _save_history(history)


# ============================================================
# PUBLIC — GET RECENT
# ============================================================

def get_recent_paths(limit: int = MAX_DISPLAY) -> list:
    """Return list path terbaru, sort by last_used descending."""
    history = _load_history()
    paths = history.get("paths", [])

    paths_sorted = sorted(
        paths,
        key=lambda x: x.get("last_used", ""),
        reverse=True,
    )

    return paths_sorted[:limit]


def get_recent_pairs(limit: int = MAX_DISPLAY) -> list:
    """Return list pair terbaru, sort by last_used descending."""
    history = _load_history()
    pairs = history.get("pairs", [])

    pairs_sorted = sorted(
        pairs,
        key=lambda x: x.get("last_used", ""),
        reverse=True,
    )

    return pairs_sorted[:limit]


# ============================================================
# PUBLIC — PROMPT WITH HISTORY
# ============================================================

def _truncate_path(path: str, max_len: int = 60) -> str:
    """Truncate path panjang dari tengah."""
    if len(path) <= max_len:
        return path
    half = (max_len - 3) // 2
    return path[:half] + "..." + path[-half:]


def prompt_path_with_history(
    label: str,
    tool_id: str = "",
    allow_empty: bool = False,
    default_empty: str = "",
) -> str:
    """
    Prompt path dengan history.

    Args:
        label:         label prompt (misal "Path folder A")
        tool_id:       id tool (buat catet used_in)
        allow_empty:   kalau True, kosong = pake default_empty
        default_empty: value kalau user kosongin

    Return:
        str path, atau "" kalau dibatalkan
    """
    t = get_theme()

    recent = get_recent_paths(limit=MAX_DISPLAY)

    # Kalau gak ada history — fallback ke prompt_input biasa
    if not recent:
        result = prompt_input(
            label,
            default=default_empty if allow_empty else "",
            show_cancel=True,
        )
        if is_cancelled(result):
            return ""
        if not result and allow_empty:
            return default_empty
        if not result:
            return ""

        result = result.strip()
        add_path(result, tool_id)   # ← FIX: simpen ke history
        return result

    # Tampilin list history
    printer.print_blank()
    printer.print_info(f"{label}:")
    printer.print_blank()

    for i, entry in enumerate(recent, 1):
        path = entry.get("path", "")
        use_count = entry.get("use_count", 1)
        display = _truncate_path(path)

        print(
            f"  {t.ACCENT}[{i}]{t.RESET}  "
            f"{t.WHITE}{display}{t.RESET}  "
            f"{t.GRAY}({use_count}x){t.RESET}"
        )

    print(
        f"  {t.ACCENT}[0]{t.RESET}  "
        f"{t.GRAY}Input manual{t.RESET}"
    )
    printer.print_blank()

    default_str = "0"

    try:
        choice = input(
            f"  {t.ACCENT}→{t.RESET}  "
            f"Pilih [1-{len(recent)}={len(recent)}, 0=manual, default: {default_str}]: "
        ).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return ""

    if is_cancelled(choice):
        return ""

    # User pilih nomor
    if choice.isdigit():
        idx = int(choice)
        if 1 <= idx <= len(recent):
            selected = recent[idx - 1].get("path", "")
            printer.print_success(f"Pakai: {selected}")
            add_path(selected, tool_id)
            return selected

    # Input manual (atau pilihan invalid)
    printer.print_blank()
    result = prompt_input(
        label,
        default=default_empty if allow_empty else "",
        show_cancel=True,
    )

    if is_cancelled(result):
        return ""

    if not result and allow_empty:
        return default_empty

    if not result:
        return ""

    result = result.strip()
    add_path(result, tool_id)
    return result


def prompt_pair_with_history(
    label_a: str = "Path folder SOURCE",
    label_b: str = "Path folder TARGET",
    tool_id: str = "",
) -> tuple:
    """
    Prompt 2 path dengan history.

    Return:
        (source, target) atau ("", "") kalau dibatalkan
    """
    source = prompt_path_with_history(label_a, tool_id)
    if not source:
        return "", ""

    printer.print_blank()
    target = prompt_path_with_history(label_b, tool_id)
    if not target:
        return "", ""

    return source, target