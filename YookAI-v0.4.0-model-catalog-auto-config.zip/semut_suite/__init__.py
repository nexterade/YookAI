"""Semut utility suite integrated as a separately namespaced subsystem.

The upstream Semut project is maintained by @nexterade. This vendored copy
keeps the utility implementation isolated from YookAI application modules.
"""

__version__ = "0.4.0-alpha"
__maintainer__ = "@nexterade"
