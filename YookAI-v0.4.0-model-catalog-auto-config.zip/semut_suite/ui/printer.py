"""
ui/printer.py — Print Helper Terpusat

Semua output CLI (success, error, info, warn, dll) WAJIB lewat sini.
DILARANG pake print() mentah buat UI/status.

Filosofi:
    - Konsisten visual di seluruh tool.
    - Semua helper otomatis handle warna via ui.theme.
    - Kalau warna off, output tetep rapi (tanpa ANSI code).
"""

import sys
from .theme import get_theme


# ============================================================
# ICON MAP
# ============================================================

ICONS = {
    "success":  "✓",
    "error":    "✗",
    "warn":     "⚠",
    "info":     "ℹ",
    "bullet":   "•",
    "arrow":    "→",
    "ghost":    "🐜",
    "file":     "📄",
    "folder":   "📁",
    "lock":     "🔒",
    "key":      "🔑",
    "search":   "👁",
    "tree":     "🌳",
    "sync":     "🔄",
    "hash":     "🔐",
    "backup":   "🗂",
    "markdown": "📜",
}


# ============================================================
# CORE HELPERS
# ============================================================

def _out(text: str = "", end: str = "\n", file=None):
    """Output mentah — handle stdout/stderr."""
    if file is None:
        file = sys.stdout
    print(text, end=end, file=file)


def _wrap(text: str, color: str, reset: str = "") -> str:
    """Wrap text dengan color code. Kalau color kosong, return text as-is."""
    if not color:
        return text
    if not reset:
        reset = get_theme().RESET
    return f"{color}{text}{reset}"


# ============================================================
# PUBLIC API — STATUS
# ============================================================

def print_success(msg: str):
    """Print pesan sukses (hijau, dengan icon ✓)."""
    t = get_theme()
    icon = ICONS["success"]
    _out(f"  {t.GREEN}{icon}{t.RESET}  {msg}")


def print_error(msg: str):
    """Print pesan error (merah, dengan icon ✗) ke stderr."""
    t = get_theme()
    icon = ICONS["error"]
    _out(f"  {t.RED}{icon}{t.RESET}  {msg}", file=sys.stderr)


def print_warn(msg: str):
    """Print pesan warning (kuning, dengan icon ⚠)."""
    t = get_theme()
    icon = ICONS["warn"]
    _out(f"  {t.YELLOW}{icon}{t.RESET}  {msg}")


def print_info(msg: str):
    """Print pesan info (accent/gray, dengan icon ℹ)."""
    t = get_theme()
    icon = ICONS["info"]
    _out(f"  {t.ACCENT_DIM}{icon}{t.RESET}  {t.GRAY}{msg}{t.RESET}")


def print_status(msg: str, status: str = "info"):
    """
    Print status dengan icon sesuai tipe.

    Status: success | error | warn | info | ghost
    """
    t = get_theme()
    icon = ICONS.get(status, ICONS["info"])

    color_map = {
        "success": t.GREEN,
        "error":   t.RED,
        "warn":    t.YELLOW,
        "info":    t.ACCENT_DIM,
        "ghost":   t.ACCENT,
    }
    color = color_map.get(status, t.ACCENT_DIM)

    _out(f"  {color}{icon}{t.RESET}  {msg}")


# ============================================================
# PUBLIC API — LIST & BULLETS
# ============================================================

def print_bullet(msg: str, indent: int = 2, color: str = None):
    """Print bullet point (•)."""
    t = get_theme()
    icon = ICONS["bullet"]
    pad = " " * indent
    if color:
        _out(f"{pad}{t.ACCENT}{icon}{t.RESET}  {color}{msg}{t.RESET}")
    else:
        _out(f"{pad}{t.ACCENT}{icon}{t.RESET}  {msg}")


def print_arrow(msg: str, indent: int = 2):
    """Print pesan dengan prefix arrow (→)."""
    t = get_theme()
    icon = ICONS["arrow"]
    pad = " " * indent
    _out(f"{pad}{t.ACCENT}{icon}{t.RESET}  {msg}")


def print_numbered(n: int, msg: str, indent: int = 2):
    """Print item bernomor."""
    t = get_theme()
    pad = " " * indent
    _out(f"{pad}{t.ACCENT}[{n}]{t.RESET}  {msg}")


def print_kv(key: str, value: str, indent: int = 2, sep: str = ":"):
    """Print key-value pair."""
    t = get_theme()
    pad = " " * indent
    _out(f"{pad}{t.ACCENT_DIM}{key}{t.RESET}{sep}  {t.WHITE}{value}{t.RESET}")


# ============================================================
# PUBLIC API — SECTIONS & SEPARATORS
# ============================================================

def print_section(title: str, icon: str = None):
    """Print section header dengan garis pemisah."""
    t = get_theme()
    icon_str = f"{icon}  " if icon else ""
    _out()
    _out(f"  {t.ACCENT}{t.BOLD}{icon_str}{title}{t.RESET}")
    _out(f"  {t.ACCENT_DIM}{'─' * 56}{t.RESET}")


def print_separator(char: str = "─", width: int = 56, indent: int = 2):
    """Print garis pemisah."""
    t = get_theme()
    pad = " " * indent
    _out(f"{pad}{t.ACCENT_DIM}{char * width}{t.RESET}")


def print_banner(title: str, subtitle: str = "", version: str = ""):
    """Print banner pembuka."""
    t = get_theme()
    _out()
    line = "═" * 60

    # Baris atas
    _out(f"  {t.ACCENT}{line}{t.RESET}")

    # Title row
    title_str = f"🐜  {title}"
    if version:
        title_str += f"  {t.ACCENT_DIM}v{version}{t.RESET}"
    _out(f"  {t.BOLD}{t.WHITE}{title_str}{t.RESET}")

    # Subtitle
    if subtitle:
        _out(f"  {t.GRAY}{subtitle}{t.RESET}")

    # Baris bawah
    _out(f"  {t.ACCENT}{line}{t.RESET}")
    _out()


def print_prompt(msg: str) -> str:
    """
    Print prompt untuk input user (tanpa newline).
    Return string kosong — cuma buat visual.

    Catatan: gunakan ui.prompt._prompt() buat input beneran.
    """
    t = get_theme()
    _out(f"  {t.ACCENT}→{t.RESET}  {msg}", end="")
    return ""


def print_blank():
    """Print baris kosong."""
    _out()


# ============================================================
# PUBLIC API — ANIMASI LOADING
# ============================================================

def print_loading(msg: str, show_elapsed: bool = True):
    """Spinner context manager shortcut.

    Contoh:
        with printer.print_loading("Scanning files"):
            do_something()
    """
    from .spinner import Spinner
    return Spinner(msg, show_elapsed=show_elapsed)


def print_progress(msg: str, total: int = None, width: int = 30):
    """Progress bar context manager shortcut.

    Contoh:
        with printer.print_progress("Hashing", total=100) as p:
            for i, f in enumerate(files):
                hash_one(f)
                p.update(i + 1)
    """
    from .spinner import Progress
    return Progress(msg, total=total, width=width)


def print_step(msg: str, indent: int = 2):
    """Print step tanpa animasi — buat operasi cepet."""
    from .spinner import step
    step(msg, indent=indent)


# ============================================================
# PUBLIC API — VERDICT & CARD
# ============================================================

def print_verdict(title: str, ok: bool, details: dict = None):
    """Print verdict box — buat hasil Verify, Restore, dll.

    Args:
        title   : judul verdict (misal "VERDICT")
        ok      : True = hijau (OK), False = merah (FAIL)
        details : dict {label: value} — ditampilin di bawah verdict

    Contoh:
        printer.print_verdict(
            "VERIFY",
            ok=True,
            details={"Files": "36 cocok", "Hash root": "4697967f..."}
        )
    """
    t = get_theme()

    if ok:
        icon = "✓"
        color = t.GREEN
        status_text = "OK"
    else:
        icon = "✗"
        color = t.RED
        status_text = "FAIL"

    line = "═" * 56

    _out()
    _out(f"  {color}{line}{t.RESET}")
    _out(f"  {color}{icon}{t.RESET}  {t.BOLD}{t.WHITE}{title}{t.RESET}  {color}· {status_text}{t.RESET}")
    _out(f"  {color}{line}{t.RESET}")

    if details:
        _out()
        for key, value in details.items():
            _out(f"  {t.ACCENT_DIM}{key}{t.RESET}:  {t.WHITE}{value}{t.RESET}")

    _out()


def print_card(title: str, items: dict, icon: str = None, color: str = None):
    """Print card style — buat preview / summary.

    Args:
        title : judul card
        items : dict {label: value}
        icon  : emoji optional
        color : color override (default: ACCENT)

    Contoh:
        printer.print_card(
            "Preview Backup",
            {
                "Project": "semut",
                "Version": "v0.3.1",
                "Mode": "clean",
                "Files": "36 file",
                "Size": "640.3 KB",
            },
            icon="👁"
        )
    """
    t = get_theme()
    if color is None:
        color = t.ACCENT

    icon_str = f"{icon}  " if icon else ""

    # Hitung lebar border
    max_key_len = max((len(str(k)) for k in items.keys()), default=0)
    max_val_len = max((len(str(v)) for v in items.values()), default=0)
    content_width = max_key_len + 2 + max_val_len
    width = max(40, min(content_width + 4, 60))

    # Card dibatasi 60 kolom. Potong value agar output tetap satu baris.
    value_budget = max(10, width - max_key_len - 8)
    key_budget = max(8, min(max_key_len, 24))

    def _truncate(value, limit):
        value = str(value)
        if len(value) <= limit:
            return value
        if limit <= 3:
            return value[:limit]
        return value[:limit - 3] + "..."

    _out()
    # Top border
    title_line = f"{icon_str}{title}"
    fill = max(0, width - len(title_line) - 3)
    _out(f"  {color}┌─ {t.BOLD}{t.WHITE}{title_line}{t.RESET}{color} {'─' * fill}┐{t.RESET}")

    # Items
    for key, value in items.items():
        key_str = _truncate(key, key_budget)
        val_str = _truncate(value, value_budget)
        pad = " " * max(0, key_budget - len(key_str))
        _out(
            f"  {color}│{t.RESET}  "
            f"{t.ACCENT_DIM}{key_str}{t.RESET}{pad}  "
            f"{t.WHITE}{val_str}{t.RESET}"
        )

    # Bottom border
    _out(f"  {color}└{'─' * width}┘{t.RESET}")
    _out()


# ============================================================
# SELF-TEST (jalanin: python3 -m ui.printer)
# ============================================================

if __name__ == "__main__":
    import time

    print()
    print_banner("semut", subtitle="toolbox lokal — gak butuh pihak ke-3", version="0.1.0")

    print_section("Sample Output", icon="📄")

    print_success("Operasi berhasil — 42 file di-hash")
    print_error("Gagal buka file: permission denied")
    print_warn("3 file di-skip karena path invalid")
    print_info("Scanning folder: /storage/emulated/0/Project")
    print_blank()

    print_bullet("Item pertama")
    print_bullet("Item kedua dengan indent lebih", indent=6)
    print_blank()

    print_arrow("Ini arrow point")
    print_numbered(1, "Pilihan pertama")
    print_numbered(2, "Pilihan kedua")
    print_blank()

    print_kv("Nama project", "semut")
    print_kv("Versi", "v0.1.0")
    print_kv("Author", "@nexterade")
    print_blank()

    print_separator()
    print_blank()

    print_status("Status: sukses", status="success")
    print_status("Status: warning", status="warn")
    print_status("Status: error", status="error")
    print_status("Status: info", status="info")
    print_status("Status: ghost", status="ghost")
    print_blank()

    # Test verdict
    print_section("Test: Verdict", icon="✓")
    print_verdict(
        "VERIFY",
        ok=True,
        details={"Files": "36 cocok", "Hash root": "4697967f7847"},
    )
    print_verdict(
        "VERIFY",
        ok=False,
        details={"Files": "30 cocok, 6 beda", "Hash root": "abcd1234"},
    )

    # Test card
    print_section("Test: Card", icon="👁")
    print_card(
        "Preview Backup",
        {
            "Project": "semut",
            "Version": "v0.3.1",
            "Mode": "clean",
            "Files": "36 file",
            "Size": "640.3 KB",
            "Hash root": "4697967f7847",
        },
        icon="👁",
    )

    # Test animasi
    print_section("Test: Animasi Loading", icon="⠋")
    with print_loading("Scanning files"):
        time.sleep(1.2)

    print_blank()
    with print_progress("Hashing files", total=30) as p:
        for i in range(30):
            time.sleep(0.02)
            p.update(i + 1)

    print_blank()
    print_step("Langkah pertama")
    print_step("Langkah kedua")
    print_blank()

    t = get_theme()
    print(f"  {t.ACCENT_DIM}Warna: {'ON' if t.enabled else 'OFF'}{t.RESET}")
    print()