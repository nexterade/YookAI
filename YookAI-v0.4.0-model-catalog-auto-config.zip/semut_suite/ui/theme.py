"""ui/theme.py — Tema warna CLI Semut.

Midnight adalah tema CLI default Semut. Semua warna di sini adalah ANSI untuk terminal.
"""

import os
import sys


def _rgb(r, g, b):
    return f"\033[38;2;{r};{g};{b}m"


class C:
    """Semantic ANSI colors — Midnight palette."""

    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"
    UNDER = "\033[4m"

    # Midnight palette: cool blue text over the terminal's dark background.
    BLACK = "\033[30m"
    RED = _rgb(251, 113, 133)
    GREEN = _rgb(74, 222, 128)
    YELLOW = _rgb(251, 191, 36)
    BLUE = _rgb(96, 165, 250)
    MAGENTA = _rgb(192, 132, 252)
    CYAN = _rgb(34, 211, 238)
    WHITE = _rgb(226, 232, 240)

    BR_BLACK = "\033[90m"
    BR_RED = _rgb(251, 113, 133)
    BR_GREEN = _rgb(74, 222, 128)
    BR_YELLOW = _rgb(251, 191, 36)
    BR_BLUE = _rgb(96, 165, 250)
    BR_MAGENTA = _rgb(192, 132, 252)
    BR_CYAN = _rgb(34, 211, 238)
    BR_WHITE = _rgb(248, 250, 252)

    ACCENT = _rgb(125, 211, 252)       # #7DD3FC
    ACCENT_DIM = _rgb(56, 189, 248)    # #38BDF8
    GRAY = _rgb(148, 163, 184)         # #94A3B8
    GRAY_DIM = "\033[2m" + _rgb(100, 116, 139)


class Theme:
    """Wrapper that can disable ANSI output for non-color environments."""

    name = "midnight"

    def __init__(self, enabled=None):
        if enabled is None:
            enabled = _supports_color()
        self.enabled = enabled
        self._cache = {}

    def _get(self, name):
        if name in self._cache:
            return self._cache[name]
        value = getattr(C, name, "") if self.enabled else ""
        self._cache[name] = value
        return value

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return self._get(name)


def _supports_color():
    """Detect ANSI support while respecting NO_COLOR/FORCE_COLOR."""
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("FORCE_COLOR"):
        return True
    if not hasattr(sys.stdout, "isatty") or not sys.stdout.isatty():
        return False
    if sys.platform == "win32":
        return bool(os.environ.get("WT_SESSION") or os.environ.get("TERM"))
    return True


_theme_instance = None


def get_theme():
    """Return the global Midnight theme instance."""
    global _theme_instance
    if _theme_instance is None:
        _theme_instance = Theme()
    return _theme_instance


def set_theme(enabled):
    """Enable/disable ANSI output; palette remains Midnight."""
    global _theme_instance
    _theme_instance = Theme(enabled=enabled)


def theme_supported():
    return get_theme().enabled


if __name__ == "__main__":
    t = get_theme()
    print("=" * 60)
    print("  SEMUT CLI THEME SELF-TEST — MIDNIGHT")
    print("=" * 60)
    print(f"  Theme          : {t.name}")
    print(f"  Support warna  : {t.enabled}")
    print(f"  NO_COLOR       : {os.environ.get('NO_COLOR', '(unset)')}")
    print(f"  FORCE_COLOR    : {os.environ.get('FORCE_COLOR', '(unset)')}")
    print()
    for name in ("ACCENT", "ACCENT_DIM", "WHITE", "GRAY", "GREEN", "RED", "YELLOW", "CYAN", "MAGENTA"):
        print(f"  {getattr(t, name)}{name:<12}{t.RESET}")
