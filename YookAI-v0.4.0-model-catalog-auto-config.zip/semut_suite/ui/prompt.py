"""
ui/prompt.py — Prompt & Input Helper Terpusat

Bungkus input() standar dengan:
- Prompt visual rapi (via ui.printer)
- Deteksi cancel otomatis (0/q/quit/batal/exit)
- Default value
- Yes/No confirmation
- Pilih dari list
- Input multi-line

Filosofi:
    - Semua input user WAJIB lewat sini.
    - Cancel sentinel: return "__CANCEL__" — biar caller bisa deteksi.
    - Jangan pakai input() mentah di tool.
"""

import sys
from .theme import get_theme
from . import printer


# ============================================================
# CONSTANTS
# ============================================================

CANCEL_SENTINEL = "__CANCEL__"

CANCEL_WORDS = {
    "0", "q", "quit", "cancel", "batal", "exit", "keluar", "back", "kembali",
}


# ============================================================
# INTERNAL HELPERS
# ============================================================

def _is_cancel(text: str) -> bool:
    """Cek apakah input user = cancel."""
    return text.strip().lower() in CANCEL_WORDS


def _build_hint(default: str = "", show_cancel: bool = True) -> str:
    """
    Build hint string buat prompt.
    Format: [default: X, 0=batal] atau [0=batal] atau [default: X]
    """
    t = get_theme()
    parts = []

    if default != "":
        parts.append(f"default: {default}")

    if show_cancel:
        parts.append("0=batal")

    if not parts:
        return ""

    hint_text = ", ".join(parts)
    return f" {t.GRAY}[{hint_text}]{t.RESET}"


# ============================================================
# PUBLIC API
# ============================================================

def prompt_input(
    label: str,
    default: str = "",
    show_cancel: bool = True,
    allow_empty: bool = False,
) -> str:
    """
    Prompt input teks biasa.

    Args:
        label       : label yang ditampilin
        default     : nilai default kalau user kosongin
        show_cancel : tampilin hint "0=batal"
        allow_empty : kalau True, kosong = return ""

    Returns:
        - String input user
        - CANCEL_SENTINEL ("__CANCEL__") kalau user ketik 0/q/batal
        - "" kalau allow_empty=True & user kosong
        - default kalau user kosong & default != ""
    """
    t = get_theme()
    hint = _build_hint(default, show_cancel)

    try:
        if t.enabled:
            raw = input(f"  {t.ACCENT}→{t.RESET}  {t.WHITE}{label}{t.RESET}{hint}: ").strip()
        else:
            raw = input(f"  →  {label}{hint}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        printer.print_warn("Input di-cancel (Ctrl+C / EOF).")
        return CANCEL_SENTINEL

    # Cek cancel
    if show_cancel and _is_cancel(raw):
        return CANCEL_SENTINEL

    # Empty input
    if raw == "":
        if allow_empty:
            return ""
        if default != "":
            return default
        # Gak ada default, gak allow empty → minta ulang?
        # Untuk simpelnya, return default kosong aja
        return ""

    return raw


def prompt_yes_no(label: str, default: str = "y") -> bool:
    """
    Prompt konfirmasi Yes/No.

    Args:
        label   : pertanyaan yang ditampilin
        default : "y" atau "n" (default: "y")

    Returns:
        True kalau user jawab y/ya/yes
        False kalau user jawab n/no/tidak/engga/gak
    """
    t = get_theme()
    default = default.strip().lower()
    if default not in ("y", "n"):
        default = "y"

    # Build hint
    if default == "y":
        choices = f"{t.BOLD}Y{t.RESET}{t.GRAY}/n{t.RESET}"
    else:
        choices = f"{t.GRAY}y/{t.RESET}{t.BOLD}N{t.RESET}"

    try:
        if t.enabled:
            raw = input(
                f"  {t.ACCENT}→{t.RESET}  {t.WHITE}{label}{t.RESET} "
                f"{t.GRAY}[{t.RESET}{choices}{t.GRAY}]{t.RESET}: "
            ).strip().lower()
        else:
            raw = input(f"  →  {label} [{default.upper()}]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        printer.print_warn("Input di-cancel (Ctrl+C / EOF).")
        return default == "y"

    if raw == "":
        raw = default

    return raw in ("y", "yes", "ya", "ye", "yup", "iya")


def prompt_choice(label: str, choices: list, default_index: int = 0) -> int:
    """
    Prompt pilihan dari list.

    Args:
        label         : label yang ditampilin
        choices       : list of string (opsi)
        default_index : index default (0-based)

    Returns:
        Index pilihan user (0-based)
        -1 kalau user cancel
    """
    t = get_theme()

    if not choices:
        printer.print_error("Gak ada pilihan yang tersedia.")
        return -1

    # Tampilin pilihan
    printer.print_blank()
    for idx, choice in enumerate(choices, 1):
        printer.print_numbered(idx, choice)
    printer.print_blank()

    default_str = str(default_index + 1)
    hint = f" {t.GRAY}[1-{len(choices)}, default: {default_str}, 0=batal]{t.RESET}"

    try:
        if t.enabled:
            raw = input(
                f"  {t.ACCENT}→{t.RESET}  {t.WHITE}{label}{t.RESET}{hint}: "
            ).strip()
        else:
            raw = input(f"  →  {label} [1-{len(choices)}, default: {default_str}, 0=batal]: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        printer.print_warn("Input di-cancel (Ctrl+C / EOF).")
        return -1

    if _is_cancel(raw):
        return -1

    if raw == "":
        return default_index

    if raw.isdigit():
        idx = int(raw)
        if 1 <= idx <= len(choices):
            return idx - 1

    printer.print_warn(f"Pilihan '{raw}' gak valid. Pake default.")
    return default_index


def prompt_multiline(label: str, terminator: str = "EOF") -> str:
    """
    Prompt input multi-line.

    User ketik beberapa baris, akhiri dengan ketik `terminator`
    di baris baru (default: "EOF").

    Args:
        label      : label yang ditampilin
        terminator : string yang nandain akhir input

    Returns:
        String multi-line (digabung dengan \\n)
        CANCEL_SENTINEL kalau user batal
    """
    t = get_theme()

    printer.print_blank()
    printer.print_info(f"Ketik '{terminator}' di baris baru buat selesai. '0' buat batal.")

    lines = []

    try:
        if t.enabled:
            print(f"  {t.ACCENT}→{t.RESET}  {t.WHITE}{label}{t.RESET}:")
        else:
            print(f"  →  {label}:")

        while True:
            if t.enabled:
                line = input(f"  {t.GRAY}│{t.RESET}  ")
            else:
                line = input("  |  ")

            if line.strip() == terminator:
                break

            if line.strip().lower() in CANCEL_WORDS:
                printer.print_warn("Dibatalkan.")
                return CANCEL_SENTINEL

            lines.append(line)

    except (EOFError, KeyboardInterrupt):
        print()
        printer.print_warn("Input di-cancel (Ctrl+C / EOF).")
        return CANCEL_SENTINEL

    return "\n".join(lines)


def prompt_password(label: str = "Password") -> str:
    """
    Prompt password (input gak keliatan di layar).

    Pake getpass kalau tersedia, fallback ke input biasa.

    Returns:
        String password
        CANCEL_SENTINEL kalau user batal
    """
    import getpass

    t = get_theme()

    try:
        if t.enabled:
            password = getpass.getpass(f"  {t.ACCENT}🔒{t.RESET}  {t.WHITE}{label}{t.RESET}: ")
        else:
            password = getpass.getpass(f"  [locked]  {label}: ")
    except (EOFError, KeyboardInterrupt):
        print()
        printer.print_warn("Input di-cancel.")
        return CANCEL_SENTINEL
    except Exception:
        # Fallback kalau getpass gak support di environment
        try:
            if t.enabled:
                password = input(f"  {t.ACCENT}🔒{t.RESET}  {t.WHITE}{label}{t.RESET} (visible): ")
            else:
                password = input(f"  {label} (visible): ")
        except (EOFError, KeyboardInterrupt):
            print()
            return CANCEL_SENTINEL

    if _is_cancel(password):
        return CANCEL_SENTINEL

    return password


def prompt_path(label: str = "Path", must_exist: bool = False) -> str:
    """
    Prompt path file/folder dengan validasi opsional.

    Args:
        label      : label yang ditampilin
        must_exist : kalau True, cek path harus ada

    Returns:
        String path
        CANCEL_SENTINEL kalau user batal
    """
    import os

    raw = prompt_input(label, show_cancel=True)

    if raw == CANCEL_SENTINEL:
        return CANCEL_SENTINEL

    if not raw:
        return raw

    # Expand ~ jadi home dir
    raw = os.path.expanduser(raw)

    if must_exist and not os.path.exists(raw):
        printer.print_error(f"Path gak ada: {raw}")
        return CANCEL_SENTINEL

    return raw


def is_cancelled(value: str) -> bool:
    """Cek apakah hasil prompt adalah cancel sentinel."""
    return value == CANCEL_SENTINEL


# ============================================================
# SELF-TEST (jalanin: python3 -m ui.prompt)
# ============================================================

if __name__ == "__main__":
    printer.print_banner("semut", subtitle="prompt.py — self-test", version="0.1.0")

    printer.print_section("Test 1: prompt_input", icon="📝")
    result = prompt_input("Masukkan nama project", default="semut")
    printer.print_kv("Hasil", repr(result))
    printer.print_kv("Cancel?", str(is_cancelled(result)))

    printer.print_section("Test 2: prompt_yes_no", icon="❓")
    result = prompt_yes_no("Lanjut ke test berikutnya?", default="y")
    printer.print_kv("Hasil", str(result))

    printer.print_section("Test 3: prompt_choice", icon="📋")
    idx = prompt_choice(
        "Pilih tool",
        choices=["Tree Printer", "Ghost Grep", "File Hasher", "Backup Rotator"],
        default_index=0,
    )
    if idx == -1:
        printer.print_warn("User cancel.")
    else:
        printer.print_kv("Index terpilih", str(idx))
        printer.print_kv("Nama tool", ["Tree Printer", "Ghost Grep", "File Hasher", "Backup Rotator"][idx])

    printer.print_section("Test 4: prompt_password", icon="🔒")
    pw = prompt_password("Password test")
    if is_cancelled(pw):
        printer.print_warn("User cancel.")
    else:
        printer.print_kv("Panjang password", str(len(pw)))

    printer.print_section("Test 5: prompt_path", icon="📁")
    path = prompt_path("Masukkan path folder", must_exist=False)
    printer.print_kv("Hasil", repr(path))

    printer.print_blank()
    printer.print_success("Semua test selesai!")
    printer.print_blank()