"""
ui/spinner.py — Animasi loading untuk tool Semut (v1.4)

Menyediakan:
    - Spinner       : animasi putar (pake \r, works di Termux)
    - Progress      : satu baris dinamis (update in-place di TTY)
    - auto_progress : auto-detect Spinner vs Progress berdasarkan total
    - step()        : helper step-by-step tanpa animasi

Filosofi:
    User harus tau sistem lagi kerja, bukan nge-freeze.
    Animasi harus ringan & RELIABLE — gak boleh bikin bug.

v1.4 changes:
    - Progress satu baris dinamis, agar log Termux tetap ringkas.

v1.3 changes:
    - Truncate message di Progress (max 25 char) — biar gak wrap
    - Tambah konstanta PROGRESS_MSG_MAX

v1.2 changes:
    - Progress sebelumnya memakai milestone print; kini update in-place.

Aturan Auto-Detect:
    - total <= 50  → Spinner + counter live
    - total > 50   → Progress bar satu baris dinamis
    - total=None   → Spinner biasa (tanpa counter)

Catatan:
    - Kalau theme disabled (no ANSI), spinner & progress tetap jalan
      tapi tanpa warna.
    - Kalau stdout bukan TTY, animasi otomatis di-skip.
"""

import sys
import time
import os

from .theme import get_theme


# ============================================================
# CONSTANTS
# ============================================================

SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

SPINNER_INTERVAL = 0.08  # detik antar frame

PROGRESS_FILL = "█"
PROGRESS_EMPTY = "░"
PROGRESS_WIDTH = 30  # fallback minimum-ish width; actual width is detected at runtime
PROGRESS_MSG_MAX = 30  # batas pesan progress

AUTO_SPINNER_MAX = 50  # total <= 50 pake Spinner, > 50 pake Progress


# ============================================================
# INTERNAL — TTY CHECK
# ============================================================

def _is_tty() -> bool:
    """Cek apakah stdout adalah terminal (bukan pipe/file)."""
    try:
        return sys.stdout.isatty()
    except (AttributeError, OSError):
        return False


def _detect_progress_width() -> int:
    """Pilih lebar progress bar sesuai terminal, dengan batas aman Termux."""
    try:
        columns = os.get_terminal_size().columns
    except OSError:
        columns = PROGRESS_WIDTH + 20
    # Sisakan ruang untuk indent, persen, counter, dan margin.
    return max(8, min(40, columns - 22))


# ============================================================
# SPINNER (tetep pake \r — works di Termux)
# ============================================================

class Spinner:
    """Spinner animasi — pakai context manager.

    Pake \\r buat update di tempat. Works di Termux karena
    spinner cuma render 1 baris pendek & gak pake f-string multi-line.

    Contoh:
        with Spinner("Hashing", total=20) as sp:
            for i, f in enumerate(files, 1):
                hash_one(f)
                sp.set(i)
    """

    def __init__(self, message: str, total: int = None, show_elapsed: bool = True):
        self.message = message
        self.total = total
        self.current = 0
        self.show_elapsed = show_elapsed
        self._start = 0.0
        self._frame_idx = 0
        self._last_render = 0.0
        self._enabled = _is_tty()
        self._finished = False

    def __enter__(self):
        self._start = time.time()
        self._last_render = 0.0
        self._frame_idx = 0
        self._finished = False
        if self._enabled:
            self._render()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop(ok=(exc_type is None))
        return False

    def _render(self):
        """Render frame spinner — cuma 1 baris, gak ada f-string multi-line.

        Sengaja dirakit dengan concatenation, bukan f-string multi-line: Termux
        lebih konsisten untuk carriage-return spinner saat output terminal sempit.
        """
        t = get_theme()
        frame = SPINNER_FRAMES[self._frame_idx % len(SPINNER_FRAMES)]
        self._frame_idx += 1

        if self.total:
            msg = self.message + " (" + str(self.current) + "/" + str(self.total) + ")"
        elif self.current > 0:
            msg = self.message + " (" + str(self.current) + ")"
        else:
            msg = self.message

        if t.enabled:
            line = "\r  " + t.ACCENT + frame + t.RESET + "  " + t.GRAY + msg + t.RESET
        else:
            line = "\r  " + frame + "  " + msg

        sys.stdout.write(line + " " * 5)
        self._finished = True
        sys.stdout.flush()

    def set(self, current: int):
        """Set current counter — render langsung."""
        self.current = current
        if self._enabled and not self._finished:
            self._render()
            self._last_render = time.time()

    def tick(self, step: int = 1):
        """Increment counter."""
        self.current += step
        if not self._enabled or self._finished:
            return
        now = time.time()
        if now - self._last_render >= SPINNER_INTERVAL:
            self._render()
            self._last_render = now

    # ---- API unifikasi (kompatibel sama Progress) ----
    # auto_progress() bisa return Spinner ATAU Progress. Biar caller
    # gak peduli dapet yang mana, dua-duanya dukung .update()/.done()
    # sekaligus .set()/.stop().

    def update(self, current: int = None, step: int = 1):
        """Alias Progress.update() — set/increment counter."""
        if current is not None:
            self.set(current)
        else:
            self.tick(step)

    def done(self, ok: bool = True):
        """Alias Progress.done() — selesaikan spinner."""
        self.stop(ok)

    def stop(self, ok: bool = True):
        """Stop spinner, print status akhir."""
        if self._finished:
            return
        self._finished = True

        elapsed = time.time() - self._start
        t = get_theme()

        if self._enabled:
            sys.stdout.write("\r" + " " * 80 + "\r")

        if self.total:
            final_msg = self.message + " — " + str(self.total) + " file"
        elif self.current > 0:
            final_msg = self.message + " — " + str(self.current) + " item"
        else:
            final_msg = self.message

        if t.enabled:
            icon = t.GREEN + "✓" + t.RESET if ok else t.RED + "✗" + t.RESET
            if self.show_elapsed:
                sys.stdout.write("  " + icon + "  " + final_msg + " " + t.GRAY + "(" + f"{elapsed:.2f}s" + ")" + t.RESET + "\n")
            else:
                sys.stdout.write("  " + icon + "  " + final_msg + "\n")
        else:
            icon = "✓" if ok else "✗"
            if self.show_elapsed:
                sys.stdout.write("  " + icon + "  " + final_msg + " (" + f"{elapsed:.2f}s" + ")\n")
            else:
                sys.stdout.write("  " + icon + "  " + final_msg + "\n")
        sys.stdout.flush()


# ============================================================
# PROGRESS — SINGLE-LINE DYNAMIC BAR
# ============================================================

class Progress:
    """Progress bar ringkas yang diperbarui pada baris terminal yang sama."""

    def __init__(self, message: str, total: int = None, width: int = None):
        self.message = message
        self.total = total
        self.width = width if width is not None else _detect_progress_width()
        self.current = 0
        self._start = time.time()
        self._enabled = _is_tty()
        self._finished = False

    def __enter__(self):
        self._start = time.time()
        self.current = 0
        self._finished = False
        self._render()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.done(ok=(exc_type is None))
        return False

    def _render(self):
        if not self._enabled or self._finished:
            return
        t = get_theme()
        total = max(1, int(self.total or 1))
        current = min(max(0, self.current), total)
        pct = min(100, int(current * 100 / total))
        columns = max(20, _terminal_columns())
        # Reserve space for indentation, brackets, percentage, counter and a gap.
        # On very narrow Termux screens the bar shrinks before the status text wraps.
        bar_width = max(4, min(self.width, columns - 18))
        filled = int(bar_width * pct / 100)
        bar = PROGRESS_FILL * filled + PROGRESS_EMPTY * (bar_width - filled)
        suffix = f" {pct:3d}% {current}/{self.total or '?'}"
        available = max(0, columns - bar_width - len(suffix) - 7)
        msg = self.message
        if len(msg) > available:
            msg = msg[:max(0, available - 3)] + ("..." if available >= 3 else "")
        if t.enabled:
            line = "  " + t.ACCENT + "[" + bar + "]" + t.RESET + t.GRAY + suffix + " " + msg + t.RESET
        else:
            line = "  [" + bar + "]" + suffix + " " + msg
        sys.stdout.write("\r\033[2K" + line)
        sys.stdout.flush()

    def update(self, current: int = None, step: int = 1):
        if current is not None:
            self.current = current
        else:
            self.current += step
        if self.total:
            self.current = min(self.current, self.total)
        self._render()

    def tick(self, step: int = 1):
        self.update(step=step)

    def set_total(self, total: int):
        self.total = total
        self._render()

    def done(self, ok: bool = True):
        if self._finished:
            return
        elapsed = time.time() - self._start
        t = get_theme()
        if self._enabled:
            # Keep the completed bar as a durable history line instead of
            # erasing it. A successful operation ends at 100%; failed work
            # retains its last measured percentage for troubleshooting.
            if ok and self.total:
                self.current = self.total
            self._render()
            sys.stdout.write("\n")
        else:
            total = self.total if self.total is not None else self.current
            final_msg = self.message + " — " + str(total) + " file"
            icon = t.GREEN + "✓" + t.RESET if ok and t.enabled else (t.RED + "✗" + t.RESET if t.enabled else ("✓" if ok else "✗"))
            suffix = t.GRAY + f" ({elapsed:.2f}s)" + t.RESET if t.enabled else f" ({elapsed:.2f}s)"
            sys.stdout.write("  " + icon + "  " + final_msg + " " + suffix + "\n")
        self._finished = True
        sys.stdout.flush()

    def set(self, current: int):
        self.update(current)

    def stop(self, ok: bool = True):
        self.done(ok)


def _terminal_columns() -> int:
    try:
        return os.get_terminal_size().columns
    except OSError:
        return 80


# ============================================================
# AUTO-DETECT HELPER
# ============================================================

def auto_progress(message: str, total: int = None,
                  show_elapsed: bool = True):
    """Auto-detect Spinner vs Progress berdasarkan total.

    Aturan:
        - total <= 50  → Spinner + counter live
        - total > 50   → Progress bar satu baris dinamis
        - total=None   → Spinner biasa (tanpa counter)
    """
    if total is not None and total > AUTO_SPINNER_MAX:
        return Progress(message, total=total)
    return Spinner(message, total=total, show_elapsed=show_elapsed)


# ============================================================
# SIMPLE STEP HELPER
# ============================================================

def step(message: str, indent: int = 2):
    """Print step tanpa animasi."""
    t = get_theme()
    pad = " " * indent
    if t.enabled:
        sys.stdout.write(pad + t.ACCENT_DIM + "▸" + t.RESET + "  " + message + "\n")
    else:
        sys.stdout.write(pad + "▸  " + message + "\n")
    sys.stdout.flush()


# ============================================================
# SELF-TEST
# ============================================================

if __name__ == "__main__":
    from semut_suite.ui import printer

    printer.print_banner("semut", subtitle="spinner.py — self-test v1.4", version="0.1.0")

    printer.print_section("Test 1: Spinner biasa", icon="⠋")
    with Spinner("Scanning files"):
        time.sleep(1.0)
    printer.print_blank()

    printer.print_section("Test 2: Spinner dengan counter (total=20)", icon="⠙")
    with Spinner("Hashing files", total=20) as sp:
        for i in range(1, 21):
            time.sleep(0.03)
            sp.set(i)
    printer.print_blank()

    printer.print_section("Test 3: Progress bar (total=100, milestone 10%)", icon="📊")
    with Progress("Hashing files", total=100) as p:
        for i in range(1, 101):
            time.sleep(0.01)
            p.update(i)
    printer.print_blank()

    printer.print_section("Test 4: auto_progress (total=20 → Spinner)", icon="🤖")
    with auto_progress("Hashing 20 file", total=20) as p:
        for i in range(1, 21):
            time.sleep(0.03)
            p.set(i)
    printer.print_blank()

    printer.print_section("Test 5: auto_progress (total=100 → Progress)", icon="🤖")
    with auto_progress("Hashing 100 file", total=100) as p:
        for i in range(1, 101):
            time.sleep(0.01)
            p.update(i)
    printer.print_blank()

    printer.print_section("Test 6: auto_progress (total=None → Spinner)", icon="🤖")
    with auto_progress("Scanning files") as p:
        time.sleep(1.0)
    printer.print_blank()

    printer.print_section("Test 7: Step helper", icon="▸")
    step("Langkah pertama")
    step("Langkah kedua")
    step("Langkah ketiga")
    printer.print_blank()

    printer.print_success("Semua test selesai!")
    printer.print_blank()