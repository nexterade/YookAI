"""
tools/sync_remote.py — Sync folder lokal dengan folder mount remote.

Tool ini sengaja bekerja pada path filesystem hasil mount rclone. Python tidak
pernah menerima URL SMB secara langsung. Mode watch memakai polling stdlib,
jadi tidak butuh watchdog.
"""

import hashlib
import os
import shutil
import subprocess
import time
from pathlib import Path

from semut_suite.core.history import prompt_pair_with_history
from semut_suite.core.exclude import is_excluded
from semut_suite.ui import printer
from semut_suite.ui.spinner import auto_progress
from semut_suite.ui.prompt import prompt_choice, prompt_input, prompt_yes_no


TOOL_META = {
    "id": "sync_remote",
    "name": "Sync Remote",
    "desc": "Sync folder lokal dengan mount remote rclone",
    "category": "file",
    "icon": "🌐",
    "order": 8,
}

TOOL_ID = "sync_remote"
EXCLUDED_NAMES = {".path_history.json", "password_vault.enc", ".exclude.json"}
SKIP_DIRS = {".git", "__pycache__", "vault"}
DEFAULT_INTERVAL = 5


def _file_map(root: Path) -> dict:
    result = {}
    if not root.is_dir():
        return result
    for directory, dirnames, filenames in os.walk(root):
        current = Path(directory)
        rel_dir = current.relative_to(root).as_posix() if current != root else ""
        dirnames[:] = sorted(
            name for name in dirnames
            if name not in SKIP_DIRS and not is_excluded((rel_dir + "/" + name).strip("/"))
        )
        for filename in sorted(filenames):
            if filename in EXCLUDED_NAMES:
                continue
            path = Path(directory) / filename
            relative = path.relative_to(root).as_posix()
            if is_excluded(relative):
                continue
            result[relative] = path
    return result


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
        return digest.hexdigest()
    except OSError:
        return ""


def _validate_pair(source: str, target: str) -> tuple:
    source_path = Path(os.path.expanduser(source)).resolve()
    target_path = Path(os.path.expanduser(target)).resolve()
    if not source_path.is_dir():
        return None, None, "Folder lokal tidak ada atau tidak bisa dibaca."
    if not target_path.is_dir():
        return None, None, (
            "Folder remote belum ter-mount. Mount rclone dulu lalu jalankan "
            "ulang."
        )
    if source_path == target_path:
        return None, None, "Source dan target tidak boleh folder yang sama."
    try:
        target_path.relative_to(source_path)
        return None, None, "Target tidak boleh berada di dalam source."
    except ValueError:
        pass
    try:
        source_path.relative_to(target_path)
        return None, None, "Source tidak boleh berada di dalam target."
    except ValueError:
        pass
    return source_path, target_path, ""


def _copy(source: Path, target: Path) -> bool:
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        return True
    except OSError as error:
        printer.print_warn(f"Gagal copy {source.name}: {error}")
        return False


def _remove(path: Path) -> bool:
    try:
        path.unlink()
        return True
    except OSError as error:
        printer.print_warn(f"Gagal hapus {path.name}: {error}")
        return False


def _sync_one_way(source: Path, target: Path, mirror: bool = False) -> dict:
    source_files = _file_map(source)
    target_files = _file_map(target)
    stats = {
        "copied": 0,
        "deleted": 0,
        "unchanged": 0,
        "errors": 0,
    }

    total_items = len(source_files) + (len(target_files) if mirror else 0)
    progress = auto_progress("Syncing files", total=total_items)
    progress.__enter__()
    for item_index, (relative, source_file) in enumerate(source_files.items(), 1):
        progress.update(item_index)
        target_file = target / relative
        if (
            relative not in target_files
            or _hash_file(source_file) != _hash_file(target_file)
        ):
            if _copy(source_file, target_file):
                stats["copied"] += 1
            else:
                stats["errors"] += 1
        else:
            stats["unchanged"] += 1

    if mirror:
        for mirror_index, (relative, target_file) in enumerate(target_files.items(), 1):
            progress.update(len(source_files) + mirror_index)
            if relative not in source_files and _remove(target_file):
                stats["deleted"] += 1

    progress.done()
    return stats


def _conflict_path(path: Path) -> Path:
    timestamp = time.strftime("%Y%m%d_%H%M%S", time.localtime())
    candidate = path.with_name(
        "{}.conflict-{}{}".format(
            path.stem,
            timestamp,
            path.suffix,
        )
    )
    index = 2
    while candidate.exists():
        candidate = path.with_name(
            "{}.conflict-{}-{}{}".format(
                path.stem,
                timestamp,
                index,
                path.suffix,
            )
        )
        index += 1
    return candidate


def _sync_bidirectional(source: Path, target: Path) -> dict:
    source_files = _file_map(source)
    target_files = _file_map(target)
    stats = {
        "copied": 0,
        "conflicts": 0,
        "unchanged": 0,
        "errors": 0,
    }

    all_paths = sorted(set(source_files) | set(target_files))
    progress = auto_progress("Syncing files", total=len(all_paths))
    progress.__enter__()
    for item_index, relative in enumerate(all_paths, 1):
        progress.update(item_index)
        source_file = source_files.get(relative)
        target_file = target_files.get(relative)
        if source_file is None:
            if _copy(target_file, source / relative):
                stats["copied"] += 1
            else:
                stats["errors"] += 1
            continue
        if target_file is None:
            if _copy(source_file, target / relative):
                stats["copied"] += 1
            else:
                stats["errors"] += 1
            continue

        source_hash = _hash_file(source_file)
        target_hash = _hash_file(target_file)
        if source_hash == target_hash:
            stats["unchanged"] += 1
            continue

        conflict = _conflict_path(target_file)
        if not _copy(target_file, conflict):
            stats["errors"] += 1
            continue
        if _copy(source_file, target_file):
            stats["conflicts"] += 1
        else:
            stats["errors"] += 1

    progress.done()
    return stats


def _print_stats(stats: dict):
    for key, value in stats.items():
        printer.print_kv(key.capitalize(), str(value))


def _mount_status():
    """Cek remote rclone + listing/read + filesystem mount."""
    if shutil.which("rclone") is None:
        printer.print_warn("rclone belum tersedia di environment ini.")
        printer.print_info("Di Termux install dengan: pkg install rclone")
        return {"ok": False, "error": "rclone tidak tersedia"}

    remote = prompt_input("Nama remote rclone", default="Nexter-Cloud:")
    if not remote:
        return {"ok": False, "error": "remote kosong"}
    remote = remote.strip()
    mount_path = prompt_input(
        "Mount point",
        default=os.path.expanduser("~/smb/nexter"),
    )
    if not mount_path:
        return {"ok": False, "error": "mount point kosong"}

    result = {
        "ok": False,
        "remote": remote,
        "mount": os.path.expanduser(mount_path),
        "remote_connection": False,
        "remote_read": False,
        "mount_read": False,
    }

    # 1) Koneksi remote: lsd memaksa rclone menghubungi backend.
    try:
        proc = subprocess.run(
            ["rclone", "lsd", remote],
            capture_output=True,
            text=True,
            timeout=20,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        printer.print_error(f"Gagal menjalankan rclone lsd: {exc}")
        return result

    if proc.returncode == 0:
        result["remote_connection"] = True
        printer.print_success(f"Remote terhubung: {remote}")
    else:
        detail = (proc.stderr or proc.stdout).strip().splitlines()
        printer.print_error(
            "Remote gagal diakses: " + (detail[-1] if detail else "error tidak diketahui")
        )

    # 2) Read test remote: ambil satu file lalu baca 1 byte/line.
    if result["remote_connection"]:
        try:
            listing = subprocess.run(
                ["rclone", "lsf", remote, "--max-depth", "1", "--files-only", "--format", "p"],
                capture_output=True,
                text=True,
                timeout=20,
            )
            remote_file = next((x.strip() for x in listing.stdout.splitlines() if x.strip()), "")
            if remote_file:
                remote_target = remote.rstrip("/") + "/" + remote_file.lstrip("/")
                read_proc = subprocess.run(
                    ["rclone", "cat", remote_target, "--head", "1"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE,
                    timeout=20,
                )
                if read_proc.returncode == 0:
                    result["remote_read"] = True
                    printer.print_success(f"Remote read test OK: {remote_file}")
                else:
                    printer.print_warn("Remote terhubung, tetapi read test gagal.")
            else:
                printer.print_info("Remote kosong / tidak ada file level-1 untuk read test.")
        except (OSError, subprocess.SubprocessError) as exc:
            printer.print_warn(f"Remote read test gagal: {exc}")

    # 3) Test filesystem hasil mount.
    mount = Path(os.path.expanduser(mount_path))
    if not mount.is_dir():
        printer.print_warn(f"Mount point belum tersedia: {mount}")
        result["ok"] = result["remote_connection"]
        return result

    printer.print_success(f"Mount point tersedia: {mount}")
    try:
        entries = list(mount.iterdir())
        printer.print_info(f"{len(entries)} entry terlihat di mount point.")
        for entry in entries:
            if entry.is_file():
                with entry.open("rb") as fh:
                    fh.read(1)
                result["mount_read"] = True
                printer.print_success(f"Mount read test OK: {entry.name}")
                break
        if not result["mount_read"]:
            # Folder kosong tetap valid untuk koneksi mount; tidak ada file untuk dibaca.
            result["mount_read"] = bool(entries)
            if not entries:
                printer.print_info("Mount kosong — read test file dilewati.")
    except OSError as exc:
        printer.print_warn(f"Mount ada tetapi read test gagal: {exc}")

    result["ok"] = result["remote_connection"] and (result["remote_read"] or not result["remote_connection"] is True or result["mount_read"])
    printer.print_info(
        "Status: remote={} · remote-read={} · mount-read={}".format(
            "OK" if result["remote_connection"] else "FAIL",
            "OK" if result["remote_read"] else "FAIL/SKIP",
            "OK" if result["mount_read"] else "FAIL/SKIP",
        )
    )
    return result


def _choose_pair():
    source, target = prompt_pair_with_history(
        "Path folder LOCAL / SOURCE",
        "Path folder MOUNTED REMOTE / TARGET",
        TOOL_ID,
    )
    if not source or not target:
        printer.print_warn("Dibatalkan.")
        return None, None
    source_path, target_path, error = _validate_pair(source, target)
    if error:
        printer.print_error(error)
        return None, None
    return source_path, target_path


def _run_manual():
    source, target = _choose_pair()
    if source is None:
        return
    mode = prompt_choice(
        "Mode sync manual",
        [
            "Safe: source → target, tidak menghapus file target",
            "Mirror: source → target, hapus file ekstra di target",
            "Bidirectional: dua arah, konflik disimpan sebagai copy",
        ],
    )
    if mode < 0:
        return
    if mode == 1:
        printer.print_warn(
            "Mirror akan menghapus file target yang tidak ada di source."
        )
        if not prompt_yes_no("Lanjut mirror?", default="n"):
            printer.print_warn("Dibatalkan.")
            return

    if mode == 0:
        stats = _sync_one_way(source, target, mirror=False)
    elif mode == 1:
        stats = _sync_one_way(source, target, mirror=True)
    else:
        stats = _sync_bidirectional(source, target)
    _print_stats(stats)
    printer.print_success("Sync selesai.")


def _run_watch(bidirectional: bool):
    source, target = _choose_pair()
    if source is None:
        return
    interval_raw = prompt_input("Interval polling (detik)", default=str(DEFAULT_INTERVAL))
    try:
        interval = max(1, int(interval_raw))
    except (TypeError, ValueError):
        interval = DEFAULT_INTERVAL
    printer.print_success(
        "Watch aktif. Tekan Ctrl+C untuk berhenti."
    )
    try:
        while True:
            stats = (
                _sync_bidirectional(source, target)
                if bidirectional
                else _sync_one_way(source, target, mirror=False)
            )
            changed = stats.get("copied", 0) + stats.get("deleted", 0)
            changed += stats.get("conflicts", 0)
            if changed:
                printer.print_info(
                    "Perubahan ter-sync: {} file.".format(changed)
                )
            time.sleep(interval)
    except KeyboardInterrupt:
        printer.print_blank()
        printer.print_success("Watch dihentikan.")


def run_cli(args):
    """Mode non-interaktif minimal untuk cek rclone mount."""
    if args and args[0] in ("status", "mount-status"):
        _mount_status()
        return 0
    printer.print_error("Argumen CLI tidak dikenal.")
    return 1



# ============================================================
# API MODE (PR-09)
# ============================================================
def _do_work(params=None):
    params=params or {}; source=str(params.get("source") or ""); target=str(params.get("target") or ""); action=str(params.get("action","sync"))
    if not source or not target: return {"ok":False,"error":"source dan target wajib diisi"}
    src,dst,err=_validate_pair(source,target)
    if err: return {"ok":False,"error":err}
    if action=="sync": return {"ok":True,"action":action,"result":_sync_one_way(src,dst,bool(params.get("mirror",False)))}
    if action=="bidirectional": return {"ok":True,"action":action,"result":_sync_bidirectional(src,dst)}
    if action=="map": return {"ok":True,"action":action,"source":str(src),"target":str(dst),"source_files":len(_file_map(src)),"target_files":len(_file_map(dst))}
    return {"ok":False,"error":f"action tidak dikenal: {action}"}

def run_api(params=None): return _do_work(params)

def run_wizard():
    printer.print_info("Sync Remote memakai folder hasil mount rclone.")
    choice = prompt_choice(
        "Pilih mode",
        [
            "Sync manual",
            "Watch satu arah: local → remote",
            "Watch bidirectional",
            "Cek status / panduan mount rclone",
        ],
    )
    if choice == 0:
        _run_manual()
    elif choice == 1:
        _run_watch(bidirectional=False)
    elif choice == 2:
        _run_watch(bidirectional=True)
    elif choice == 3:
        _mount_status()