"""
tools/color_note_exporter.py — ColorNote Exporter

Tool #11 — Export note dari ColorNote (SQLite) ke Markdown + HTML.

ColorNote simpen note-nya di database SQLite, biasanya di:
    /data/data/com.socialnmobile.colornote/databases/note.db

Schema ColorNote (auto-detect):
    Tabel: notes
    Kolom umum: _id, title, note, created_date, modified_date,
                color, lock, folder, trash, etc.

Note terkunci (lock=1) gak bisa dibaca plaintext — di-skip dengan warning.

Dependency: stdlib sqlite3 only.
"""

import html
import sqlite3
import time
from pathlib import Path
from semut_suite.core.storage import output_dir

from semut_suite.core.history import prompt_path_with_history
from semut_suite.ui import printer
from semut_suite.ui.spinner import auto_progress
from semut_suite.ui.prompt import (
    is_cancelled,
    prompt_choice,
    prompt_input,
    prompt_yes_no,
)


# ============================================================
# TOOL META
# ============================================================

TOOL_META = {
    "id": "color_note_exporter",
    "name": "ColorNote Exporter",
    "desc": "Export note ColorNote (SQLite) ke Markdown + HTML",
    "category": "file",
    "icon": "\U0001F4DD",
    "order": 11,
}

TOOL_ID = "color_note_exporter"

# Kolom yang dianggap sebagai "judul" note (prioritas)
TITLE_CANDIDATES = ("title", "note_title", "name", "subject")

# Kolom yang dianggap sebagai "isi" note (prioritas)
CONTENT_CANDIDATES = ("note", "content", "body", "text", "memo")

# Kolom timestamp (prioritas)
CREATED_CANDIDATES = ("created_date", "created", "created_at", "date_created")
MODIFIED_CANDIDATES = ("modified_date", "modified", "modified_at", "date_modified")


# ============================================================
# SCHEMA DETECTION
# ============================================================

def _detect_table(conn) -> str:
    """Auto-detect tabel yang berisi note."""
    cursor = conn.cursor()
    cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' "
        "ORDER BY name"
    )
    tables = [row[0] for row in cursor.fetchall()]
    if not tables:
        raise ValueError("Database gak punya tabel.")

    # Prioritas: "notes" > "note" > tabel dengan kolom content
    for preferred in ("notes", "note", "colornote"):
        if preferred in tables:
            return preferred

    # Cari tabel yang punya kolom mirip "note" / "content"
    for table in tables:
        if table.startswith("sqlite_") or table.startswith("android_"):
            continue
        cols = _get_columns(conn, table)
        col_names = {c.lower() for c in cols}
        if col_names & {"note", "content", "body", "text", "memo"}:
            return table

    # Fallback: tabel pertama yang bukan sistem
    for table in tables:
        if not table.startswith("sqlite_") and not table.startswith("android_"):
            return table

    raise ValueError("Gak nemu tabel note di database.")


def _get_columns(conn, table: str) -> list:
    """Return list nama kolom dari tabel."""
    cursor = conn.cursor()
    cursor.execute(f'PRAGMA table_info("{table}")')
    return [row[1] for row in cursor.fetchall()]


def _find_column(columns: list, candidates: tuple) -> str:
    """Cari kolom yang match dengan daftar kandidat (case-insensitive)."""
    lowered = {c.lower(): c for c in columns}
    for candidate in candidates:
        if candidate.lower() in lowered:
            return lowered[candidate.lower()]
    return ""


def _parse_timestamp(value) -> str:
    """Konversi timestamp ke string yang readable."""
    if value is None:
        return ""
    try:
        ts = int(value)
    except (TypeError, ValueError):
        return str(value)

    # Validasi unit berdasarkan rentang tahun 2000-2100.
    min_ts, max_ts = 946_684_800, 4_102_444_800
    if not (min_ts <= ts <= max_ts):
        milli = ts // 1000
        if min_ts <= milli <= max_ts:
            ts = milli
        else:
            return str(value)
    if min_ts <= ts <= max_ts:
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))
    return str(value)


# ============================================================
# NOTE PARSER
# ============================================================

def _parse_notes(db_path: str) -> list:
    """Buka SQLite, auto-detect schema, parse semua note.

    Returns:
        List of dict: {id, title, content, created, modified, color, locked, raw}
    """
    path = Path(db_path).expanduser().resolve()
    if not path.is_file():
        raise ValueError(f"File database gak ada: {path}")

    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    try:
        table = _detect_table(conn)
        columns = _get_columns(conn, table)

        title_col = _find_column(columns, TITLE_CANDIDATES)
        content_col = _find_column(columns, CONTENT_CANDIDATES)
        created_col = _find_column(columns, CREATED_CANDIDATES)
        modified_col = _find_column(columns, MODIFIED_CANDIDATES)

        if not content_col:
            raise ValueError(
                f"Gak nemu kolom isi note di tabel '{table}'. "
                f"Kolom tersedia: {', '.join(columns)}"
            )

        # Cek kolom lock & color & id & trash & folder
        col_lower = {c.lower(): c for c in columns}
        id_col = col_lower.get("_id", col_lower.get("id", "rowid"))
        lock_col = col_lower.get("lock", "")
        color_col = col_lower.get("color", "")
        trash_col = col_lower.get("trash", "")
        folder_col = col_lower.get("folder", "")

        # Build SELECT
        select_cols = [id_col, title_col, content_col]
        if created_col:
            select_cols.append(created_col)
        if modified_col:
            select_cols.append(modified_col)
        if lock_col:
            select_cols.append(lock_col)
        if color_col:
            select_cols.append(color_col)
        if trash_col:
            select_cols.append(trash_col)
        if folder_col:
            select_cols.append(folder_col)

        select_sql = 'SELECT {} FROM "{}"'.format(
            ", ".join(f'"{c}"' for c in select_cols), table
        )

        cursor = conn.cursor()
        cursor.execute(select_sql)
        rows = cursor.fetchall()

        notes = []
        col_index = {c: i for i, c in enumerate(select_cols)}

        progress = auto_progress("Parsing notes", total=len(rows))
        progress.__enter__()
        for row_index, row in enumerate(rows, 1):
            progress.update(row_index)
            note_id = row[col_index[id_col]]
            title = row[col_index[title_col]] if title_col else ""
            content = row[col_index[content_col]] if content_col else ""
            created = row[col_index[created_col]] if created_col else None
            modified = row[col_index[modified_col]] if modified_col else None
            locked = row[col_index[lock_col]] if lock_col else 0
            color = row[col_index[color_col]] if color_col else None
            trash = row[col_index[trash_col]] if trash_col else 0
            folder = row[col_index[folder_col]] if folder_col else None

            # Skip note yang di-trash (kalau ada kolom trash)
            if trash and int(trash) != 0:
                continue

            notes.append({
                "id": note_id,
                "title": str(title) if title else "(Untitled)",
                "content": str(content) if content else "",
                "created": _parse_timestamp(created),
                "modified": _parse_timestamp(modified),
                "color": int(color) if color is not None else None,
                "locked": bool(locked),
                "folder": int(folder) if folder is not None else None,
            })

        progress.done()
        return notes
    finally:
        conn.close()


def _color_name(color_value) -> str:
    """Map nilai color ColorNote ke nama warna."""
    if color_value is None:
        return "default"
    mapping = {
        0: "default",
        1: "red",
        2: "orange",
        3: "yellow",
        4: "green",
        5: "blue",
        6: "purple",
        7: "pink",
        8: "gray",
    }
    return mapping.get(int(color_value), f"color_{color_value}")


# ============================================================
# EXPORT MARKDOWN
# ============================================================

def _export_markdown(notes: list, output_dir: Path) -> list:
    """Export setiap note ke file Markdown terpisah + 1 index."""
    md_dir = output_dir / "colornote_md"
    md_dir.mkdir(parents=True, exist_ok=True)

    exported = []
    progress = auto_progress("Exporting Markdown", total=len(notes))
    progress.__enter__()

    for idx, note in enumerate(notes, 1):
        progress.update(idx)
        if note["locked"]:
            printer.print_warn(f"Note #{idx} terkunci — di-skip (gak bisa baca plaintext).")
            continue

        # Sanitasi title buat filename
        safe_title = "".join(
            c if c.isalnum() or c in "-_ " else "_"
            for c in note["title"]
        ).strip()[:60]
        if not safe_title:
            safe_title = f"note_{idx}"

        filename = f"{idx:03d}_{safe_title}.md"
        filepath = md_dir / filename

        # Build Markdown content
        lines = [
            f"# {note['title']}",
            "",
        ]
        if note["created"]:
            lines.append(f"> Created: {note['created']}")
        if note["modified"]:
            lines.append(f"> Modified: {note['modified']}")
        lines.append(f"> Color: {_color_name(note['color'])}")
        lines.append("")
        lines.append(note["content"])
        lines.append("")

        filepath.write_text("\n".join(lines), encoding="utf-8")
        exported.append(filepath)

    # Tulis index
    if exported:
        index_path = md_dir / "INDEX.md"
        index_lines = ["# ColorNote Export Index", ""]
        for idx, note in enumerate(notes, 1):
            if note["locked"]:
                index_lines.append(f"{idx}. {note['title']} \u2014 \U0001F512 LOCKED")
            else:
                safe_title = "".join(
                    c if c.isalnum() or c in "-_ " else "_"
                    for c in note["title"]
                ).strip()[:60]
                if not safe_title:
                    safe_title = f"note_{idx}"
                filename = f"{idx:03d}_{safe_title}.md"
                index_lines.append(f"{idx}. [{note['title']}]({filename})")
                if note["modified"]:
                    index_lines[-1] += f" \u2014 {note['modified']}"
        index_lines.append("")
        index_path.write_text("\n".join(index_lines), encoding="utf-8")
        exported.append(index_path)

    progress.done()
    return exported


# ============================================================
# EXPORT HTML
# ============================================================

_HTML_DOC_TEMPLATE = """<!DOCTYPE html>
<html lang="id"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="Export catatan ColorNote lokal dari Semut">\n<meta property="og:title" content="ColorNote Export — Semut">\n<meta property="og:description" content="Export catatan ColorNote lokal dari Semut">
<title>📝 ColorNote Export — Semut</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#2A2312;color:#fff;display:flex;min-height:100vh}aside{width:260px;padding:20px;background:#201a0d;border-right:1px solid rgba(255,190,11,.25);position:sticky;top:0;height:100vh;overflow:auto}main{flex:1;padding:24px;max-width:1100px}.brand{color:#FFBE0B;font-weight:800;font-size:1.25rem;margin-bottom:18px}.search{width:100%;padding:10px;border-radius:10px;border:1px solid rgba(255,190,11,.3);background:#2A2312;color:#fff}.filters{display:grid;gap:8px;margin-top:12px}.filter{padding:9px;border:1px solid rgba(255,190,11,.2);background:transparent;color:#ddd;border-radius:8px;text-align:left}.filter.active{background:#FFBE0B;color:#2A2312}.head{display:flex;justify-content:space-between;gap:16px;align-items:end;margin-bottom:20px}.subtitle{color:#A0A0A0;font-size:.85rem}.grid{display:grid;gap:14px}.note-card{background:rgba(255,255,255,.05);border:1px solid rgba(255,190,11,.2);border-radius:14px;padding:16px}.note-card.locked{opacity:.65}.note-title{color:#FFBE0B;font-weight:700;font-size:1.05rem}.note-meta{color:#A0A0A0;font-size:.78rem;margin:7px 0 12px}.note-content{white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.6}.empty{color:#A0A0A0;padding:30px;text-align:center}@media(max-width:768px){body{display:block}aside{position:sticky;width:100%;height:auto;border-right:0;border-bottom:1px solid rgba(255,190,11,.25);z-index:2}.filters{display:flex;overflow:auto}.filter{white-space:nowrap}main{padding:16px}}
</style></head><body>
<aside><div class="brand">📝 ColorNote</div><input id="search" class="search" placeholder="Cari judul / isi...">
<div class="filters"><button class="filter active" data-color="all">Semua</button><button class="filter" data-color="red">🔴 Merah</button><button class="filter" data-color="orange">🟠 Oranye</button><button class="filter" data-color="yellow">🟡 Kuning</button><button class="filter" data-color="green">🟢 Hijau</button><button class="filter" data-color="blue">🔵 Biru</button><button class="filter" data-color="locked">🔒 Locked</button></div></aside>
<main><div class="head"><div><h1>Catatan</h1><div class="subtitle">{count} note · diekspor {export_time}</div></div></div><section id="notes" class="grid">{note_cards}</section><div id="empty" class="empty" hidden>Tidak ada note yang cocok.</div></main>
<script>const cards=[...document.querySelectorAll('.note-card')],search=document.querySelector('#search'),empty=document.querySelector('#empty');let color='all';function apply(){const q=search.value.toLowerCase();let shown=0;cards.forEach(c=>{const ok=(color==='all'||c.dataset.color===color||(color==='locked'&&c.classList.contains('locked')))&&c.textContent.toLowerCase().includes(q);c.hidden=!ok;if(ok)shown++});empty.hidden=shown!==0}search.addEventListener('input',apply);document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{document.querySelectorAll('.filter').forEach(x=>x.classList.remove('active'));b.classList.add('active');color=b.dataset.color;apply()});</script></body></html>"""


def _export_html(notes: list, output_dir: Path) -> Path:
    """Export semua note ke 1 file HTML index."""
    cards = []
    progress = auto_progress("Exporting HTML", total=len(notes))
    progress.__enter__()
    for idx, note in enumerate(notes, 1):
        progress.update(idx)
        title_esc = html.escape(note["title"])
        content_esc = html.escape(note["content"])

        meta_parts = []
        if note["modified"]:
            meta_parts.append(f"Modified: {note['modified']}")
        elif note["created"]:
            meta_parts.append(f"Created: {note['created']}")
        meta_parts.append(f"Color: {_color_name(note['color'])}")
        meta = " \u00B7 ".join(meta_parts)

        if note["locked"]:
            color = html.escape(_color_name(note["color"]).lower())
            card = (
                f'<div class="note-card locked" data-color="{color}">'
                f'<div class="note-title">{idx}. \U0001F512 {title_esc}</div>'
                f'<div class="note-meta">{meta} \u00B7 LOCKED</div>'
                '<div class="note-content"><em>Note terkunci \u2014 isi tidak bisa dibaca.</em></div>'
                '</div>'
            )
        else:
            color = html.escape(_color_name(note["color"]).lower())
            card = (
                f'<div class="note-card" data-color="{color}">'
                f'<div class="note-title">{idx}. {title_esc}</div>'
                f'<div class="note-meta">{meta}</div>'
                f'<div class="note-content">{content_esc}</div>'
                '</div>'
            )
        cards.append(card)

    html_path = output_dir / "colornote_export_{}.html".format(
        time.strftime("%Y%m%d_%H%M%S", time.localtime())
    )
    progress.done()
    html_content = _HTML_DOC_TEMPLATE.replace("{count}", str(len(notes)))
    html_content = html_content.replace(
        "{export_time}", time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    )
    html_content = html_content.replace("{note_cards}", "\n".join(cards))
    html_path.write_text(html_content, encoding="utf-8")
    return html_path


# ============================================================
# PREVIEW
# ============================================================

def _show_preview(notes: list):
    """Tampilin preview note sebelum export."""
    printer.print_blank()
    printer.print_info(f"Total note terbaca: {len(notes)}")

    locked_count = sum(1 for n in notes if n["locked"])
    if locked_count:
        printer.print_warn(f"{locked_count} note terkunci (gak bisa diexport plaintext).")

    printer.print_blank()
    for idx, note in enumerate(notes, 1):
        lock_icon = " \U0001F512" if note["locked"] else ""
        title = note["title"]
        preview = note["content"][:50].replace("\n", " ")
        if note["content"] and len(note["content"]) > 50:
            preview += "..."
        printer.print_numbered(idx, f"{title}{lock_icon}")
        if preview:
            printer.print_kv("Preview", preview, indent=7)
        if note["modified"]:
            printer.print_kv("Modified", note["modified"], indent=7)

    printer.print_blank()


# ============================================================
# WIZARD
# ============================================================

def _get_output_dir() -> Path:
    """Return direktori output."""
    return output_dir("color_note_exporter")


def _rotate_exports(output_dir: Path, keep: int = 5) -> None:
    """Keep maksimal `keep` folder/file export ColorNote terbaru."""
    try:
        items = [p for p in output_dir.iterdir() if p.is_dir() or p.is_file()]
        items.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        for old in items[keep:]:
            if old.is_dir():
                import shutil
                shutil.rmtree(old, ignore_errors=True)
            else:
                old.unlink(missing_ok=True)
    except OSError:
        pass


def _do_export(db_path: str, choice=None, interactive=True):
    """Proses export: parse + preview + export MD + HTML.

    ``interactive=True`` dipakai CLI. API/GUI mengirim ``choice`` langsung
    supaya endpoint tidak pernah berhenti menunggu input terminal.
    """
    try:
        notes = _parse_notes(db_path)
    except ValueError as e:
        if interactive:
            printer.print_error(str(e))
            return None
        return {"ok": False, "error": str(e)}
    except sqlite3.DatabaseError as e:
        message = f"Gagal baca database: {e}"
        if interactive:
            printer.print_error(message)
            return None
        return {"ok": False, "error": message}

    if not notes:
        message = "Database kosong atau gak ada note yang bisa dibaca."
        if interactive:
            printer.print_warn(message)
            return None
        return {"ok": False, "error": message}

    if interactive:
        _show_preview(notes)

    output_dir = _get_output_dir()
    _rotate_exports(output_dir, keep=5)

    if choice is None:
        choice = prompt_choice(
            "Pilih format export",
            [
                "Markdown + HTML (recommended)",
                "Markdown saja",
                "HTML saja",
            ],
        )
        if choice == -1:
            return None

    try:
        choice = int(choice)
    except (TypeError, ValueError):
        return {"ok": False, "error": "format export tidak valid"}

    if choice not in (0, 1, 2):
        return {"ok": False, "error": "format export harus 0 (semua), 1 (Markdown), atau 2 (HTML)"}

    exported_files = []
    md_files = []
    html_path = None

    if choice in (0, 1):
        if interactive:
            printer.print_info("Exporting ke Markdown...")
        md_files = _export_markdown(notes, output_dir)
        exported_files.extend(md_files)
        if interactive:
            printer.print_success(f"Markdown: {len(md_files)} file di {output_dir / 'colornote_md'}")

    if choice in (0, 2):
        if interactive:
            printer.print_info("Exporting ke HTML...")
        html_path = _export_html(notes, output_dir)
        exported_files.append(html_path)
        if interactive:
            printer.print_success(f"HTML: {html_path}")

    result = {
        "ok": True,
        "database": str(Path(db_path).name),
        "total_notes": len(notes),
        "exported_notes": sum(1 for n in notes if not n["locked"]),
        "locked_notes": sum(1 for n in notes if n["locked"]),
        "format": {0: "all", 1: "markdown", 2: "html"}[choice],
        "markdown_files": [str(path) for path in md_files],
        "html_file": str(html_path) if html_path else None,
        "output_dir": str(output_dir),
    }

    if interactive and exported_files:
        printer.print_blank()
        printer.print_card(
            "Export Selesai",
            {
                "Database": result["database"],
                "Total note": str(result["total_notes"]),
                "Exported": str(result["exported_notes"]),
                "Locked (skip)": str(result["locked_notes"]),
                "Output dir": result["output_dir"],
            },
            icon="\U0001F4DD",
        )

    return result



# ============================================================
# API MODE (PR-09)
# ============================================================
def _do_work(params=None):
    params=params or {}; db_path=str(params.get("db_path") or params.get("path") or "")
    if not db_path: return {"ok":False,"error":"db_path wajib diisi"}
    format_name=str(params.get("format") or "all").lower()
    choice={"all":0,"markdown":1,"md":1,"html":2}.get(format_name)
    if choice is None: return {"ok":False,"error":"format harus all, markdown, atau html"}
    return _do_export(db_path, choice=choice, interactive=False)

def run_api(params=None): return _do_work(params)

def run_wizard():
    """Entry point ColorNote Exporter."""
    printer.print_info("ColorNote Exporter \u2014 konversi note SQLite ke Markdown + HTML.")
    printer.print_info("Note terkunci (lock=1) akan di-skip (gak bisa baca plaintext).")

    raw_path = prompt_path_with_history(
        "Path database ColorNote (note.db)",
        TOOL_ID,
    )

    if is_cancelled(raw_path) or not raw_path:
        printer.print_warn("Dibatalkan.")
        return

    _do_export(raw_path)

    if not prompt_yes_no("Export database lain?", default="n"):
        return
    run_wizard()
