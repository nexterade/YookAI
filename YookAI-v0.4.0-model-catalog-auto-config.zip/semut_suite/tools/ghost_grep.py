"""
tools/ghost_grep.py — Smart Search di Project

Search pattern (regex / string) di seluruh project, dengan:
    - Auto-group by file
    - Context lines (2 sebelum + 2 sesudah)
    - Filter by extension
    - Auto-exclude folder sampah
    - Mode: semua file ATAU cuma file traversed (dari tree_printer)
    - Export hasil ke output/<project>_grep.txt
    - Path history (auto-complete dari input sebelumnya)

Filosofi:
    Lebih pintar dari grep biasa — ngerti struktur project,
    exclude sampah otomatis, dan bisa integrasi sama
    dependency tree.
"""

import os
import re
import sys
import time
from pathlib import Path
from semut_suite.core.storage import output_dir

from semut_suite.ui import printer
from semut_suite.ui.spinner import auto_progress
from semut_suite.ui.theme import get_theme
from semut_suite.ui.prompt import (
    prompt_input, prompt_yes_no,
    is_cancelled,
)

from semut_suite.core.history import (
    prompt_path_with_history,
    add_path,
)

# Import dari tree_printer (buat integrasi):
#   scan_all_files() & scan_dependencies() udah integrasi .exclude.json
#   internal (v3.2) — lewat core.exclude.is_excluded().
from semut_suite.tools.tree_printer import (
    scan_dependencies,
    scan_all_files,
    resolve_input_path,
    DATA_EXTS,
    CODE_EXTS,
)


# ============================================================
# TOOL_META
# ============================================================

TOOL_META = {
    "id":       "ghost_grep",
    "name":     "Ghost Grep",
    "desc":     "Smart search pattern di project (grep pintar)",
    "category": "file",
    "icon":     "👁",
    "order":    2,
}


# ============================================================
# CONSTANTS
# ============================================================

OUTPUT_DIR = "output"
TOOL_ID = "ghost_grep"

DEFAULT_SCAN_EXTS = CODE_EXTS | DATA_EXTS

MAX_MATCHES_PER_FILE = 50

CONTEXT_BEFORE = 2
CONTEXT_AFTER = 2

REGEX_CHARS = set(".*+?[](){}|^$\\")


# ============================================================
# INTERNAL — PATTERN DETECTION
# ============================================================

def _is_regex_pattern(pattern: str) -> bool:
    return any(c in REGEX_CHARS for c in pattern)


def _compile_pattern(pattern: str, case_sensitive: bool):
    flags = 0
    if not case_sensitive:
        flags |= re.IGNORECASE

    if _is_regex_pattern(pattern):
        mode = "regex"
        try:
            return re.compile(pattern, flags), mode, None
        except re.error as e:
            return None, mode, f"Regex error: {e}"
    else:
        mode = "literal"
        escaped = re.escape(pattern)
        return re.compile(escaped, flags), mode, None


# ============================================================
# INTERNAL — SEARCH
# ============================================================

def _read_file_safe(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except (OSError, UnicodeDecodeError):
        return ""


def _should_scan_file(path: str, ext_filter: set) -> bool:
    ext = os.path.splitext(path)[1].lower()
    return ext in ext_filter


def search_pattern(
    pattern: str,
    project_root: str,
    files: list,
    case_sensitive: bool = False,
    ext_filter: set = None,
) -> dict:
    if ext_filter is None:
        ext_filter = DEFAULT_SCAN_EXTS

    regex, mode, error = _compile_pattern(pattern, case_sensitive)

    if error:
        return {
            "pattern":       pattern,
            "mode":          mode,
            "results":       [],
            "total_matches": 0,
            "total_files":   0,
            "error":         error,
        }

    results = []
    total_matches = 0
    progress = auto_progress("Searching files", total=len(files))
    progress.__enter__()

    for file_index, rel_path in enumerate(files, 1):
        progress.update(file_index)
        if not _should_scan_file(rel_path, ext_filter):
            continue

        abs_path = os.path.join(project_root, rel_path)
        if not os.path.isfile(abs_path):
            continue

        content = _read_file_safe(abs_path)
        if not content:
            continue

        lines = content.splitlines()
        file_matches = []

        for i, line in enumerate(lines):
            if regex.search(line):
                before_start = max(0, i - CONTEXT_BEFORE)
                after_end = min(len(lines), i + CONTEXT_AFTER + 1)

                file_matches.append({
                    "line_no": i + 1,
                    "line":    line,
                    "before":  lines[before_start:i],
                    "after":   lines[i + 1:after_end],
                })

                if len(file_matches) >= MAX_MATCHES_PER_FILE:
                    break

        if file_matches:
            results.append({
                "path":    rel_path,
                "matches": file_matches,
            })
            total_matches += len(file_matches)

    progress.done()
    return {
        "pattern":       pattern,
        "mode":          mode,
        "results":       results,
        "total_matches": total_matches,
        "total_files":   len(results),
        "error":         None,
    }


# ============================================================
# RENDER
# ============================================================

def _highlight_match(line: str, pattern: str, case_sensitive: bool = False) -> str:
    t = get_theme()

    regex, _, _ = _compile_pattern(pattern, case_sensitive)
    if regex is None:
        return line

    try:
        def _replace(m):
            return f"{t.YELLOW}{t.BOLD}{m.group(0)}{t.RESET}"

        return regex.sub(_replace, line)
    except Exception:
        return line


def render_results(scan_result: dict, project_root: str):
    t = get_theme()

    if scan_result["error"]:
        printer.print_error(scan_result["error"])
        return

    results = scan_result["results"]
    total_matches = scan_result["total_matches"]
    total_files = scan_result["total_files"]

    if not results:
        printer.print_blank()
        printer.print_warn(
            f"Gak ada match buat pattern: '{scan_result['pattern']}'"
        )
        return

    printer.print_blank()
    printer.print_section(
        f"Results — '{scan_result['pattern']}' ({scan_result['mode']})",
        icon="👁",
    )
    printer.print_blank()

    print(
        f"  {t.GREEN}✓{t.RESET}  "
        f"{total_matches} match  di  "
        f"{total_files} file"
    )
    printer.print_blank()

    for file_result in results:
        rel_path = file_result["path"]
        matches = file_result["matches"]

        print(
            f"  {t.ACCENT}{t.BOLD}{rel_path}{t.RESET}  "
            f"{t.GRAY}({len(matches)} match){t.RESET}"
        )
        print(f"  {t.ACCENT_DIM}{'─' * 56}{t.RESET}")

        for match in matches:
            line_no = match["line_no"]
            line = match["line"]

            for before_line in match["before"]:
                print(f"    {t.GRAY_DIM}  {before_line}{t.RESET}")

            highlighted = _highlight_match(
                line, scan_result["pattern"]
            )
            print(
                f"    {t.GRAY}{line_no:>4}{t.RESET}  "
                f"{t.ACCENT}│{t.RESET}  {highlighted}"
            )

            for after_line in match["after"]:
                print(f"    {t.GRAY_DIM}  {after_line}{t.RESET}")

            print()

        print()


def render_summary(scan_result: dict):
    t = get_theme()

    if scan_result["error"] or not scan_result["results"]:
        return

    printer.print_separator("═", 56)
    printer.print_section("Summary", icon="📊")
    printer.print_blank()

    print(
        f"  {t.GREEN}✓{t.RESET}  Pattern  : {scan_result['pattern']} "
        f"({scan_result['mode']})"
    )
    print(
        f"  {t.GREEN}✓{t.RESET}  Match    : {scan_result['total_matches']}"
    )
    print(
        f"  {t.GREEN}✓{t.RESET}  Files    : {scan_result['total_files']}"
    )

    printer.print_separator("═", 56)


# ============================================================
# EXPORT
# ============================================================

def _get_output_dir() -> str:
    return str(output_dir("ghost_grep"))


def _get_output_filename(project_root: str, pattern: str) -> str:
    project_name = os.path.basename(project_root.rstrip(os.sep))
    safe_pattern = re.sub(r"[^a-zA-Z0-9_-]", "_", pattern)[:30]
    return f"{project_name}_grep_{safe_pattern}.txt"


def export_txt(scan_result: dict, project_root: str) -> str:
    if scan_result["error"] or not scan_result["results"]:
        return ""

    out_dir = _get_output_dir()
    out_name = _get_output_filename(project_root, scan_result["pattern"])
    out_path = os.path.join(out_dir, out_name)

    try:
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(f"# Ghost Grep Results\n")
            f.write(f"# Pattern: {scan_result['pattern']} ({scan_result['mode']})\n")
            f.write(f"# Project: {project_root}\n")
            f.write(
                f"# Generated: "
                f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}\n"
            )
            f.write(f"# Total: {scan_result['total_matches']} match "
                    f"di {scan_result['total_files']} file\n")
            f.write("\n")
            f.write("=" * 60 + "\n\n")

            for file_result in scan_result["results"]:
                f.write(f"{file_result['path']}\n")
                f.write("-" * 60 + "\n")

                for match in file_result["matches"]:
                    for before_line in match["before"]:
                        f.write(f"      {before_line}\n")

                    f.write(
                        f"  {match['line_no']:>4}  │  {match['line']}\n"
                    )

                    for after_line in match["after"]:
                        f.write(f"      {after_line}\n")

                    f.write("\n")

                f.write("\n")

        return out_path
    except OSError as e:
        printer.print_error(f"Gagal export: {e}")
        return ""


# ============================================================
# WIZARD
# ============================================================


# ============================================================
# API MODE (PR-09)
# ============================================================
def _do_work(params=None):
    params = params or {}
    pattern = str(params.get("pattern", ""))
    project_root = str(params.get("project_root") or params.get("path") or ".")
    case_sensitive = bool(params.get("case_sensitive", False))
    ext = params.get("extensions")
    ext_filter = set()
    if ext:
        if isinstance(ext, str): ext = ext.split(",")
        ext_filter = {str(x).strip().lower() if str(x).strip().startswith(".") else "."+str(x).strip().lower() for x in ext if str(x).strip()}
    if not pattern: return {"ok": False, "error": "pattern wajib diisi"}
    root = Path(project_root).expanduser().resolve()
    if not root.is_dir(): return {"ok": False, "error": f"folder tidak ditemukan: {root}"}
    files = []
    for p in root.rglob("*"):
        if p.is_file() and (not ext_filter or p.suffix.lower() in ext_filter): files.append(str(p))
    result = search_pattern(pattern, str(root), files, case_sensitive=case_sensitive, ext_filter=ext_filter or None)
    return {"ok": True, "pattern": pattern, "project_root": str(root), "result": result}

def run_api(params=None):
    return _do_work(params)

def run_wizard():
    """Wizard interaktif."""
    printer.print_section("Ghost Grep", icon="👁")
    printer.print_info("Smart search pattern di project")
    printer.print_info("Ketik '0' di prompt manapun buat batal")
    printer.print_blank()

    printer.print_info("Contoh input:")
    printer.print_bullet("/storage/emulated/0/Project/GhostWriter/main.py")
    printer.print_bullet("/storage/emulated/0/Project/lumoss/")
    printer.print_bullet("(kosongin buat pake cwd)")
    printer.print_blank()

    # 1. Path project (pake history)
    raw_path = prompt_path_with_history(
        "Path project (file .py atau folder)",
        tool_id=TOOL_ID,
        allow_empty=True,
        default_empty="",
    )

    if is_cancelled(raw_path):
        printer.print_warn("Dibatalkan.")
        return

    # Kalau kosong — pake cwd
    if not raw_path:
        project_root = str(Path.cwd())
        entry_file = None
    else:
        project_root, entry_file, error = resolve_input_path(raw_path)

        if error and error != "MULTIPLE":
            printer.print_error(error)
            return

        if error == "MULTIPLE":
            project_root = raw_path if os.path.isdir(raw_path) else os.path.dirname(raw_path)
            entry_file = None

    printer.print_blank()
    printer.print_success(f"Project root: {project_root}")
    printer.print_blank()

    # 2. Pattern
    pattern = prompt_input(
        "Pattern yang mau dicari",
        default="",
        show_cancel=True,
    )

    if is_cancelled(pattern) or not pattern:
        printer.print_warn("Dibatalkan.")
        return

    # 3. Mode — semua file atau cuma traversed?
    printer.print_blank()
    printer.print_section("Mode Search", icon="🎯")
    printer.print_bullet("[1] Semua file (kecuali exclude default)")
    printer.print_bullet("[2] Cuma file traversed (dari dependency tree)")
    printer.print_blank()

    mode_input = prompt_input(
        "Pilih mode [1-2]",
        default="1",
        show_cancel=True,
    )

    if is_cancelled(mode_input):
        printer.print_warn("Dibatalkan.")
        return

    mode = "all" if mode_input.strip() in ("1", "") else "traversed"

    # 4. Build file list
    if mode == "traversed":
        if not entry_file:
            printer.print_warn(
                "Mode traversed butuh entry point. "
                "Fallback ke semua file."
            )
            mode = "all"
        else:
            printer.print_info(f"Scanning dependency tree dari {entry_file}...")
            try:
                tree_data = scan_dependencies(entry_file, project_root)
                files = tree_data["visited"]
                printer.print_success(f"{len(files)} file traversed")
            except Exception as e:
                printer.print_error(f"Gagal scan: {e}")
                return

    if mode == "all":
        printer.print_info("Scanning semua file...")
        files = scan_all_files(project_root)
        printer.print_success(f"{len(files)} file ditemukan")

    if not files:
        printer.print_warn("Gak ada file buat di-scan.")
        return

    # 5. Case sensitive?
    printer.print_blank()
    case_sensitive = not prompt_yes_no(
        "Case insensitive? (default: y, huruf besar/kecil dianggap sama)",
        default="y",
    )

    # 6. Search
    printer.print_blank()
    printer.print_info(f"Searching '{pattern}'...")

    scan_result = search_pattern(
        pattern=pattern,
        project_root=project_root,
        files=files,
        case_sensitive=case_sensitive,
    )

    # 7. Render
    render_results(scan_result, project_root)
    render_summary(scan_result)
    printer.print_card(
        "Search Selesai",
        {
            "Pattern": pattern,
            "Files": str(len(files)),
            "Matches": str(len(scan_result.get("results", []))),
        },
        icon="👁",
        color=get_theme().GREEN,
    )

    # 8. Export?
    if scan_result["results"]:
        printer.print_blank()
        if prompt_yes_no("Export ke file?", default="n"):
            out_path = export_txt(scan_result, project_root)
            if out_path:
                printer.print_success(f"Exported: {out_path}")

    printer.print_blank()
    printer.print_success("Selesai.")


# ============================================================
# SELF-TEST
# ============================================================

if __name__ == "__main__":
    run_wizard()