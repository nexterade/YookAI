"""
tools/file_hasher.py — Hash File + Verifikasi Integritas (v1.1)

Fitur:
    - Hash semua file di project (SHA256)
    - Output manifest plain text: '<hash>  <size>  <path>'
    - Verifikasi folder vs folder (bandingin 2 folder)
    - Verifikasi folder vs manifest (cek integritas file)
    - Output centralized di semut/output/
    - Path history (auto-complete dari input sebelumnya)

v1.1 changes:
    - Integrasi core.exclude — file yang ke-exclude gak di-hash
    - Animasi loading pake ui.spinner (Progress + Spinner)

Filosofi:
    Backup tanpa verifikasi = backup yang belum tentu bener.
    File hasher ini bikin lo bisa BUKTIKAN backup lo utuh.
"""

import os
import re
import time
import hashlib
from semut_suite.core.storage import output_dir

from semut_suite.ui import printer
from semut_suite.ui.theme import get_theme
from semut_suite.ui.prompt import (
    prompt_input, prompt_choice, prompt_yes_no,
    is_cancelled,
)
from semut_suite.ui.spinner import Spinner, auto_progress

from semut_suite.core.history import (
    prompt_path_with_history,
    add_path,
)

from semut_suite.core.exclude import is_excluded

# Import dari tree_printer (buat konsistensi exclude & scan)
from semut_suite.tools.tree_printer import (
    scan_all_files,
    resolve_input_path,
)


# ============================================================
# TOOL_META
# ============================================================

TOOL_META = {
    "id":       "file_hasher",
    "name":     "File Hasher",
    "desc":     "Hash file + verifikasi integritas backup",
    "category": "file",
    "icon":     "🔐",
    "order":    3,
}


# ============================================================
# CONSTANTS
# ============================================================

OUTPUT_DIR = "output"
TOOL_ID = "file_hasher"

HASH_ALGO = "sha256"
CHUNK_SIZE = 65536


# ============================================================
# INTERNAL — HASH
# ============================================================

def hash_file(path: str, algo: str = HASH_ALGO) -> str:
    try:
        hasher = hashlib.new(algo)
        with open(path, "rb") as f:
            while True:
                chunk = f.read(CHUNK_SIZE)
                if not chunk:
                    break
                hasher.update(chunk)
        return hasher.hexdigest()
    except (OSError, ValueError):
        return ""


def hash_files(
    project_root: str,
    files: list,
    algo: str = HASH_ALGO,
    verbose: bool = False,
    skip_excluded: bool = True,
    show_progress: bool = False,
) -> dict:
    """Hash semua file di list.

    Args:
        project_root   : path root project
        files          : list path relatif
        algo           : hash algorithm (default sha256)
        verbose        : print per file
        skip_excluded  : skip file yang ada di .exclude.json
        show_progress  : tampilin progress bar

    Returns:
        dict {rel_path: {"hash": ..., "size": ...}}
    """
    # Filter exclude dulu
    if skip_excluded:
        files = [f for f in files if not is_excluded(f)]

    results = {}
    total = len(files)

    if show_progress and total > 0:
        progress = auto_progress("Hashing files", total=total)
        progress.__enter__()
    else:
        progress = None

    for i, rel_path in enumerate(files, 1):
        abs_path = os.path.join(project_root, rel_path)

        if not os.path.isfile(abs_path):
            if progress:
                progress.update(i)
            continue

        if verbose and not show_progress:
            print(f"  [{i}/{total}] {rel_path}")

        try:
            size = os.path.getsize(abs_path)
        except OSError:
            size = 0

        file_hash = hash_file(abs_path, algo)

        results[rel_path] = {
            "hash": file_hash,
            "size": size,
        }

        if progress:
            progress.update(i)

    if progress:
        progress.done()

    return results


# ============================================================
# INTERNAL — MANIFEST
# ============================================================

def write_manifest(
    hashes: dict,
    project_root: str,
    output_path: str,
    algo: str = HASH_ALGO,
) -> bool:
    try:
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(f"# File Manifest\n")
            f.write(f"# Algorithm: {algo}\n")
            f.write(f"# Project:   {project_root}\n")
            f.write(
                f"# Generated: "
                f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}\n"
            )
            f.write(f"# Total:     {len(hashes)} file\n")
            f.write("\n")

            for rel_path in sorted(hashes.keys()):
                entry = hashes[rel_path]
                file_hash = entry["hash"]
                size = entry["size"]

                if not file_hash:
                    f.write(f"# FAILED  {size:>12}  {rel_path}\n")
                else:
                    f.write(f"{file_hash}  {size:>12}  {rel_path}\n")

        return True
    except OSError as e:
        printer.print_error(f"Gagal tulis manifest: {e}")
        return False


def parse_manifest(manifest_path: str) -> dict:
    results = {}

    if not os.path.isfile(manifest_path):
        return results

    try:
        with open(manifest_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.rstrip("\n")

                if not line or line.startswith("#"):
                    continue

                parts = re.split(r"\s{2,}", line.strip(), maxsplit=2)

                if len(parts) < 3:
                    continue

                file_hash, size_str, rel_path = parts

                try:
                    size = int(size_str.strip())
                except ValueError:
                    size = 0

                results[rel_path.strip()] = {
                    "hash": file_hash.strip(),
                    "size": size,
                }

    except (OSError, UnicodeDecodeError):
        pass

    return results


# ============================================================
# VERIFY
# ============================================================

def verify_manifests(
    hashes_a: dict,
    hashes_b: dict,
    label_a: str = "A",
    label_b: str = "B",
) -> dict:
    result = {
        "same":      [],
        "different": [],
        "only_a":    [],
        "only_b":    [],
    }

    all_paths = set(hashes_a.keys()) | set(hashes_b.keys())

    for path in sorted(all_paths):
        in_a = path in hashes_a
        in_b = path in hashes_b

        if in_a and in_b:
            hash_a = hashes_a[path]["hash"]
            hash_b = hashes_b[path]["hash"]

            if hash_a == hash_b:
                result["same"].append(path)
            else:
                result["different"].append(path)
        elif in_a:
            result["only_a"].append(path)
        else:
            result["only_b"].append(path)

    return result


# ============================================================
# RENDER
# ============================================================

def render_verify_result(result: dict, label_a: str, label_b: str):
    t = get_theme()

    same = result["same"]
    different = result["different"]
    only_a = result["only_a"]
    only_b = result["only_b"]

    printer.print_blank()
    printer.print_section("Verify Results", icon="🔍")
    printer.print_blank()

    print(f"  {t.GREEN}✓{t.RESET}  Same      : {len(same):>4} file")
    print(f"  {t.YELLOW}⚠{t.RESET}  Different : {len(different):>4} file")
    print(f"  {t.RED}−{t.RESET}  Only {label_a:>5} : {len(only_a):>4} file")
    print(f"  {t.RED}+{t.RESET}  Only {label_b:>5} : {len(only_b):>4} file")
    printer.print_blank()

    if different:
        printer.print_section(f"Different ({len(different)})", icon="⚠")
        printer.print_info(f"File yang ada di dua-duanya, tapi hash-nya beda:")
        printer.print_blank()

        for path in different[:30]:
            print(f"  {t.YELLOW}⚠{t.RESET}  {path}")

        if len(different) > 30:
            printer.print_info(f"... dan {len(different) - 30} file lain")
        printer.print_blank()

    if only_a:
        printer.print_section(f"Only in {label_a} ({len(only_a)})", icon="−")
        printer.print_info(f"File yang cuma ada di {label_a}:")
        printer.print_blank()

        for path in only_a[:20]:
            print(f"  {t.RED}−{t.RESET}  {path}")

        if len(only_a) > 20:
            printer.print_info(f"... dan {len(only_a) - 20} file lain")
        printer.print_blank()

    if only_b:
        printer.print_section(f"Only in {label_b} ({len(only_b)})", icon="+")
        printer.print_info(f"File yang cuma ada di {label_b}:")
        printer.print_blank()

        for path in only_b[:20]:
            print(f"  {t.RED}+{t.RESET}  {path}")

        if len(only_b) > 20:
            printer.print_info(f"... dan {len(only_b) - 20} file lain")
        printer.print_blank()


# ============================================================
# OUTPUT HELPERS
# ============================================================

def _get_semut_root() -> str:
    """Return YookAI's persistent Semut utility data root."""
    return str(Path.home() / ".yookai" / "semut_suite")


def _get_output_dir() -> str:
    return str(output_dir("file_hasher"))


def _get_manifest_filename(project_root: str) -> str:
    project_name = os.path.basename(project_root.rstrip(os.sep))
    if not project_name:
        project_name = "manifest"
    return f"{project_name}_manifest.txt"


# ============================================================
# WIZARD
# ============================================================


# ============================================================
# API MODE (PR-09)
# ============================================================
def _do_work(params=None):
    params=params or {}; action=str(params.get("action","hash")); algo=str(params.get("algorithm", HASH_ALGO))
    if action == "hash_file":
        path=str(params.get("path",""));
        if not path: return {"ok":False,"error":"path wajib diisi"}
        return {"ok":True,"action":action,"path":path,"hash":hash_file(path,algo),"algorithm":algo}
    if action == "hash_folder":
        root=Path(params.get("project_root") or params.get("path") or ".").expanduser().resolve()
        files=[str(p) for p in root.rglob("*") if p.is_file()]
        data=hash_files(str(root),files,algo,verbose=False,skip_excluded=True,show_progress=False)
        return {"ok":True,"action":action,"project_root":str(root),"hashes":data}
    if action == "verify":
        a=params.get("hashes_a",{}); b=params.get("hashes_b",{})
        return {"ok":True,"action":action,"result":verify_manifests(a,b,str(params.get("label_a","A")),str(params.get("label_b","B")))}
    return {"ok":False,"error":f"action tidak dikenal: {action}"}

def run_api(params=None): return _do_work(params)

def run_wizard():
    """Wizard interaktif."""
    printer.print_section("File Hasher", icon="🔐")
    printer.print_info("Hash file + verifikasi integritas backup")
    printer.print_info("Ketik '0' di prompt manapun buat batal")
    printer.print_blank()

    mode = prompt_choice(
        "Pilih mode",
        choices=[
            "Hash folder → bikin manifest",
            "Verify: folder vs folder",
            "Verify: folder vs manifest",
        ],
        default_index=0,
    )

    if mode == -1:
        printer.print_warn("Dibatalkan.")
        return

    if mode == 0:
        _wizard_hash()
    elif mode == 1:
        _wizard_verify_folder()
    elif mode == 2:
        _wizard_verify_manifest()


def _wizard_hash():
    """Mode 1: Hash folder → bikin manifest."""
    printer.print_blank()
    printer.print_section("Mode: Hash Folder", icon="🔐")
    printer.print_blank()

    # Input project root (pake history)
    raw = prompt_path_with_history(
        "Path folder project",
        tool_id=TOOL_ID,
        allow_empty=True,
        default_empty="",
    )

    if is_cancelled(raw):
        printer.print_warn("Dibatalkan.")
        return

    if not raw:
        project_root = str(Path.cwd())
    else:
        project_root, _, error = resolve_input_path(raw)

        if error and error != "MULTIPLE":
            printer.print_error(error)
            return

        if error == "MULTIPLE":
            project_root = raw if os.path.isdir(raw) else os.path.dirname(raw)

    printer.print_blank()
    printer.print_success(f"Project root: {project_root}")
    printer.print_blank()

    # Scan
    with Spinner("Scanning files"):
        files = scan_all_files(project_root)

    printer.print_success(f"{len(files)} file ditemukan (exclude aktif)")

    if not files:
        printer.print_warn("Gak ada file buat di-hash.")
        return

    printer.print_blank()
    printer.print_info(f"Bakal hash {len(files)} file dengan {HASH_ALGO.upper()}")
    printer.print_info("File yang ada di .exclude.json otomatis di-skip.")

    if not prompt_yes_no("Lanjut?", default="y"):
        printer.print_warn("Dibatalkan.")
        return

    printer.print_blank()

    start_time = time.time()
    hashes = hash_files(
        project_root, files,
        verbose=False,
        skip_excluded=True,
        show_progress=True,
    )
    elapsed = time.time() - start_time

    printer.print_blank()
    printer.print_success(
        f"{len(hashes)} file di-hash dalam {elapsed:.2f}s"
    )

    out_dir = _get_output_dir()
    out_name = _get_manifest_filename(project_root)
    out_path = os.path.join(out_dir, out_name)

    printer.print_blank()
    if write_manifest(hashes, project_root, out_path, HASH_ALGO):
        printer.print_success(f"Manifest: {out_path}")
    else:
        printer.print_error("Gagal tulis manifest.")

    printer.print_blank()
    printer.print_success("Selesai.")


def _wizard_verify_folder():
    """Mode 2: Verify folder vs folder."""
    printer.print_blank()
    printer.print_section("Mode: Verify Folder vs Folder", icon="🔍")
    printer.print_blank()

    # Folder A (pake history)
    raw_a = prompt_path_with_history(
        "Path folder A",
        tool_id=TOOL_ID,
    )
    if not raw_a:
        printer.print_warn("Dibatalkan.")
        return

    project_a, _, err_a = resolve_input_path(raw_a)
    if err_a and err_a != "MULTIPLE":
        printer.print_error(f"Folder A: {err_a}")
        return
    if err_a == "MULTIPLE":
        project_a = raw_a if os.path.isdir(raw_a) else os.path.dirname(raw_a)

    # Folder B (pake history)
    printer.print_blank()
    raw_b = prompt_path_with_history(
        "Path folder B",
        tool_id=TOOL_ID,
    )
    if not raw_b:
        printer.print_warn("Dibatalkan.")
        return

    project_b, _, err_b = resolve_input_path(raw_b)
    if err_b and err_b != "MULTIPLE":
        printer.print_error(f"Folder B: {err_b}")
        return
    if err_b == "MULTIPLE":
        project_b = raw_b if os.path.isdir(raw_b) else os.path.dirname(raw_b)

    printer.print_blank()
    printer.print_success(f"Folder A: {project_a}")
    printer.print_success(f"Folder B: {project_b}")
    printer.print_blank()

    # Scan A
    with Spinner("Scanning folder A"):
        files_a = scan_all_files(project_a)
    printer.print_success(f"Folder A: {len(files_a)} file")
    printer.print_blank()

    # Hash A
    hashes_a = hash_files(
        project_a, files_a,
        verbose=False,
        skip_excluded=True,
        show_progress=True,
    )
    printer.print_blank()

    # Scan B
    with Spinner("Scanning folder B"):
        files_b = scan_all_files(project_b)
    printer.print_success(f"Folder B: {len(files_b)} file")
    printer.print_blank()

    # Hash B
    hashes_b = hash_files(
        project_b, files_b,
        verbose=False,
        skip_excluded=True,
        show_progress=True,
    )
    printer.print_blank()

    label_a = os.path.basename(project_a.rstrip(os.sep)) or "A"
    label_b = os.path.basename(project_b.rstrip(os.sep)) or "B"

    result = verify_manifests(hashes_a, hashes_b, label_a, label_b)
    render_verify_result(result, label_a, label_b)

    printer.print_success("Selesai.")


def _wizard_verify_manifest():
    """Mode 3: Verify folder vs manifest."""
    printer.print_blank()
    printer.print_section("Mode: Verify Folder vs Manifest", icon="🔍")
    printer.print_blank()

    # Folder (pake history)
    raw_folder = prompt_path_with_history(
        "Path folder project",
        tool_id=TOOL_ID,
    )
    if not raw_folder:
        printer.print_warn("Dibatalkan.")
        return

    project_root, _, err = resolve_input_path(raw_folder)
    if err and err != "MULTIPLE":
        printer.print_error(err)
        return
    if err == "MULTIPLE":
        project_root = raw_folder if os.path.isdir(raw_folder) else os.path.dirname(raw_folder)

    # Manifest (pake history juga)
    printer.print_blank()
    raw_manifest = prompt_path_with_history(
        "Path file manifest",
        tool_id=TOOL_ID,
    )
    if not raw_manifest:
        printer.print_warn("Dibatalkan.")
        return

    manifest_path = os.path.expanduser(raw_manifest.strip())

    if not os.path.isfile(manifest_path):
        printer.print_error(f"Manifest gak ada cuy: {manifest_path}")
        return

    printer.print_blank()
    printer.print_success(f"Folder: {project_root}")
    printer.print_success(f"Manifest: {manifest_path}")
    printer.print_blank()

    # Parse manifest
    with Spinner("Parsing manifest"):
        manifest_hashes = parse_manifest(manifest_path)

    if not manifest_hashes:
        printer.print_error("Manifest kosong / format invalid.")
        return

    printer.print_success(f"Manifest: {len(manifest_hashes)} entry")
    printer.print_blank()

    # Scan folder
    with Spinner("Scanning folder"):
        files_now = scan_all_files(project_root)
    printer.print_success(f"Folder: {len(files_now)} file")
    printer.print_blank()

    # Hash folder
    hashes_now = hash_files(
        project_root, files_now,
        verbose=False,
        skip_excluded=True,
        show_progress=True,
    )
    printer.print_blank()

    result = verify_manifests(
        manifest_hashes,
        hashes_now,
        "manifest",
        "sekarang",
    )
    render_verify_result(result, "manifest", "sekarang")

    printer.print_success("Beres boss 👍.")


# ============================================================
# SELF-TEST
# ============================================================

if __name__ == "__main__":
    run_wizard()