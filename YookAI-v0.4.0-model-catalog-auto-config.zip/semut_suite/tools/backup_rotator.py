"""
tools/backup_rotator.py — Backup Pintar dengan Rotation & Verifikasi (v3.1)

Fitur:
    - Mode 1: Backup Project (smart / clean / mirror) → ZIP + manifest JSON
    - Mode 2: Backup File Spesifik (multi-line → 1 ZIP per sesi)
    - Mode 3: List Backups (ZIP + legacy folder)
    - Mode 4: Restore
    - Mode 5: Prune
    - Mode 6: History Backup (timeline dari .backup_log.json)

v3.1 changes:
    - Integrasi core.exclude — file yang ke-exclude gak di-backup
    - Animasi loading pake ui.spinner (Spinner + Progress)
    - Polish UI pake print_card & print_verdict

Filosofi:
    Backup tanpa verify = asumsi. Backup dengan verify = fakta.
    Backup pintar = cuma file yang beneran dipake.
    1 backup = 1 file ZIP + 1 manifest JSON. Self-contained. Portable.

Format nama backup project (ZIP):
    - Dengan tag    : <Project>_v<tag>_<DD-MM-YYYY>.zip
    - Tanpa tag     : <Project>_<DD-MM-YYYY>.zip
    - Manifest      : <nama>.meta.json
    - Legacy        : folder <Project>_v<tag>_<DD-MM-YYYY>/

Struktur:
    semut/backups/
    ├── <Project>_v<tag>_<DD-MM-YYYY>.zip
    ├── <Project>_v<tag>_<DD-MM-YYYY>.meta.json
    ├── file_sessions/
    │   └── <DD-MM-YYYY_HHMM>_<note>.zip
    └── .backup_log.json          ← timeline log global

Isi ZIP backup project:
    ├── .backup_meta.json         ← metadata + file list + hash
    ├── semut.py
    └── ui/theme.py

History:
    Path project disimpen di semut/.path_history.json
"""

import os
import hashlib
import re
import shutil
import time
import datetime
import json
import zipfile
from pathlib import Path
from semut_suite.core.storage import output_dir

from semut_suite.ui import printer
from semut_suite.ui.theme import get_theme
from semut_suite.ui.prompt import (
    prompt_input, prompt_choice, prompt_yes_no,
    is_cancelled,
)
from semut_suite.ui.spinner import Spinner, auto_progress

from semut_suite.core.utils import (
    read_json, write_json, format_size, wait_for_file,
)

from semut_suite.core.history import (
    prompt_path_with_history,
    add_path,
)

from semut_suite.core.exclude import is_excluded

from semut_suite.tools.tree_printer import (
    scan_dependencies,
    scan_all_files,
    resolve_input_path,
    detect_entry_points,
    _is_junk,
    _should_exclude,
)

from semut_suite.tools.file_hasher import (
    hash_file,
    hash_files,
    write_manifest,
    parse_manifest,
    verify_manifests,
    HASH_ALGO,
)


# ============================================================
# TOOL_META
# ============================================================

TOOL_META = {
    "id":       "backup_rotator",
    "name":     "Backup Rotator",
    "desc":     "Backup pintar + ZIP arsip dengan rotation",
    "category": "file",
    "icon":     "💾",
    "order":    4,
}


# ============================================================
# CONSTANTS
# ============================================================

BACKUP_DIR_NAME = "backups"
SESSIONS_DIR_NAME = "file_sessions"

META_FILENAME = ".backup_meta.json"
LOG_FILENAME = ".backup_log.json"
MANIFEST_FILENAME = ".manifest.txt"

MAX_BACKUPS_PER_PROJECT = 10
MAX_FILE_SESSIONS = 50
MAX_FILES_PER_SESSION = 50

SIZE_WARN_THRESHOLD = 50 * 1024 * 1024
MAX_VERSION_TAG_LEN = 20

TOOL_ID = "backup_rotator"

COMPRESSION = zipfile.ZIP_DEFLATED


# ============================================================
# INTERNAL — PATH HELPERS
# ============================================================

def _get_semut_root() -> str:
    """Return YookAI's persistent Semut utility data root."""
    return str(Path.home() / ".yookai" / "semut_suite")


def _get_backup_root() -> str:
    """Use accessible shared output and preserve/migrate prior private backups."""
    backup_root = output_dir("backups")
    legacy_root = Path(_get_semut_root()) / BACKUP_DIR_NAME
    if legacy_root.is_dir() and legacy_root.resolve() != backup_root.resolve():
        for source in legacy_root.iterdir():
            target = backup_root / source.name
            try:
                if source.is_symlink() or target.exists():
                    continue
                if source.is_file():
                    shutil.copy2(source, target)
                elif source.is_dir():
                    shutil.copytree(source, target, symlinks=False, dirs_exist_ok=False,
                                    ignore=shutil.ignore_patterns("*.tmp", "__pycache__"))
            except OSError:
                # Keep original private copy intact if shared storage is full/unavailable.
                continue
    return str(backup_root)


def _get_sessions_dir() -> str:
    sessions_dir = os.path.join(_get_backup_root(), SESSIONS_DIR_NAME)
    os.makedirs(sessions_dir, exist_ok=True)
    return sessions_dir


def _get_log_path() -> str:
    return os.path.join(_get_backup_root(), LOG_FILENAME)


def _sanitize_name(name: str, max_len: int = 40) -> str:
    safe = re.sub(r"[^a-zA-Z0-9._-]", "_", name)
    safe = safe.strip("._")
    return safe[:max_len] or "unnamed"


def _sanitize_version_tag(tag: str) -> str:
    if not tag:
        return ""
    safe = re.sub(r"[^a-zA-Z0-9._-]", "", tag.strip())
    safe = safe.strip("._-")
    return safe[:MAX_VERSION_TAG_LEN]


def _build_backup_basename(project_name: str, tag: str, date_str: str) -> str:
    clean_project = _sanitize_name(project_name, max_len=40)
    clean_tag = _sanitize_version_tag(tag)
    if clean_tag:
        return f"{clean_project}_v{clean_tag}_{date_str}"
    return f"{clean_project}_{date_str}"


def _generate_session_id(note: str = "") -> str:
    ts = time.strftime("%d-%m-%Y_%H%M", time.localtime())
    if note:
        safe_note = _sanitize_name(note, max_len=30)
        return f"{ts}_{safe_note}"
    return ts


# ============================================================
# INTERNAL — PARSE BACKUP NAME
# ============================================================

def _parse_backup_basename(name: str) -> dict:
    """Parse nama backup (tanpa ekstensi) jadi dict {project, tag, date}."""
    if not name:
        return None
    parts = name.split("_")
    date_idx = None
    for i, part in enumerate(parts):
        if re.match(r"^\d{2}-\d{2}-\d{4}$", part):
            date_idx = i
            break
    if date_idx is None or date_idx == 0:
        return None
    date_part = parts[date_idx]
    prefix_parts = parts[:date_idx]
    if not prefix_parts:
        return None
    prefix = "_".join(prefix_parts)
    project = prefix
    tag = ""
    if "_v" in prefix:
        idx = prefix.rfind("_v")
        project = prefix[:idx]
        remainder = prefix[idx + 2:]
        tag = remainder
    if not project:
        return None
    return {"project": project, "tag": tag, "date": date_part, "name": name}


# ============================================================
# INTERNAL — LOG MANAGEMENT
# ============================================================

def _read_log() -> dict:
    log_path = _get_log_path()
    data = read_json(log_path, default={})
    if not isinstance(data, dict):
        return {"version": 1, "entries": []}
    if "entries" not in data or not isinstance(data["entries"], list):
        data["entries"] = []
    data.setdefault("version", 1)
    return data


def _write_log(log: dict) -> bool:
    return write_json(_get_log_path(), log)


def _append_log(entry: dict) -> bool:
    log = _read_log()
    log["entries"].append(entry)
    return _write_log(log)


def _update_log_remove(name: str) -> bool:
    log = _read_log()
    before = len(log["entries"])
    log["entries"] = [
        e for e in log["entries"]
        if e.get("archive") != name and e.get("basename") != name
    ]
    if len(log["entries"]) == before:
        return False
    return _write_log(log)


def _find_previous_log_entry(project: str, current_timestamp: str) -> dict:
    log = _read_log()
    candidates = [
        e for e in log["entries"]
        if e.get("project") == project
        and e.get("timestamp", "") < current_timestamp
    ]
    if not candidates:
        return {}
    candidates.sort(key=lambda e: e.get("timestamp", ""), reverse=True)
    return candidates[0]


# ============================================================
# INTERNAL — HASH ROOT
# ============================================================

def _compute_hash_root(files_meta: list) -> str:
    """Hash gabungan semua hash file, sort by path."""
    items = sorted(
        (fm.get("path", ""), fm.get("hash", ""))
        for fm in files_meta
    )
    from hashlib import sha256
    h = sha256()
    for path, fhash in items:
        h.update(path.encode("utf-8"))
        h.update(b"\0")
        h.update(fhash.encode("utf-8"))
        h.update(b"\n")
    return "sha256:" + h.hexdigest()


# ============================================================
# INTERNAL — VALIDASI FILE
# ============================================================

def _validate_file(path: str) -> dict:
    result = {
        "path": path, "valid": False, "error": None,
        "size": 0, "is_binary": False,
    }
    if not path:
        result["error"] = "Path kosong"
        return result
    expanded = os.path.expanduser(path)
    if not os.path.exists(expanded):
        result["error"] = f"File gak ada: {path}"
        return result
    if os.path.isdir(expanded):
        result["error"] = f"Path ini folder, bukan file: {path}"
        return result
    if not os.access(expanded, os.R_OK):
        result["error"] = f"File gak bisa dibaca: {path}"
        return result
    try:
        size = os.path.getsize(expanded)
    except OSError as e:
        result["error"] = f"Gagal baca size: {e}"
        return result
    result["path"] = expanded
    result["valid"] = True
    result["size"] = size
    result["is_binary"] = _is_binary_extension(expanded)
    return result


def _is_binary_extension(path: str) -> bool:
    BINARY_EXTS = {
        ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".ico",
        ".pdf", ".zip", ".rar", ".7z", ".tar", ".gz",
        ".mp3", ".mp4", ".mkv", ".mov", ".avi", ".webm",
        ".exe", ".apk", ".so", ".dll", ".bin",
        ".db", ".sqlite", ".sqlite3",
        ".ttf", ".otf", ".woff", ".woff2",
    }
    ext = os.path.splitext(path)[1].lower()
    return ext in BINARY_EXTS


def _should_skip_junk(path: str) -> bool:
    """Cek junk + exclude .exclude.json."""
    base = os.path.basename(path)
    if _is_junk(base):
        return True
    # Cek exclude dari .exclude.json
    if is_excluded(path):
        return True
    return False


# ============================================================
# INTERNAL — FIND COMMON BASE
# ============================================================

def _find_common_base(paths: list) -> str:
    if not paths:
        return ""
    if len(paths) == 1:
        return os.path.dirname(paths[0]) + os.sep
    parts_list = [Path(p).parts for p in paths]
    common = []
    min_len = min(len(p) for p in parts_list)
    for i in range(min_len):
        segment = parts_list[0][i]
        if all(p[i] == segment for p in parts_list):
            common.append(segment)
        else:
            break
    if not common:
        return ""
    base = os.path.join(*common)
    for p in paths:
        if os.path.normpath(p) == os.path.normpath(base):
            base = os.path.dirname(base)
    if not os.path.isdir(base):
        base = os.path.dirname(base)
    if not base:
        return ""
    return base.rstrip(os.sep) + os.sep


def _relative_to_base(path: str, base: str) -> str:
    if not base:
        return os.path.basename(path)
    try:
        return os.path.relpath(path, base)
    except ValueError:
        return os.path.basename(path)


# ============================================================
# INTERNAL — ZIP LOGIC
# ============================================================

def _create_project_zip(project_root: str, files: list,
                        output_path: str, meta: dict) -> dict:
    """Bikin ZIP backup project + manifest JSON."""
    try:
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with zipfile.ZipFile(output_path, "w", COMPRESSION) as zf:
            for rel_path in files:
                abs_path = os.path.join(project_root, rel_path)
                if not os.path.isfile(abs_path):
                    continue
                arcname = rel_path.replace(os.sep, "/")
                zf.write(abs_path, arcname=arcname)
            meta_json = json.dumps(meta, indent=2, ensure_ascii=False)
            zf.writestr(META_FILENAME, meta_json)
        size = os.path.getsize(output_path)
        return {"success": True, "error": None, "size": size}
    except (OSError, zipfile.BadZipFile) as e:
        return {"success": False, "error": str(e), "size": 0}


def _read_meta_from_zip(zip_path: str) -> dict:
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            if META_FILENAME not in zf.namelist():
                return {}
            with zf.open(META_FILENAME) as f:
                return json.loads(f.read().decode("utf-8"))
    except (zipfile.BadZipFile, KeyError, ValueError, OSError):
        return {}


def _list_zip_files(zip_path: str) -> list:
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            return [
                n for n in zf.namelist()
                if n != META_FILENAME and not n.endswith("/")
            ]
    except (zipfile.BadZipFile, OSError):
        return []


# ============================================================
# INTERNAL — LIST BACKUPS
# ============================================================

def _list_project_backups() -> list:
    """List backup project (ZIP baru + folder legacy)."""
    backup_root = _get_backup_root()
    backups = []
    if not os.path.isdir(backup_root):
        return backups

    log = _read_log()
    log_by_name = {e.get("basename", ""): e for e in log.get("entries", [])}

    for entry in sorted(os.listdir(backup_root)):
        if entry == SESSIONS_DIR_NAME:
            continue
        entry_path = os.path.join(backup_root, entry)

        # ZIP baru
        if entry.endswith(".zip"):
            basename = entry[:-4]
            parsed = _parse_backup_basename(basename)
            if not parsed:
                continue
            meta = _read_meta_from_zip(entry_path)
            try:
                size = os.path.getsize(entry_path)
            except OSError:
                size = 0
            log_entry = log_by_name.get(basename, {})
            backups.append({
                "path": entry_path,
                "name": entry,
                "basename": basename,
                "project": parsed["project"],
                "tag": parsed["tag"],
                "date": parsed["date"],
                "size": size,
                "file_count": meta.get("file_count", 0),
                "mode": meta.get("mode", "unknown"),
                "backed_up": meta.get("backed_up_at", ""),
                "hash_root": meta.get("hash_root", ""),
                "type": "zip",
                "legacy": False,
                "log": log_entry,
            })
            continue

        # Legacy folder
        if os.path.isdir(entry_path):
            parsed = _parse_backup_basename(entry)
            if not parsed:
                continue
            meta_path = os.path.join(entry_path, ".backup_meta.json")
            meta = read_json(meta_path, default={})
            total_size = 0
            file_count = 0
            for root, _, files in os.walk(entry_path):
                for f in files:
                    if f.startswith("."):
                        continue
                    file_count += 1
                    try:
                        total_size += os.path.getsize(os.path.join(root, f))
                    except OSError:
                        pass
            backups.append({
                "path": entry_path,
                "name": entry,
                "basename": entry,
                "project": parsed["project"],
                "tag": parsed["tag"],
                "date": parsed["date"],
                "size": total_size,
                "file_count": file_count,
                "mode": meta.get("mode", "unknown"),
                "backed_up": meta.get("backed_up_at", ""),
                "hash_root": "",
                "type": "folder",
                "legacy": True,
                "log": {},
            })

    return backups


def _list_file_sessions() -> list:
    sessions_dir = _get_sessions_dir()
    sessions = []
    if not os.path.isdir(sessions_dir):
        return sessions
    for entry in sorted(os.listdir(sessions_dir)):
        if not entry.endswith(".zip"):
            continue
        zip_path = os.path.join(sessions_dir, entry)
        session_name = entry[:-4]
        meta = _read_meta_from_zip(zip_path)
        if not meta:
            meta = {"session_id": session_name, "note": "", "file_count": 0}
        try:
            size = os.path.getsize(zip_path)
        except OSError:
            size = 0
        sessions.append({
            "path": zip_path, "name": session_name, "zip_name": entry,
            "size": size, "file_count": meta.get("file_count", 0),
            "note": meta.get("note", ""), "created": meta.get("created", ""),
            "base_path": meta.get("base_path", ""), "meta": meta,
            "type": "session",
        })
    return sessions


# ============================================================
# INTERNAL — ROTATION
# ============================================================

def _backup_recency_key(item: dict) -> tuple:
    """Newest-first stable key: metadata timestamp, then file mtime/name fallback."""
    stamp = item.get("backed_up") or ""
    try:
        parsed = datetime.datetime.strptime(stamp, "%Y-%m-%d %H:%M:%S")
        epoch = parsed.timestamp()
    except (ValueError, TypeError, OverflowError, OSError):
        try:
            epoch = os.path.getmtime(item["path"])
        except (OSError, KeyError, TypeError):
            try:
                d, m, y = item["date"].split("-")
                epoch = datetime.datetime(int(y), int(m), int(d)).timestamp()
            except (ValueError, AttributeError, KeyError, TypeError, OverflowError, OSError):
                epoch = 0
    return (epoch, item.get("name", ""))


def _prune_project_backups(max_keep: int = MAX_BACKUPS_PER_PROJECT) -> list:
    """Keep newest backups per project; return removed archive paths."""
    max_keep = max(1, int(max_keep))
    backups = _list_project_backups()
    by_project = {}
    for b in backups:
        by_project.setdefault(b["project"], []).append(b)
    removed = []
    for project, items in by_project.items():
        if len(items) <= max_keep:
            continue
        # Keep newest by actual backup timestamp, not date-only filename.
        # Date-only sorting can delete a recent backup when several are made
        # on the same day (the common case for interactive development).
        items_sorted = sorted(items, key=_backup_recency_key)
        to_remove = items_sorted[: len(items_sorted) - max_keep]
        for b in to_remove:
            if _remove_backup_files(b):
                removed.append(b["path"])
    return removed


def _remove_backup_files(backup: dict) -> bool:
    """Hapus ZIP + manifest + log entry. Return True kalau berhasil."""
    try:
        if backup["type"] == "zip":
            if os.path.isfile(backup["path"]):
                os.remove(backup["path"])
            manifest_path = backup["path"][:-4] + ".meta.json"
            if os.path.isfile(manifest_path):
                os.remove(manifest_path)
            _update_log_remove(backup["basename"])
        elif backup["type"] == "folder":
            shutil.rmtree(backup["path"])
        return True
    except OSError:
        return False


def _prune_file_sessions(max_keep: int = MAX_FILE_SESSIONS) -> list:
    sessions = _list_file_sessions()
    if len(sessions) <= max_keep:
        return []
    def _sort_key(s):
        name = s.get("name", "")
        return name
    sessions_sorted = sorted(sessions, key=_sort_key)
    to_remove = sessions_sorted[: len(sessions_sorted) - max_keep]
    removed = []
    for s in to_remove:
        try:
            os.remove(s["path"])
            removed.append(s["path"])
        except OSError:
            pass
    return removed


# ============================================================
# INTERNAL — COMPARE HASH
# ============================================================

def _compute_changed_files(prev_meta: dict, current_files_meta: list) -> list:
    """Bandingin file hash dari backup sebelumnya vs sekarang."""
    if not prev_meta:
        return []
    prev_files = {f.get("path"): f.get("hash") for f in prev_meta.get("files", [])}
    changed = []
    for fm in current_files_meta:
        path = fm.get("path")
        if path not in prev_files:
            changed.append({"path": path, "status": "added"})
        elif prev_files[path] != fm.get("hash"):
            changed.append({"path": path, "status": "modified"})
    current_paths = {f.get("path") for f in current_files_meta}
    for path in prev_files:
        if path not in current_paths:
            changed.append({"path": path, "status": "removed"})
    return changed


# ============================================================
# UI RENDER
# ============================================================

def _render_project_list(backups: list):
    t = get_theme()
    if not backups:
        printer.print_blank()
        printer.print_info("Belum ada project backup.")
        return
    printer.print_blank()
    printer.print_section(f"Project Backups ({len(backups)})", icon="📁")
    printer.print_blank()
    for i, b in enumerate(backups, 1):
        mode_icon = {
            "smart": "🌳", "clean": "🧹",
            "mirror": "📦", "full": "📦",
        }.get(b["mode"], "❓")
        tag = b.get("tag", "")
        tag_str = f" v{tag}" if tag else ""
        legacy_str = "  [LEGACY]" if b.get("legacy") else ""
        print(
            f"  {t.ACCENT}[{i}]{t.RESET}  "
            f"{t.WHITE}{b['project']}{t.RESET}"
            f"{t.GRAY}{tag_str}{t.RESET}  "
            f"{t.GRAY}({b['date']}){t.RESET}"
            f"{t.YELLOW}{legacy_str}{t.RESET}"
        )
        print(
            f"       {mode_icon}  "
            f"{t.GRAY}{b['file_count']} file · "
            f"{format_size(b['size'])} · "
            f"{b['mode']}{t.RESET}"
        )
        if b.get("hash_root"):
            short_hash = b["hash_root"][7:19]
            print(f"       {t.GRAY}# {short_hash}...{t.RESET}")
        print()


def _render_session_list(sessions: list):
    t = get_theme()
    if not sessions:
        printer.print_blank()
        printer.print_info("Belum ada file session.")
        return
    printer.print_blank()
    printer.print_section(f"File Sessions ({len(sessions)})", icon="🗂")
    printer.print_blank()
    for i, s in enumerate(sessions, 1):
        note_str = f'"{s["note"]}"' if s["note"] else "(no note)"
        print(
            f"  {t.ACCENT}[{i}]{t.RESET}  "
            f"{t.WHITE}{s['name']}{t.RESET}"
        )
        print(
            f"       {t.GRAY}{s['file_count']} file · "
            f"{format_size(s['size'])} · "
            f"{note_str}{t.RESET}"
        )
        print()


# ============================================================
# MODE 1 — BACKUP PROJECT
# ============================================================

def _wizard_backup_project():
    printer.print_blank()
    printer.print_section("Mode: Backup Project", icon="💾")
    printer.print_blank()

    raw = prompt_path_with_history(
        "Path project (file .py atau folder)",
        tool_id=TOOL_ID,
    )
    if not raw:
        printer.print_warn("Dibatalkan.")
        return

    project_root, entry_file, error = resolve_input_path(raw)
    if error and error != "MULTIPLE":
        printer.print_error(error)
        return
    if error == "MULTIPLE":
        entries = entry_file
        idx = prompt_choice(
            "Folder punya banyak entry point. Pilih salah satu",
            choices=entries, default_index=0,
        )
        if idx == -1:
            printer.print_warn("Dibatalkan.")
            return
        entry_file = entries[idx]

    project_name = os.path.basename(project_root.rstrip(os.sep)) or "project"

    printer.print_blank()
    printer.print_success(f"Project  : {project_name}")
    printer.print_success(f"Root     : {project_root}")
    if entry_file:
        printer.print_success(f"Entry    : {entry_file}")
    printer.print_blank()

    printer.print_info("Version tag (opsional) buat nandain milestone.")
    printer.print_info("Contoh: 2, 1.1, final, pre-refactor")
    printer.print_blank()

    tag_raw = prompt_input("Version tag", default="", show_cancel=True)
    if is_cancelled(tag_raw):
        printer.print_warn("Dibatalkan.")
        return

    tag = _sanitize_version_tag(tag_raw)
    date_str = time.strftime("%d-%m-%Y", time.localtime())
    basename = _build_backup_basename(project_name, tag, date_str)
    zip_name = basename + ".zip"
    meta_name = basename + ".meta.json"

    printer.print_blank()
    if tag:
        printer.print_success(f"Version tag : v{tag}")
    else:
        printer.print_info("Version tag : (kosong — tanpa versi)")
    printer.print_success(f"Nama backup : {zip_name}")
    printer.print_blank()

    mode_idx = prompt_choice(
        "Pilih mode backup",
        choices=[
            "Smart   — cuma file traversed (hemat disk)",
            "Clean   — semua file, skip sampah (.bak, dll)",
            "Mirror  — semua file, mentah (full raw)",
        ],
        default_index=0,
    )
    if mode_idx == -1:
        printer.print_warn("Dibatalkan.")
        return
    mode = ["smart", "clean", "mirror"][mode_idx]

    files = []
    if mode == "smart":
        if not entry_file:
            printer.print_warn("Smart butuh entry point. Fallback ke clean.")
            mode = "clean"
        else:
            printer.print_blank()
            try:
                with Spinner(f"Scanning dependency tree dari {entry_file}"):
                    tree_data = scan_dependencies(entry_file, project_root)
                    files = tree_data["visited"]
                printer.print_success(f"{len(files)} file traversed")
            except Exception as e:
                printer.print_error(f"Gagal scan: {e}")
                return

    if mode == "clean":
        printer.print_blank()
        with Spinner("Scanning semua file (skip sampah + exclude)"):
            all_files = scan_all_files(project_root)
            files = [f for f in all_files if not _should_skip_junk(f)]
        printer.print_success(
            f"{len(files)} file (skip {len(all_files) - len(files)} sampah/exclude)"
        )

    if mode == "mirror":
        printer.print_blank()
        with Spinner("Scanning semua file (mirror raw)"):
            files = scan_all_files(project_root)
        printer.print_success(f"{len(files)} file ditemukan")

    if not files:
        printer.print_warn("Gak ada file buat di-backup.")
        return

    # Hitung hash + meta file
    printer.print_blank()
    files_meta = []
    total_size = 0

    with auto_progress(f"Hashing {len(files)} file", total=len(files)) as p:
        for i, rel in enumerate(files, 1):
            abs_src = os.path.join(project_root, rel)
            if not os.path.isfile(abs_src):
                p.update(i)
                continue
            try:
                size = os.path.getsize(abs_src)
            except OSError:
                size = 0
            files_meta.append({
                "path": rel.replace(os.sep, "/"),
                "size": size,
                "hash": hash_file(abs_src, HASH_ALGO),
            })
            total_size += size
            p.update(i)

    hash_root = _compute_hash_root(files_meta)
    short_hash = hash_root[7:19]

    # Cek duplikat hash root
    prev_entry = _find_previous_log_entry(project_name, time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
    if prev_entry and prev_entry.get("hash_root") == hash_root:
        printer.print_blank()
        printer.print_warn(
            f"⚠ Backup ini identik sama backup sebelumnya ({prev_entry.get('timestamp')})."
        )
        if not prompt_yes_no("Tetap lanjut?", default="n"):
            printer.print_warn("Dibatalkan.")
            return

    # Preview pake print_card
    printer.print_card(
        "Preview Backup",
        {
            "Project": project_name,
            "Version": f"v{tag}" if tag else "(tanpa versi)",
            "Mode": mode,
            "Files": f"{len(files_meta)} file",
            "Size": format_size(total_size),
            "Hash root": short_hash + "...",
        },
        icon="👁",
    )

    if not prompt_yes_no("Lanjut backup?", default="y"):
        printer.print_warn("Dibatalkan.")
        return

    # Cek nama udah ada
    backup_root = _get_backup_root()
    target_path = os.path.join(backup_root, zip_name)
    target_meta = os.path.join(backup_root, meta_name)

    if os.path.exists(target_path):
        printer.print_blank()
        printer.print_warn(f"ZIP udah ada: {zip_name}")
        printer.print_blank()
        printer.print_bullet("[1] Overwrite")
        printer.print_bullet("[2] Rename otomatis (suffix _2)")
        printer.print_bullet("[3] Batal")
        printer.print_blank()
        choice = prompt_input(
            "Pilih [1-3, default: 3]", default="3", show_cancel=False,
        ).strip()
        if choice == "1":
            try:
                os.remove(target_path)
                if os.path.exists(target_meta):
                    os.remove(target_meta)
            except OSError as e:
                printer.print_error(f"Gagal hapus: {e}")
                return
        elif choice == "2":
            suffix = 2
            while suffix < 100:
                new_base = f"{basename}_{suffix}"
                new_zip = os.path.join(backup_root, new_base + ".zip")
                if not os.path.exists(new_zip):
                    basename = new_base
                    zip_name = new_base + ".zip"
                    meta_name = new_base + ".meta.json"
                    target_path = new_zip
                    target_meta = os.path.join(backup_root, meta_name)
                    break
                suffix += 1
            else:
                printer.print_error("Kehabisan suffix.")
                return
        else:
            printer.print_warn("Dibatalkan.")
            return

    # Bikin meta dict
    now_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    meta = {
        "version": 1,
        "project": project_name,
        "project_root": project_root,
        "version_tag": tag,
        "entry": entry_file,
        "mode": mode,
        "created_at": now_str,
        "backed_up_at": now_str,
        "file_count": len(files_meta),
        "total_size": total_size,
        "hash_root": hash_root,
        "files": files_meta,
    }

    # Bikin ZIP pake Spinner
    printer.print_blank()
    with Spinner(f"Membuat ZIP {zip_name}"):
        result = _create_project_zip(
            project_root=project_root,
            files=[fm["path"] for fm in files_meta],
            output_path=target_path,
            meta=meta,
        )

    if not result["success"]:
        printer.print_error(f"Gagal bikin ZIP: {result['error']}")
        return
    printer.print_success(
        f"ZIP dibuat: {zip_name} ({format_size(result['size'])})"
    )

    # Tulis manifest JSON
    try:
        write_json(target_meta, meta)
        printer.print_success(f"Manifest: {meta_name}")
    except OSError as e:
        printer.print_error(f"Gagal tulis manifest: {e}")

    # Append ke log
    changed_files = _compute_changed_files(
        _read_meta_from_zip(prev_entry.get("archive", "")) if prev_entry.get("archive") else {},
        files_meta,
    ) if prev_entry else []
    log_entry = {
        "timestamp": now_str,
        "project": project_name,
        "tag": tag,
        "mode": mode,
        "file_count": len(files_meta),
        "total_bytes": total_size,
        "hash_root": hash_root,
        "basename": basename,
        "archive": zip_name,
        "manifest": meta_name,
        "changed_files": changed_files,
    }
    _append_log(log_entry)
    printer.print_success("Log updated")

    # Verify pake Spinner
    printer.print_blank()
    if prompt_yes_no("Verify backup sekarang?", default="y"):
        with Spinner("Verifying backup"):
            verify = _verify_backup(target_path, files_meta)
        if verify["ok"]:
            printer.print_success(f"Verify OK: {verify['same']} file cocok")
        else:
            printer.print_warn(
                f"Verify: {verify['same']} cocok, {verify['different']} beda"
            )

    # Rotation: show policy and post-run count so the retention behavior is clear.
    printer.print_blank()
    before_rotation = [b for b in _list_project_backups() if b.get("project") == _sanitize_name(project_name, 40)]
    printer.print_info(
        f"Rotation: simpan maksimal {MAX_BACKUPS_PER_PROJECT} backup untuk project ini "
        f"({len(before_rotation)} terdeteksi)."
    )
    with Spinner("Cek rotation"):
        removed = _prune_project_backups()
    remaining = [b for b in _list_project_backups() if b.get("project") == _sanitize_name(project_name, 40)]
    if removed:
        printer.print_success(f"{len(removed)} backup lama dihapus; tersisa {len(remaining)} backup.")
        for old_path in removed[:3]:
            printer.print_bullet(os.path.basename(old_path), indent=4)
        if len(removed) > 3:
            printer.print_info(f"dan {len(removed) - 3} lainnya")
    else:
        printer.print_info(
            f"Belum perlu menghapus backup: {len(remaining)}/{MAX_BACKUPS_PER_PROJECT} tersimpan."
        )

    # Summary pake print_card
    printer.print_card(
        "Backup Selesai",
        {
            "Project": project_name,
            "Version": f"v{tag}" if tag else "(tanpa versi)",
            "Mode": mode,
            "Files": f"{len(files_meta)} ({format_size(total_size)})",
            "Hash root": short_hash + "...",
            "Lokasi": target_path,
            "Changed": f"{len(changed_files)} file" if changed_files else "-",
        },
        icon="✓",
        color=get_theme().GREEN,
    )

    printer.print_success("Selesai.")


def _verify_backup(zip_path: str, files_meta: list) -> dict:
    """Verify isi ZIP vs hash di meta tanpa extract ke disk."""
    try:
        expected = {str(fm.get("path", "")): fm.get("hash", "") for fm in files_meta}
        same = 0
        different = 0
        seen = set()

        with zipfile.ZipFile(zip_path, "r") as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                rel = info.filename
                if rel not in expected:
                    # Entry ekstra tidak membatalkan hash file yang tercatat.
                    continue
                seen.add(rel)
                hasher = hashlib.new(HASH_ALGO)
                try:
                    with zf.open(info, "r") as source:
                        while True:
                            chunk = source.read(65536)
                            if not chunk:
                                break
                            hasher.update(chunk)
                    actual = hasher.hexdigest()
                except (OSError, RuntimeError, zipfile.BadZipFile):
                    actual = ""
                if actual == expected[rel]:
                    same += 1
                else:
                    different += 1

        # Entry yang tercatat di meta tapi tidak ada di ZIP.
        different += len(set(expected) - seen)
        return {"ok": different == 0, "same": same, "different": different}
    except (zipfile.BadZipFile, OSError, ValueError):
        return {"ok": False, "same": 0, "different": len(files_meta)}


# ============================================================
# MODE 2 — BACKUP FILE SPESIFIK
# ============================================================

def _prompt_multiline_paths() -> list:
    t = get_theme()
    printer.print_info("Ketik 1 path per baris. Enter kosong buat selesai.")
    printer.print_info("Ketik '0' atau 'batal' buat cancel.")
    printer.print_blank()
    paths = []
    while True:
        try:
            if t.enabled:
                line = input(f"  {t.ACCENT}→{t.RESET}  ").strip()
            else:
                line = input("  →  ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            break
        if line.lower() in ("0", "batal", "cancel", "q", "quit"):
            return []
        paths.append(line)
    return paths


def _wizard_backup_files():
    printer.print_blank()
    printer.print_section("Mode: Backup File Spesifik", icon="📄")
    printer.print_blank()
    printer.print_info("💡 Tips: Select file di Mixplorer → Copy path → paste di sini.")
    printer.print_blank()

    raw_paths = _prompt_multiline_paths()
    if not raw_paths:
        printer.print_warn("Dibatalkan / kosong.")
        return

    if len(raw_paths) > MAX_FILES_PER_SESSION:
        printer.print_error(
            f"Maks {MAX_FILES_PER_SESSION} file per sesi. "
            f"Lo masukin {len(raw_paths)} file."
        )
        return

    printer.print_blank()
    with Spinner("Validasi file"):
        valid_files = []
        invalid_files = []
        for raw in raw_paths:
            result = _validate_file(raw)
            if result["valid"]:
                if result["size"] > SIZE_WARN_THRESHOLD:
                    printer.print_warn(
                        f"File gede: {os.path.basename(raw)} "
                        f"({format_size(result['size'])})"
                    )
                valid_files.append(result)
            else:
                invalid_files.append(result)

    printer.print_blank()
    printer.print_section("Preview", icon="👁")
    printer.print_blank()
    t = get_theme()

    if valid_files:
        print(f"  {t.GREEN}✓ File valid ({len(valid_files)}):{t.RESET}")
        for v in valid_files:
            print(
                f"    {t.GREEN}✓{t.RESET}  "
                f"{os.path.basename(v['path'])}  "
                f"{t.GRAY}({format_size(v['size'])}){t.RESET}"
            )
        print()

    if invalid_files:
        print(f"  {t.RED}✗ File invalid ({len(invalid_files)}):{t.RESET}")
        for inv in invalid_files:
            print(
                f"    {t.RED}✗{t.RESET}  "
                f"{inv['path']}  "
                f"{t.GRAY}({inv['error']}){t.RESET}"
            )
        print()

    if not valid_files:
        printer.print_error("Gak ada file valid buat di-backup.")
        return

    abs_paths = [v["path"] for v in valid_files]
    base_path = _find_common_base(abs_paths)
    printer.print_kv("Common base", base_path or "(gak ketemu)")
    printer.print_blank()

    note = prompt_input(
        "Note (opsional) — misal: sebelum refactor",
        default="", show_cancel=True,
    )
    if is_cancelled(note):
        printer.print_warn("Dibatalkan.")
        return

    printer.print_blank()
    printer.print_section("Konfirmasi", icon="❓")
    printer.print_kv("File", f"{len(valid_files)} file")
    printer.print_kv("Note", note or "(no note)")
    if base_path:
        printer.print_kv("Base", base_path)
    printer.print_blank()

    if not prompt_yes_no("Backup jadi 1 ZIP?", default="y"):
        printer.print_warn("Dibatalkan.")
        return

    session_id = _generate_session_id(note)
    sessions_dir = _get_sessions_dir()
    zip_path = os.path.join(sessions_dir, f"{session_id}.zip")

    if os.path.exists(zip_path):
        suffix = 2
        while suffix < 100:
            new_id = f"{session_id}_{suffix}"
            new_path = os.path.join(sessions_dir, f"{new_id}.zip")
            if not os.path.exists(new_path):
                session_id = new_id
                zip_path = new_path
                break
            suffix += 1
        else:
            printer.print_error("Kehabisan suffix.")
            return

    files_meta = []
    total_size = 0
    with auto_progress(f"Hashing {len(valid_files)} file", total=len(valid_files)) as p:
        for i, v in enumerate(valid_files, 1):
            rel = _relative_to_base(v["path"], base_path) if base_path else os.path.basename(v["path"])
            files_meta.append({
                "path": rel.replace(os.sep, "/"), "original": v["path"],
                "size": v["size"], "hash": hash_file(v["path"], HASH_ALGO),
                "is_binary": v["is_binary"],
            })
            total_size += v["size"]
            p.update(i)

    meta = {
        "session_id": session_id,
        "created": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        "note": note, "base_path": base_path,
        "file_count": len(valid_files),
        "total_size": total_size,
        "files": files_meta,
    }

    printer.print_blank()
    with Spinner(f"Membuat ZIP {session_id}"):
        try:
            os.makedirs(sessions_dir, exist_ok=True)
            with zipfile.ZipFile(zip_path, "w", COMPRESSION) as zf:
                zf.writestr(META_FILENAME, json.dumps(meta, indent=2, ensure_ascii=False))
                for v in valid_files:
                    rel = _relative_to_base(v["path"], base_path) if base_path else os.path.basename(v["path"])
                    arcname = rel.replace(os.sep, "/")
                    zf.write(v["path"], arcname=arcname)
            zip_size = os.path.getsize(zip_path)
            success = True
            error = None
        except (OSError, zipfile.BadZipFile) as e:
            success = False
            error = str(e)
            zip_size = 0

    if not success:
        printer.print_error(f"Gagal bikin ZIP: {error}")
        return

    printer.print_success(
        f"ZIP dibuat: {os.path.basename(zip_path)} ({format_size(zip_size)})"
    )

    printer.print_blank()
    with Spinner("Cek rotation"):
        removed = _prune_file_sessions()
    if removed:
        printer.print_success(f"{len(removed)} sesi lama dihapus")
    else:
        printer.print_success("Rotation OK")

    printer.print_card(
        "Session Selesai",
        {
            "Session ID": session_id,
            "Files": str(len(valid_files)),
            "Size ZIP": format_size(zip_size),
            "Lokasi": zip_path,
            "Note": note or "(no note)",
        },
        icon="✓",
        color=get_theme().GREEN,
    )

    printer.print_success("Selesai.")


# ============================================================
# MODE 3 — LIST
# ============================================================

def _wizard_list():
    printer.print_blank()
    printer.print_section("Mode: List Backups", icon="📋")
    printer.print_blank()
    project_backups = _list_project_backups()
    file_sessions = _list_file_sessions()
    if not project_backups and not file_sessions:
        printer.print_info("Belum ada backup.")
        return
    if project_backups:
        _render_project_list(project_backups)
    if file_sessions:
        _render_session_list(file_sessions)

    printer.print_blank()
    printer.print_section("Summary", icon="📊")
    printer.print_blank()
    t = get_theme()
    if project_backups:
        total_size = sum(b["size"] for b in project_backups)
        print(
            f"  {t.ACCENT}📁 Project{t.RESET}  "
            f"{t.GRAY}({len(project_backups)} backup, "
            f"{format_size(total_size)}){t.RESET}"
        )
    if file_sessions:
        total_size = sum(s["size"] for s in file_sessions)
        print(
            f"  {t.ACCENT}🗂  Session{t.RESET}  "
            f"{t.GRAY}({len(file_sessions)} sesi, "
            f"{format_size(total_size)}){t.RESET}"
        )
    printer.print_blank()


# ============================================================
# MODE 4 — RESTORE
# ============================================================

def _restore_zip_backup(backup: dict) -> None:
    meta = _read_meta_from_zip(backup["path"])
    if not meta:
        printer.print_error("ZIP gak punya metadata.")
        return
    project_root = meta.get("project_root")
    if not project_root or not os.path.isdir(project_root):
        printer.print_error(f"Project root gak valid: {project_root}")
        return

    printer.print_blank()
    printer.print_section("Konfirmasi Restore", icon="⚠")
    printer.print_kv("Backup", backup["name"])
    printer.print_kv("Project", project_root)
    if meta.get("version_tag"):
        printer.print_kv("Version", f"v{meta['version_tag']}")
    printer.print_kv("Backed up", meta.get("backed_up_at", "—"))
    printer.print_kv("Files", str(meta.get("file_count", 0)))
    printer.print_blank()
    printer.print_warn("Restore bakal OVERWRITE file di project. Lanjut?")
    printer.print_blank()
    if not prompt_yes_no("Lanjut?", default="n"):
        printer.print_warn("Dibatalkan.")
        return

    printer.print_blank()
    safety_root = _get_backup_root()
    safety_name = (
        f"{backup['project']}_pre_restore_"
        f"{time.strftime('%d-%m-%Y_%H%M%S', time.localtime())}"
    )
    safety_path = os.path.join(safety_root, safety_name + ".zip")

    with Spinner("Bikin safety backup"):
        try:
            current_files = scan_all_files(project_root)
            with zipfile.ZipFile(safety_path, "w", COMPRESSION) as zf:
                for rel in current_files:
                    abs_path = os.path.join(project_root, rel)
                    if os.path.isfile(abs_path):
                        zf.write(abs_path, arcname=rel.replace(os.sep, "/"))
            success = True
        except OSError as e:
            success = False
            error_msg = str(e)

    if success:
        printer.print_success(f"Safety backup: {safety_name}.zip")
    else:
        printer.print_error(f"Gagal safety backup: {error_msg}")
        if not prompt_yes_no("Lanjut restore tanpa safety backup?", default="n"):
            return

    printer.print_blank()
    files_meta = meta.get("files", [])
    copied = 0
    failed = []

    with auto_progress(f"Restoring {len(files_meta)} file", total=len(files_meta)) as p:
        try:
            with zipfile.ZipFile(backup["path"], "r") as zf:
                namelist = set(zf.namelist())
                for i, fm in enumerate(files_meta, 1):
                    rel = fm.get("path", "")
                    if not rel or rel not in namelist:
                        failed.append(rel or "(unknown)")
                        p.update(i)
                        continue
                    dst = os.path.join(project_root, rel)
                    try:
                        os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
                        with zf.open(rel) as src, open(dst, "wb") as out:
                            shutil.copyfileobj(src, out)
                        copied += 1
                    except OSError as e:
                        failed.append(f"{rel} ({e})")
                    p.update(i)
        except (zipfile.BadZipFile, OSError) as e:
            printer.print_error(f"Gagal buka ZIP: {e}")
            return

    printer.print_blank()
    printer.print_success(f"{copied} file di-restore")
    if failed:
        printer.print_warn(f"{len(failed)} file gagal:")
        for f in failed[:5]:
            printer.print_bullet(f, indent=6)
    printer.print_blank()
    printer.print_success("Selesai.")


def _restore_legacy_folder(backup: dict) -> None:
    meta_path = os.path.join(backup["path"], ".backup_meta.json")
    meta = read_json(meta_path, default={})
    if not meta:
        printer.print_error("Backup gak punya metadata.")
        return
    project_root = meta.get("project")
    if not project_root or not os.path.isdir(project_root):
        printer.print_error(f"Project root gak valid: {project_root}")
        return

    printer.print_blank()
    printer.print_section("Konfirmasi Restore (LEGACY)", icon="⚠")
    printer.print_kv("Backup", backup["name"])
    printer.print_kv("Project", project_root)
    if meta.get("version_tag"):
        printer.print_kv("Version", f"v{meta['version_tag']}")
    printer.print_kv("Files", str(meta.get("file_count", 0)))
    printer.print_blank()
    if not prompt_yes_no("Lanjut?", default="n"):
        printer.print_warn("Dibatalkan.")
        return

    printer.print_blank()
    traversed = meta.get("traversed", [])
    copied = 0
    failed = []

    with auto_progress(f"Restoring {len(traversed)} file", total=len(traversed)) as p:
        for i, rel in enumerate(traversed, 1):
            src = os.path.join(backup["path"], rel)
            dst = os.path.join(project_root, rel)
            if not os.path.isfile(src):
                failed.append(rel)
                p.update(i)
                continue
            try:
                os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
                shutil.copy2(src, dst)
                copied += 1
            except OSError as e:
                failed.append(f"{rel} ({e})")
            p.update(i)

    printer.print_blank()
    printer.print_success(f"{copied} file di-restore")
    if failed:
        printer.print_warn(f"{len(failed)} file gagal:")
        for f in failed[:5]:
            printer.print_bullet(f, indent=6)
    printer.print_blank()
    printer.print_success("Selesai.")


def _restore_file_session(session: dict) -> None:
    t = get_theme()
    zip_path = session["path"]
    meta = session.get("meta", {})
    if not meta:
        printer.print_error("ZIP gak punya metadata.")
        return
    files = meta.get("files", [])
    base_path = meta.get("base_path", "")
    if not files:
        printer.print_error("Meta gak punya list file.")
        return

    printer.print_blank()
    printer.print_section("Konfirmasi Restore", icon="⚠")
    printer.print_kv("Session", session["name"])
    printer.print_kv("Created", meta.get("created", "—"))
    printer.print_kv("Note", meta.get("note", "(no note)"))
    printer.print_kv("Files", str(len(files)))
    if base_path:
        printer.print_kv("Base", base_path)
    printer.print_blank()
    printer.print_info("File yang bakal di-restore:")
    for fm in files[:10]:
        print(f"    {t.GRAY}•{t.RESET}  {fm['path']}  →  {fm['original']}")
    if len(files) > 10:
        printer.print_info(f"    ... dan {len(files) - 10} file lain")
    printer.print_blank()
    printer.print_warn("Restore bakal OVERWRITE file di original path. Lanjut?")
    printer.print_blank()
    if not prompt_yes_no("Lanjut?", default="n"):
        printer.print_warn("Dibatalkan.")
        return

    printer.print_blank()
    restored = 0
    failed = []

    with auto_progress(f"Restoring {len(files)} file", total=len(files)) as p:
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                namelist = set(zf.namelist())
                for i, fm in enumerate(files, 1):
                    rel = fm["path"].replace(os.sep, "/")
                    original = fm["original"]
                    if rel not in namelist:
                        failed.append(f"{rel} (gak ada di ZIP)")
                        p.update(i)
                        continue
                    try:
                        os.makedirs(os.path.dirname(original) or ".", exist_ok=True)
                        with zf.open(rel) as src, open(original, "wb") as dst:
                            shutil.copyfileobj(src, dst)
                        restored += 1
                    except OSError as e:
                        failed.append(f"{rel} ({e})")
                    p.update(i)
        except (zipfile.BadZipFile, OSError) as e:
            printer.print_error(f"Gagal buka ZIP: {e}")
            return

    printer.print_blank()
    printer.print_success(f"{restored} file di-restore")
    if failed:
        printer.print_warn(f"{len(failed)} file gagal:")
        for f in failed[:5]:
            printer.print_bullet(f, indent=6)
    printer.print_blank()
    printer.print_success("Selesai.")


def _wizard_restore():
    printer.print_blank()
    printer.print_section("Mode: Restore Backup", icon="🔄")
    printer.print_blank()
    project_backups = _list_project_backups()
    file_sessions = _list_file_sessions()
    if not project_backups and not file_sessions:
        printer.print_info("Belum ada backup.")
        return
    all_items = []
    for b in project_backups:
        all_items.append(("project", b))
    for s in file_sessions:
        all_items.append(("session", s))
    printer.print_info("Pilih backup yang mau di-restore:")
    printer.print_blank()
    t = get_theme()
    for i, (typ, item) in enumerate(all_items, 1):
        if typ == "project":
            tag = item.get("tag", "")
            tag_str = f" v{tag}" if tag else ""
            legacy = " [LEGACY]" if item.get("legacy") else ""
            label = f"📁 Project: {item['project']}{tag_str} ({item['date']}){legacy}"
            info = f"{item['file_count']} file · {format_size(item['size'])}"
        else:
            label = f"🗂  Session: {item['name']}"
            note = f' "{item["note"]}"' if item["note"] else ""
            info = f"{item['file_count']} file · {format_size(item['size'])}{note}"
        print(f"  {t.ACCENT}[{i}]{t.RESET}  {t.WHITE}{label}{t.RESET}")
        print(f"       {t.GRAY}{info}{t.RESET}")
        print()
    idx = prompt_choice(
        "Pilih backup",
        choices=[f"[{typ}] {item['name']}" for typ, item in all_items],
        default_index=0,
    )
    if idx == -1:
        printer.print_warn("Dibatalkan.")
        return
    typ, item = all_items[idx]
    if typ == "project":
        if item.get("legacy"):
            _restore_legacy_folder(item)
        else:
            _restore_zip_backup(item)
    else:
        _restore_file_session(item)


# ============================================================
# MODE 5 — PRUNE
# ============================================================

def _wizard_prune():
    printer.print_blank()
    printer.print_section("Mode: Prune Backups", icon="🗑")
    printer.print_blank()
    project_backups = _list_project_backups()
    file_sessions = _list_file_sessions()
    if not project_backups and not file_sessions:
        printer.print_info("Belum ada backup.")
        return
    printer.print_info(
        f"Retensi otomatis: maksimal {MAX_BACKUPS_PER_PROJECT} backup per project "
        f"dan {MAX_FILE_SESSIONS} file session. Di bawah batas, tidak ada yang dihapus."
    )
    mode = prompt_choice(
        "Pilih mode prune",
        choices=[
            f"Auto — pertahankan {MAX_BACKUPS_PER_PROJECT} project / {MAX_FILE_SESSIONS} session terbaru",
            "Manual — pilih backup yang mau dihapus",
        ],
        default_index=0,
    )
    if mode == -1:
        printer.print_warn("Dibatalkan.")
        return
    if mode == 0:
        printer.print_blank()
        with Spinner("Auto-prune"):
            removed_p = _prune_project_backups()
            removed_s = _prune_file_sessions()
        total = len(removed_p) + len(removed_s)
        if total == 0:
            printer.print_info(
                f"Tidak ada yang dihapus: batas {MAX_BACKUPS_PER_PROJECT} backup/project "
                f"dan {MAX_FILE_SESSIONS} session belum terlampaui."
            )
        else:
            if removed_p:
                printer.print_success(f"{len(removed_p)} project backup dihapus")
            if removed_s:
                printer.print_success(f"{len(removed_s)} file session dihapus")
        return

    all_items = []
    for b in project_backups:
        all_items.append(("project", b))
    for s in file_sessions:
        all_items.append(("session", s))
    printer.print_blank()
    printer.print_info("Pilih nomor yang mau dihapus (mis: 1,3,5 atau 1-3):")
    printer.print_blank()
    t = get_theme()
    for i, (typ, item) in enumerate(all_items, 1):
        icon = "📁" if typ == "project" else "🗂 "
        legacy = " [LEGACY]" if item.get("legacy") else ""
        print(
            f"  {t.ACCENT}[{i}]{t.RESET}  "
            f"{icon}  {item['name']}{legacy}  "
            f"{t.GRAY}({format_size(item['size'])}){t.RESET}"
        )
    printer.print_blank()
    raw = prompt_input("Nomor backup", show_cancel=True)
    if is_cancelled(raw) or not raw:
        printer.print_warn("Dibatalkan.")
        return
    indices = []
    for part in raw.split(","):
        part = part.strip()
        if "-" in part:
            try:
                a, b = part.split("-", 1)
                a, b = int(a), int(b)
                for i in range(min(a, b), max(a, b) + 1):
                    if 1 <= i <= len(all_items):
                        indices.append(i - 1)
            except ValueError:
                continue
        elif part.isdigit():
            i = int(part)
            if 1 <= i <= len(all_items):
                indices.append(i - 1)
    if not indices:
        printer.print_error("Gak ada nomor valid.")
        return
    indices = sorted(set(indices))
    printer.print_blank()
    printer.print_warn(f"{len(indices)} backup bakal dihapus:")
    for i in indices:
        typ, item = all_items[i]
        printer.print_bullet(item["name"], indent=6)
    printer.print_blank()
    if not prompt_yes_no("Lanjut hapus?", default="n"):
        printer.print_warn("Dibatalkan.")
        return
    removed = 0
    with Spinner("Menghapus backup"):
        for i in indices:
            typ, item = all_items[i]
            if typ == "project":
                if _remove_backup_files(item):
                    removed += 1
            else:
                try:
                    os.remove(item["path"])
                    removed += 1
                except OSError:
                    pass
    printer.print_blank()
    printer.print_success(f"{removed} backup dihapus")


# ============================================================
# MODE 6 — HISTORY
# ============================================================

def _wizard_history():
    printer.print_blank()
    printer.print_section("Mode: History Backup", icon="📜")
    printer.print_blank()
    log = _read_log()
    entries = log.get("entries", [])
    if not entries:
        printer.print_info("Belum ada history backup.")
        printer.print_info("Backup project dulu biar muncul di sini.")
        return

    entries_sorted = sorted(
        entries, key=lambda e: e.get("timestamp", ""), reverse=True
    )

    t = get_theme()
    printer.print_info(f"Total {len(entries_sorted)} backup tercatat:")
    printer.print_blank()
    for i, e in enumerate(entries_sorted, 1):
        tag = e.get("tag", "")
        tag_str = f" v{tag}" if tag else ""
        changed = e.get("changed_files", [])
        changed_str = f" · {len(changed)} changed" if changed else ""
        print(
            f"  {t.ACCENT}[{i}]{t.RESET}  "
            f"{t.GRAY}{e.get('timestamp', '?')}{t.RESET}"
        )
        print(
            f"       {t.WHITE}{e.get('project', '?')}{tag_str}{t.RESET}  "
            f"{t.GRAY}· {e.get('mode', '?')} · "
            f"{e.get('file_count', 0)} file · "
            f"{format_size(e.get('total_bytes', 0))}{changed_str}{t.RESET}"
        )
        if e.get("archive"):
            print(f"       {t.GRAY}→ {e['archive']}{t.RESET}")
        print()

    printer.print_blank()
    printer.print_info("Pilih nomor buat lihat detail perubahan:")
    raw = prompt_input("Nomor (kosong = skip)", default="", show_cancel=True)
    if is_cancelled(raw) or not raw.strip():
        return
    if not raw.strip().isdigit():
        printer.print_error("Nomor gak valid.")
        return
    idx = int(raw.strip()) - 1
    if not (0 <= idx < len(entries_sorted)):
        printer.print_error("Nomor di luar range.")
        return
    entry = entries_sorted[idx]
    printer.print_blank()
    printer.print_section(f"Detail: {entry.get('archive', '?')}", icon="🔍")
    printer.print_blank()
    printer.print_kv("Timestamp", entry.get("timestamp", "?"))
    printer.print_kv("Project", entry.get("project", "?"))
    printer.print_kv("Version", f"v{entry.get('tag')}" if entry.get("tag") else "(kosong)")
    printer.print_kv("Mode", entry.get("mode", "?"))
    printer.print_kv("Files", str(entry.get("file_count", 0)))
    printer.print_kv("Size", format_size(entry.get("total_bytes", 0)))
    printer.print_kv("Hash root", entry.get("hash_root", "?")[7:19] + "...")
    printer.print_blank()
    changed = entry.get("changed_files", [])
    if not changed:
        printer.print_info("Gak ada perubahan dari backup sebelumnya (atau ini backup pertama).")
    else:
        printer.print_info(f"{len(changed)} file berubah dari backup sebelumnya:")
        printer.print_blank()
        for c in changed[:30]:
            status = c.get("status", "?")
            icon = {"added": "＋", "modified": "≠", "removed": "－"}.get(status, "?")
            color = {"added": t.GREEN, "modified": t.YELLOW, "removed": t.RED}.get(status, t.GRAY)
            print(f"    {color}{icon}{t.RESET}  {c.get('path', '?')}  {t.GRAY}({status}){t.RESET}")
        if len(changed) > 30:
            printer.print_info(f"    ... dan {len(changed) - 30} file lain")
    printer.print_blank()


# ============================================================
# WIZARD — MAIN
# ============================================================


def _restore_zip_backup_api(zip_path: str, target_root: str = "", safety: bool = True) -> dict:
    """Restore ZIP backup without CLI prompts; intended for local GUI/API use."""
    if not os.path.isfile(zip_path):
        return {"ok": False, "error": f"ZIP tidak ditemukan: {zip_path}"}

    meta = _read_meta_from_zip(zip_path)
    if not meta:
        return {"ok": False, "error": "ZIP gak punya metadata."}

    project_root = target_root or meta.get("project_root")
    if not project_root:
        return {"ok": False, "error": "Target project root tidak tersedia di metadata."}
    project_root = os.path.abspath(os.path.expanduser(project_root))
    if not os.path.isdir(project_root):
        return {"ok": False, "error": f"Target project root gak valid: {project_root}"}

    files_meta = meta.get("files", [])
    if not isinstance(files_meta, list) or not files_meta:
        return {"ok": False, "error": "Metadata ZIP tidak punya daftar file."}

    safety_path = None
    if safety:
        safety_name = (
            f"{Path(project_root).name}_pre_restore_"
            f"{time.strftime('%d-%m-%Y_%H%M%S', time.localtime())}.zip"
        )
        safety_path = os.path.join(_get_backup_root(), safety_name)
        try:
            current_files = scan_all_files(project_root)
            with zipfile.ZipFile(safety_path, "w", COMPRESSION) as zf:
                for rel in current_files:
                    abs_path = os.path.join(project_root, rel)
                    if os.path.isfile(abs_path):
                        zf.write(abs_path, arcname=rel.replace(os.sep, "/"))
        except (OSError, zipfile.BadZipFile) as exc:
            try:
                os.remove(safety_path)
            except OSError:
                pass
            return {"ok": False, "error": f"Gagal membuat safety backup: {exc}"}

    copied = 0
    failed = []
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            namelist = set(zf.namelist())
            for fm in files_meta:
                rel = str(fm.get("path", "")).replace("\\", "/").lstrip("/")
                if not rel or rel not in namelist:
                    failed.append(rel or "(unknown)")
                    continue
                # Prevent ZIP path traversal during restore.
                destination = (Path(project_root) / rel).resolve()
                root_path = Path(project_root).resolve()
                if root_path not in destination.parents and destination != root_path:
                    failed.append(f"{rel} (path traversal)")
                    continue
                try:
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    with zf.open(rel) as src, destination.open("wb") as out:
                        shutil.copyfileobj(src, out)
                    copied += 1
                except OSError as exc:
                    failed.append(f"{rel} ({exc})")
    except (zipfile.BadZipFile, OSError) as exc:
        return {"ok": False, "error": f"Gagal buka ZIP: {exc}", "safety_backup": safety_path}

    return {
        "ok": True,
        "backup": os.path.abspath(zip_path),
        "project_root": project_root,
        "copied": copied,
        "failed": failed,
        "safety_backup": safety_path,
    }


# ============================================================
# API MODE (PR-09)
# ============================================================
def _do_work(params=None):
    params=params or {}; action=str(params.get("action","list"))
    if action=="list":
        return {"ok":True,"project_backups":_list_project_backups(),"file_sessions":_list_file_sessions()}
    if action=="prune":
        project=_prune_project_backups(int(params.get("max_keep",MAX_BACKUPS_PER_PROJECT))); sessions=_prune_file_sessions(int(params.get("max_file_sessions",MAX_FILE_SESSIONS)))
        return {"ok":True,"removed_project":project,"removed_sessions":sessions}
    if action=="verify":
        path=str(params.get("path") or "");
        if not path: return {"ok":False,"error":"path wajib diisi"}
        return {"ok":True,"result":_verify_backup(path,params.get("files_meta",[]))}
    if action=="restore":
        path=str(params.get("path") or "")
        if not path: return {"ok":False,"error":"path wajib diisi"}
        return _restore_zip_backup_api(path, str(params.get("target_root") or ""), bool(params.get("safety",True)))
    return {"ok":False,"error":f"action API yang tersedia: list, prune, verify, restore"}

def run_api(params=None): return _do_work(params)

def run_wizard():
    printer.print_section("Backup Rotator", icon="💾")
    printer.print_info("Backup pintar dengan rotation & verifikasi")
    printer.print_info("Ketik '0' di prompt manapun buat batal")
    printer.print_blank()
    mode = prompt_choice(
        "Pilih mode",
        choices=[
            "Backup Project (smart / clean / mirror)",
            "Backup File Spesifik (multi → 1 ZIP)",
            "List Backups",
            "Restore Backup",
            "Prune Backups",
            "Lihat History Backup",
        ],
        default_index=0,
    )
    if mode == -1:
        printer.print_warn("Dibatalkan.")
        return
    if mode == 0:
        _wizard_backup_project()
    elif mode == 1:
        _wizard_backup_files()
    elif mode == 2:
        _wizard_list()
    elif mode == 3:
        _wizard_restore()
    elif mode == 4:
        _wizard_prune()
    elif mode == 5:
        _wizard_history()


# ============================================================
# SELF-TEST
# ============================================================

if __name__ == "__main__":
    run_wizard()