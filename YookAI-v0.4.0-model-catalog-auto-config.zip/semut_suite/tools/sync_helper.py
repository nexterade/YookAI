"""
tools/sync_helper.py — Sync 2 Folder dengan Hash-Based Diff (v2.2)

Fitur:
    - Mode 1: Compare (dry-run) — list file beda, gak ada perubahan
    - Mode 2: Sync 1-Arah (source → target) + opsi mirror (delete extra)
    - Mode 3: Verify — cek integritas (hash only)

v2.2 changes:
    - Integrasi core.exclude — file yang ke-exclude gak di-scan/hash
    - Animasi loading pake ui.spinner

Filosofi:
    Hash-based, bukan timestamp. Timestamp bisa bohong.
    Konfirmasi dulu sebelum eksekusi. Safety first.
    Mirror mode = sinkron beneran (hapus yang gak ada di source).

Output:
    CLI + export ke semut/output/<project>_sync_<timestamp>.txt

History:
    Path source & target disimpen di semut/.path_history.json
    biar gak perlu ketik ulang.

Exclude:
    File config / privacy (.path_history.json) gak di-sync.
    File di .exclude.json juga otomatis gak di-scan.
"""

import os
import re
import time
import shutil

from semut_suite.ui import printer
from semut_suite.ui.theme import get_theme
from semut_suite.ui.prompt import (
    prompt_input, prompt_choice, prompt_yes_no,
    is_cancelled,
)
from semut_suite.ui.spinner import auto_progress

from semut_suite.core.utils import read_json, write_json, format_size, get_output_dir

from semut_suite.core.history import (
    prompt_path_with_history,
    prompt_pair_with_history,
    add_pair,
)

from semut_suite.core.exclude import is_excluded


from semut_suite.tools.file_hasher import (
    hash_file,
    hash_files,
    HASH_ALGO,
)


# ============================================================
# TOOL_META
# ============================================================

TOOL_META = {
    "id":       "sync_helper",
    "name":     "Sync Helper",
    "desc":     "Sync 2 folder dengan hash-based diff",
    "category": "file",
    "icon":     "🔄",
    "order":    5,
}


# ============================================================
# CONSTANTS
# ============================================================

OUTPUT_DIR = "output"
TOOL_ID = "sync_helper"

# File config / privacy yang gak boleh di-sync
EXCLUDED_FILES = {
    ".path_history.json",
    "password_vault.enc",
    ".exclude.json",
}


# ============================================================
# INTERNAL — VALIDASI FOLDER
# ============================================================

def _validate_folder(path: str) -> dict:
    """
    Validasi 1 folder.

    Return:
        {"path": abs, "valid": bool, "error": str | None, "file_count": int}
    """
    result = {
        "path":       path,
        "valid":      False,
        "error":      None,
        "file_count": 0,
    }

    if not path:
        result["error"] = "Path kosong"
        return result

    expanded = os.path.expanduser(path.strip())

    if not os.path.exists(expanded):
        result["error"] = f"Folder gak ada: {path}"
        return result

    if not os.path.isdir(expanded):
        result["error"] = f"Bukan folder: {path}"
        return result

    if not os.access(expanded, os.R_OK):
        result["error"] = f"Folder gak bisa dibaca: {path}"
        return result

    result["path"] = expanded
    result["valid"] = True
    return result


def _scan_all_files(project_root: str) -> list:
    """Scan file secara lokal tanpa bergantung pada private/public API tool lain."""
    found = []
    for root, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if not is_excluded(d)]
        for filename in files:
            full = os.path.join(root, filename)
            rel = os.path.relpath(full, project_root)
            if is_excluded(rel) or _should_skip_file(rel):
                continue
            found.append(rel)
    return sorted(found)


def _should_skip_file(rel_path: str) -> bool:
    """Cek apakah file harus di-skip (config / privacy)."""
    filename = os.path.basename(rel_path)
    normalized = rel_path.replace("\\", "/").strip("/")
    return filename in EXCLUDED_FILES or normalized == "vault/password_vault.enc"


# ============================================================
# INTERNAL — HASH FOLDER
# ============================================================

def _hash_folder(project_root: str, verbose: bool = True) -> dict:
    """
    Scan + hash semua file di folder.

    Return:
        {
            "hashes": dict {rel: {"hash", "size"}},
            "errors": list[str],
        }
    """
    if verbose:
        printer.print_info(f"Scanning & hashing: {project_root}...")

    files = _scan_all_files(project_root)

    if not files:
        return {"hashes": {}, "errors": []}

    # Filter exclude & file config
    files = [
        f for f in files
        if not is_excluded(f) and not _should_skip_file(f)
    ]

    if not files:
        return {"hashes": {}, "errors": []}

    errors = []
    hashes = {}

    total = len(files)

    if verbose:
        progress = auto_progress(f"Hashing ({total} file)", total=total)
        progress.__enter__()
    else:
        progress = None

    for i, rel in enumerate(files, 1):
        abs_path = os.path.join(project_root, rel)

        if not os.path.isfile(abs_path):
            if progress:
                progress.update(i)
            continue

        file_hash = hash_file(abs_path, HASH_ALGO)

        if not file_hash:
            errors.append(f"{rel} (gagal hash)")
            if progress:
                progress.update(i)
            continue

        try:
            size = os.path.getsize(abs_path)
        except OSError:
            size = 0

        hashes[rel] = {"hash": file_hash, "size": size}

        if progress:
            progress.update(i)

    if progress:
        progress.done()

    return {"hashes": hashes, "errors": errors}


# ============================================================
# INTERNAL — DIFF FOLDERS
# ============================================================

def _diff_folders(hashes_a: dict, hashes_b: dict) -> dict:
    """
    Bandingin 2 hash map.

    Return:
        {
            "only_in_source": list[str],
            "only_in_target": list[str],
            "different":      list[dict],
            "same":           list[str],
        }
    """
    result = {
        "only_in_source": [],
        "only_in_target": [],
        "different":      [],
        "same":           [],
    }

    all_paths = set(hashes_a.keys()) | set(hashes_b.keys())

    for path in sorted(all_paths):
        in_a = path in hashes_a
        in_b = path in hashes_b

        if in_a and in_b:
            hash_a = hashes_a[path]["hash"]
            hash_b = hashes_b[path]["hash"]

            if hash_a == hash_b:
                result["same"].append(path)
            else:
                result["different"].append({
                    "path":     path,
                    "src_hash": hash_a,
                    "dst_hash": hash_b,
                    "src_size": hashes_a[path]["size"],
                    "dst_size": hashes_b[path]["size"],
                })
        elif in_a:
            result["only_in_source"].append(path)
        else:
            result["only_in_target"].append(path)

    return result


# ============================================================
# INTERNAL — FORMAT SUMMARY
# ============================================================

def _format_diff_summary(diff: dict) -> str:
    """Return string ringkasan diff (buat laporan / export)."""
    lines = []
    lines.append(f"Only in source : {len(diff['only_in_source'])} file")
    lines.append(f"Only in target : {len(diff['only_in_target'])} file")
    lines.append(f"Different      : {len(diff['different'])} file")
    lines.append(f"Same           : {len(diff['same'])} file")
    return "\n".join(lines)


# ============================================================
# SYNC LOGIC
# ============================================================

def _copy_file(src: str, dst: str) -> dict:
    """
    Copy 1 file. Bikin parent folder kalau perlu.

    Return: {"success": bool, "error": str | None, "bytes": int}
    """
    try:
        os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
        shutil.copy2(src, dst)
        try:
            bytes_copied = os.path.getsize(dst)
        except OSError:
            bytes_copied = 0
        return {"success": True, "error": None, "bytes": bytes_copied}
    except OSError as e:
        return {"success": False, "error": str(e), "bytes": 0}


def _sync_one_way(
    source_root: str,
    target_root: str,
    diff: dict,
    mirror: bool = False,
) -> dict:
    """
    Copy file dari source ke target.

    Args:
        source_root: path folder source
        target_root: path folder target
        diff:        hasil _diff_folders()
        mirror:      kalau True, hapus file di target yang gak ada di source

    Return:
        {
            "copied":       int,
            "deleted":      int,
            "failed":       list[dict],
            "bytes_copied": int,
        }
    """
    result = {
        "copied":       0,
        "deleted":      0,
        "failed":       [],
        "bytes_copied": 0,
    }

    files_to_copy = diff["only_in_source"] + [
        d["path"] for d in diff["different"]
    ]

    for rel in files_to_copy:
        # Safety: skip file config (privacy)
        if _should_skip_file(rel):
            continue

        src = os.path.join(source_root, rel)
        dst = os.path.join(target_root, rel)

        if not os.path.isfile(src):
            result["failed"].append({
                "path": rel, "error": "src gak ada",
            })
            continue

        copy_result = _copy_file(src, dst)

        if copy_result["success"]:
            result["copied"] += 1
            result["bytes_copied"] += copy_result["bytes"]
        else:
            result["failed"].append({
                "path": rel, "error": copy_result["error"],
            })

    if mirror:
        for rel in diff["only_in_target"]:
            # Safety: jangan hapus file config
            if _should_skip_file(rel):
                continue

            dst = os.path.join(target_root, rel)
            try:
                if os.path.isfile(dst):
                    os.remove(dst)
                    result["deleted"] += 1
            except OSError as e:
                result["failed"].append({
                    "path": rel, "error": f"gagal hapus: {e}",
                })

    return result


# ============================================================
# EXPORT REPORT
# ============================================================

def _export_sync_report(
    source_root: str,
    target_root: str,
    diff: dict,
    sync_result: dict = None,
    mode: str = "compare",
) -> str:
    """
    Export laporan sync ke semut/output/<project>_sync_<timestamp>.txt.

    Return path file atau "" kalau gagal.
    """
    out_dir = get_output_dir("sync_helper")
    project_name = os.path.basename(source_root.rstrip(os.sep)) or "sync"
    timestamp = time.strftime("%d-%m-%Y_%H%M%S", time.localtime())
    out_name = f"{project_name}_sync_{timestamp}.txt"
    out_path = os.path.join(out_dir, out_name)

    lines = []
    lines.append("=" * 72)
    lines.append(f"SYNC REPORT — {mode.upper()}")
    lines.append("=" * 72)
    lines.append(f"Generated : {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}")
    lines.append(f"Source    : {source_root}")
    lines.append(f"Target    : {target_root}")
    lines.append(f"Algorithm : {HASH_ALGO}")
    lines.append("")
    lines.append("-" * 72)
    lines.append("DIFF SUMMARY")
    lines.append("-" * 72)
    lines.append(f"Only in source : {len(diff['only_in_source'])}")
    lines.append(f"Only in target : {len(diff['only_in_target'])}")
    lines.append(f"Different      : {len(diff['different'])}")
    lines.append(f"Same           : {len(diff['same'])}")
    lines.append("")

    if diff["only_in_source"]:
        lines.append("-" * 72)
        lines.append(f"ONLY IN SOURCE ({len(diff['only_in_source'])})")
        lines.append("-" * 72)
        for p in diff["only_in_source"]:
            lines.append(f"  + {p}")
        lines.append("")

    if diff["only_in_target"]:
        lines.append("-" * 72)
        lines.append(f"ONLY IN TARGET ({len(diff['only_in_target'])})")
        lines.append("-" * 72)
        for p in diff["only_in_target"]:
            lines.append(f"  - {p}")
        lines.append("")

    if diff["different"]:
        lines.append("-" * 72)
        lines.append(f"DIFFERENT ({len(diff['different'])})")
        lines.append("-" * 72)
        for d in diff["different"]:
            lines.append(f"  ~ {d['path']}")
            lines.append(f"      src: {d['src_hash'][:16]}... ({d['src_size']} B)")
            lines.append(f"      dst: {d['dst_hash'][:16]}... ({d['dst_size']} B)")
        lines.append("")

    if sync_result:
        lines.append("-" * 72)
        lines.append("SYNC RESULT")
        lines.append("-" * 72)
        lines.append(f"Copied  : {sync_result['copied']}")
        lines.append(f"Deleted : {sync_result['deleted']}")
        lines.append(f"Failed  : {len(sync_result['failed'])}")
        lines.append(f"Bytes   : {sync_result['bytes_copied']}")
        lines.append("")

        if sync_result["failed"]:
            lines.append("FAILED FILES:")
            for f in sync_result["failed"]:
                lines.append(f"  ✗ {f['path']} — {f['error']}")
            lines.append("")

    lines.append("=" * 72)
    lines.append("END OF REPORT")
    lines.append("=" * 72)

    try:
        with open(out_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
        return out_path
    except OSError as e:
        printer.print_error(f"Gagal export: {e}")
        return ""


# ============================================================
# RENDER
# ============================================================

def _render_diff(diff: dict, source_label: str, target_label: str):
    """Render hasil diff ke CLI."""
    t = get_theme()

    printer.print_blank()
    printer.print_section("Diff Results", icon="🔍")
    printer.print_blank()

    print(f"  {t.GREEN}+{t.RESET}  Only in {source_label:<15} : {len(diff['only_in_source']):>4} file")
    print(f"  {t.RED}-{t.RESET}  Only in {target_label:<15} : {len(diff['only_in_target']):>4} file")
    print(f"  {t.YELLOW}~{t.RESET}  Different{'':<14} : {len(diff['different']):>4} file")
    print(f"  {t.GREEN}✓{t.RESET}  Same{'':<19} : {len(diff['same']):>4} file")
    printer.print_blank()

    if diff["only_in_source"]:
        printer.print_section(f"Only in {source_label} ({len(diff['only_in_source'])})", icon="+")
        printer.print_info("File ini bakal di-COPY ke target:")
        printer.print_blank()
        for p in diff["only_in_source"][:30]:
            print(f"  {t.GREEN}+{t.RESET}  {p}")
        if len(diff["only_in_source"]) > 30:
            printer.print_info(f"... dan {len(diff['only_in_source']) - 30} file lain")
        printer.print_blank()

    if diff["only_in_target"]:
        printer.print_section(f"Only in {target_label} ({len(diff['only_in_target'])})", icon="-")
        printer.print_info("File ini cuma ada di target (bakal dihapus kalau mirror mode):")
        printer.print_blank()
        for p in diff["only_in_target"][:30]:
            print(f"  {t.RED}-{t.RESET}  {p}")
        if len(diff["only_in_target"]) > 30:
            printer.print_info(f"... dan {len(diff['only_in_target']) - 30} file lain")
        printer.print_blank()

    if diff["different"]:
        printer.print_section(f"Different ({len(diff['different'])})", icon="~")
        printer.print_info("File ini ada di dua-duanya, tapi isinya beda:")
        printer.print_blank()
        for d in diff["different"][:30]:
            print(
                f"  {t.YELLOW}~{t.RESET}  {d['path']}  "
                f"{t.GRAY}(src: {format_size(d['src_size'])}, "
                f"dst: {format_size(d['dst_size'])}){t.RESET}"
            )
        if len(diff["different"]) > 30:
            printer.print_info(f"... dan {len(diff['different']) - 30} file lain")
        printer.print_blank()


# ============================================================
# MODE 1 — COMPARE
# ============================================================

def _wizard_compare():
    """Mode 1: Compare 2 folder (dry-run)."""
    printer.print_blank()
    printer.print_section("Mode: Compare (Dry-Run)", icon="🔍")
    printer.print_blank()

    raw_a = prompt_path_with_history(
        "Path folder A (source)",
        tool_id=TOOL_ID,
    )
    if not raw_a:
        printer.print_warn("Dibatalkan.")
        return

    val_a = _validate_folder(raw_a)
    if not val_a["valid"]:
        printer.print_error(val_a["error"])
        return

    printer.print_blank()
    raw_b = prompt_path_with_history(
        "Path folder B (target)",
        tool_id=TOOL_ID,
    )
    if not raw_b:
        printer.print_warn("Dibatalkan.")
        return

    val_b = _validate_folder(raw_b)
    if not val_b["valid"]:
        printer.print_error(val_b["error"])
        return

    source_root = val_a["path"]
    target_root = val_b["path"]

    add_pair(source_root, target_root, TOOL_ID)

    printer.print_blank()
    printer.print_success(f"Folder A: {source_root}")
    printer.print_success(f"Folder B: {target_root}")
    printer.print_blank()

    hash_a = _hash_folder(source_root, verbose=True)
    printer.print_success(f"Folder A: {len(hash_a['hashes'])} file di-hash")
    if hash_a["errors"]:
        printer.print_warn(f"{len(hash_a['errors'])} file gagal di-hash")

    printer.print_blank()
    hash_b = _hash_folder(target_root, verbose=True)
    printer.print_success(f"Folder B: {len(hash_b['hashes'])} file di-hash")
    if hash_b["errors"]:
        printer.print_warn(f"{len(hash_b['errors'])} file gagal di-hash")

    diff = _diff_folders(hash_a["hashes"], hash_b["hashes"])

    label_a = os.path.basename(source_root.rstrip(os.sep)) or "A"
    label_b = os.path.basename(target_root.rstrip(os.sep)) or "B"

    _render_diff(diff, label_a, label_b)

    printer.print_blank()
    if prompt_yes_no("Export laporan ke .txt?", default="y"):
        out_path = _export_sync_report(source_root, target_root, diff, mode="compare")
        if out_path:
            printer.print_success(f"Laporan: {out_path}")

    printer.print_blank()
    printer.print_success("Selesai.")


# ============================================================
# MODE 2 — SYNC 1-ARAH
# ============================================================

def _wizard_sync():
    """Mode 2: Sync 1-arah (source → target)."""
    printer.print_blank()
    printer.print_section("Mode: Sync 1-Arah", icon="🔄")
    printer.print_blank()

    raw_a = prompt_path_with_history(
        "Path folder SOURCE (yang bener)",
        tool_id=TOOL_ID,
    )
    if not raw_a:
        printer.print_warn("Dibatalkan.")
        return

    val_a = _validate_folder(raw_a)
    if not val_a["valid"]:
        printer.print_error(val_a["error"])
        return

    printer.print_blank()
    raw_b = prompt_path_with_history(
        "Path folder TARGET (yang mau di-update)",
        tool_id=TOOL_ID,
    )
    if not raw_b:
        printer.print_warn("Dibatalkan.")
        return

    val_b = _validate_folder(raw_b)
    if not val_b["valid"]:
        printer.print_error(val_b["error"])
        return

    source_root = val_a["path"]
    target_root = val_b["path"]

    if os.path.normpath(source_root) == os.path.normpath(target_root):
        printer.print_error("Source dan target gak boleh sama, cuy.")
        return

    printer.print_blank()
    printer.print_success(f"Source: {source_root}")
    printer.print_success(f"Target: {target_root}")
    printer.print_blank()

    sync_mode = prompt_choice(
        "Pilih mode sync",
        choices=[
            "Safe   — copy file baru/beda, biarin file extra di target",
            "Mirror — copy file baru/beda, HAPUS file extra di target",
        ],
        default_index=0,
    )
    if sync_mode == -1:
        printer.print_warn("Dibatalkan.")
        return

    mirror = (sync_mode == 1)

    hash_a = _hash_folder(source_root, verbose=True)
    printer.print_success(f"Source: {len(hash_a['hashes'])} file di-hash")

    printer.print_blank()
    hash_b = _hash_folder(target_root, verbose=True)
    printer.print_success(f"Target: {len(hash_b['hashes'])} file di-hash")

    diff = _diff_folders(hash_a["hashes"], hash_b["hashes"])

    label_a = os.path.basename(source_root.rstrip(os.sep)) or "source"
    label_b = os.path.basename(target_root.rstrip(os.sep)) or "target"

    _render_diff(diff, label_a, label_b)

    total_changes = (
        len(diff["only_in_source"]) +
        len(diff["different"]) +
        (len(diff["only_in_target"]) if mirror else 0)
    )

    if total_changes == 0:
        printer.print_blank()
        printer.print_success("Udah sinkron, gak ada yang perlu di-sync.")
        return

    printer.print_blank()
    printer.print_info("💡 Tips: Backup target dulu pake Backup Rotator (menu utama)")
    printer.print_info("   kalau target-nya project penting.")
    printer.print_blank()

    printer.print_section("Konfirmasi Sync", icon="⚠")
    printer.print_kv("Source", source_root)
    printer.print_kv("Target", target_root)
    printer.print_kv("Mode", "mirror (hapus extra)" if mirror else "safe (biarin extra)")
    printer.print_kv("File di-copy", str(len(diff["only_in_source"]) + len(diff["different"])))
    if mirror:
        printer.print_kv("File dihapus", str(len(diff["only_in_target"])))
    printer.print_blank()

    if not prompt_yes_no("Lanjut sync?", default="n"):
        printer.print_warn("Dibatalkan.")
        return

    printer.print_blank()
    printer.print_info("Syncing...")
    printer.print_blank()

    start_time = time.time()
    sync_result = _sync_one_way(source_root, target_root, diff, mirror=mirror)
    elapsed = time.time() - start_time

    printer.print_blank()
    printer.print_success(
        f"{sync_result['copied']} file di-copy "
        f"({format_size(sync_result['bytes_copied'])}) "
        f"dalam {elapsed:.2f}s"
    )

    if mirror and sync_result["deleted"] > 0:
        printer.print_success(f"{sync_result['deleted']} file dihapus di target")

    if sync_result["failed"]:
        printer.print_warn(f"{len(sync_result['failed'])} file gagal:")
        for f in sync_result["failed"][:5]:
            printer.print_bullet(f"{f['path']} — {f['error']}", indent=6)

    add_pair(source_root, target_root, TOOL_ID)

    printer.print_blank()
    if prompt_yes_no("Export laporan ke .txt?", default="y"):
        out_path = _export_sync_report(
            source_root, target_root, diff, sync_result, mode="sync"
        )
        if out_path:
            printer.print_success(f"Laporan: {out_path}")

    printer.print_blank()
    printer.print_success("Selesai.")


# ============================================================
# MODE 3 — VERIFY
# ============================================================

def _wizard_verify():
    """Mode 3: Verify 2 folder (hash only)."""
    printer.print_blank()
    printer.print_section("Mode: Verify (Hash Only)", icon="✓")
    printer.print_blank()

    raw_a = prompt_path_with_history(
        "Path folder A",
        tool_id=TOOL_ID,
    )
    if not raw_a:
        printer.print_warn("Dibatalkan.")
        return

    val_a = _validate_folder(raw_a)
    if not val_a["valid"]:
        printer.print_error(val_a["error"])
        return

    printer.print_blank()
    raw_b = prompt_path_with_history(
        "Path folder B",
        tool_id=TOOL_ID,
    )
    if not raw_b:
        printer.print_warn("Dibatalkan.")
        return

    val_b = _validate_folder(raw_b)
    if not val_b["valid"]:
        printer.print_error(val_b["error"])
        return

    source_root = val_a["path"]
    target_root = val_b["path"]

    add_pair(source_root, target_root, TOOL_ID)

    printer.print_blank()
    printer.print_success(f"Folder A: {source_root}")
    printer.print_success(f"Folder B: {target_root}")
    printer.print_blank()

    hash_a = _hash_folder(source_root, verbose=True)
    printer.print_success(f"Folder A: {len(hash_a['hashes'])} file di-hash")

    printer.print_blank()
    hash_b = _hash_folder(target_root, verbose=True)
    printer.print_success(f"Folder B: {len(hash_b['hashes'])} file di-hash")

    diff = _diff_folders(hash_a["hashes"], hash_b["hashes"])

    label_a = os.path.basename(source_root.rstrip(os.sep)) or "A"
    label_b = os.path.basename(target_root.rstrip(os.sep)) or "B"

    _render_diff(diff, label_a, label_b)

    printer.print_blank()
    printer.print_separator("═", 56)

    if not diff["only_in_source"] and not diff["only_in_target"] and not diff["different"]:
        printer.print_section("VERDICT: ✓ IDENTIK", icon="✓")
        printer.print_info(f"Folder {label_a} dan {label_b} isinya sama persis.")
    else:
        printer.print_section("VERDICT: ✗ BEDA", icon="⚠")
        printer.print_info(f"Folder {label_a} dan {label_b} isinya beda.")
        printer.print_info(
            f"Total beda: {len(diff['only_in_source']) + len(diff['only_in_target']) + len(diff['different'])} file"
        )

    printer.print_separator("═", 56)

    printer.print_blank()
    printer.print_success("Selesai.")


# ============================================================
# WIZARD — MAIN
# ============================================================


# ============================================================
# API MODE (PR-09)
# ============================================================
def _do_work(params=None):
    params=params or {}; source=str(params.get("source") or ""); target=str(params.get("target") or ""); action=str(params.get("action","compare"))
    if not source or not target: return {"ok":False,"error":"source dan target wajib diisi"}
    a=_validate_folder(source); b=_validate_folder(target)
    if not a.get("valid") or not b.get("valid"): return {"ok":False,"error":a.get("error") or b.get("error")}
    ha=_hash_folder(source,verbose=False); hb=_hash_folder(target,verbose=False); diff=_diff_folders(ha.get("hashes",{}),hb.get("hashes",{}))
    if action == "compare": return {"ok":True,"action":action,"source":source,"target":target,"diff":diff}
    if action == "sync":
        result=_sync_one_way(source,target,diff,bool(params.get("mirror",False)))
        return {"ok":True,"action":action,"source":source,"target":target,"result":result}
    if action == "verify": return {"ok":True,"action":action,"source":ha,"target":hb,"diff":diff,"identical":not any(diff.values()) if isinstance(diff,dict) else False}
    return {"ok":False,"error":f"action tidak dikenal: {action}"}

def run_api(params=None): return _do_work(params)

def run_wizard():
    """Wizard interaktif — dipanggil dari menu."""
    printer.print_section("Sync Helper", icon="🔄")
    printer.print_info("Sync 2 folder dengan hash-based diff")
    printer.print_info("Ketik '0' di prompt manapun buat batal")
    printer.print_blank()

    mode = prompt_choice(
        "Pilih mode",
        choices=[
            "Compare (dry-run) — list file beda, gak ada perubahan",
            "Sync 1-Arah (source → target)",
            "Verify (hash only) — cek integritas",
        ],
        default_index=0,
    )

    if mode == -1:
        printer.print_warn("Dibatalkan.")
        return

    if mode == 0:
        _wizard_compare()
    elif mode == 1:
        _wizard_sync()
    elif mode == 2:
        _wizard_verify()


# ============================================================
# SELF-TEST
# ============================================================

if __name__ == "__main__":
    run_wizard()