"""
tools/tree_printer.py — Dependency Tree Scanner (v3.2)

Scan dependency tree dari entry point (file .py atau folder),
traversal import chain, klasifikasi file: traversed / orphan / ignored.

Fitur:
    - Input path manual (file .py atau folder)
    - Auto-detect entry point kalau input folder
    - Traversal import dari entry point (pake ast)
    - Deteksi orphan (file gak di-import)
    - Deteksi ignored (file sampah: .bak, __pycache__, dll)
    - Parse string literal (best-effort) buat file non-Python
    - Mode combined: folder tree + status per file
    - Export JSON ke output/<project>_<entry>_tree.json
    - Path history (auto-complete dari input sebelumnya)

v3.2 changes:
    - Integrasi core.exclude — pake .exclude.json global
    - Semua scan (all files, dependencies, entry points) auto-exclude

Filosofi:
    Ambil apa yang perlu, bukan filter apa yang gak perlu.
    Output JSON siap dikonsumsi tool lain (backup_rotator).

Filosofi Output:
    Output SELALU disimpen di semut/output/ — gak peduli
    project apa yang di-scan. Biar centralized & gampang
    dibaca backup_rotator nanti.
"""

import os
import sys
import ast
import re
import json
import time
from pathlib import Path
from semut_suite.core.storage import output_dir

from semut_suite.ui import printer
from semut_suite.ui.spinner import Spinner
from semut_suite.ui.theme import get_theme
from semut_suite.ui.prompt import (
    prompt_input, prompt_choice, prompt_yes_no,
    is_cancelled, CANCEL_SENTINEL,
)

from semut_suite.core.history import (
    prompt_path_with_history,
    add_path,
)

from semut_suite.core.exclude import is_excluded, FALLBACK_EXCLUDE


# ============================================================
# TOOL_META
# ============================================================

TOOL_META = {
    "id":       "tree_printer",
    "name":     "Tree Printer",
    "desc":     "Scan dependency tree + deteksi orphan file",
    "category": "file",
    "icon":     "🌳",
    "order":    1,
}


# ============================================================
# CONSTANTS
# ============================================================

OUTPUT_DIR = "output"
TOOL_ID = "tree_printer"

# Fallback exclude — dipake kalau .exclude.json gak ada
# (sebenernya is_excluded() udah handle auto-generate, tapi ini buat safety)

JUNK_PATTERNS = [
    re.compile(r".*\.bak$"),
    re.compile(r".*\.bak[._].*$"),
    re.compile(r".*\.old$"),
    re.compile(r".*\.orig$"),
    re.compile(r".*\.tmp$"),
    re.compile(r".*\.swp$"),
    re.compile(r".*\.swo$"),
    re.compile(r".*~$"),
    re.compile(r".*\.pyc$"),
    re.compile(r".*\.pyo$"),
    re.compile(r".*_bak\..*$"),
]

CODE_EXTS = {".py"}

DATA_EXTS = {
    ".json", ".md", ".txt", ".yaml", ".yml", ".toml",
    ".html", ".css", ".js", ".cfg", ".ini", ".env",
}

STDLIB_MODULES = {
    "os", "sys", "json", "re", "time", "datetime", "math",
    "random", "hashlib", "itertools", "functools", "collections",
    "pathlib", "shutil", "glob", "subprocess", "argparse",
    "logging", "unittest", "typing", "dataclasses", "enum",
    "io", "textwrap", "string", "ast", "importlib", "traceback",
    "getpass", "socket", "http", "urllib", "base64", "binascii",
    "csv", "sqlite3", "pickle", "copy", "pprint", "uuid",
    "secrets", "hmac", "tempfile", "contextlib", "warnings",
    "platform", "getopt", "configparser", "webbrowser", "zipfile",
    "tarfile", "gzip", "struct", "array", "queue", "threading",
    "multiprocessing", "asyncio", "concurrent", "signal",
}

ENTRY_PRIORITY = ["main.py", "app.py", "run.py", "__main__.py", "cli.py"]


# ============================================================
# SEMUT ROOT
# ============================================================

def _get_semut_root() -> str:
    """Return YookAI's persistent Semut utility data root."""
    return str(Path.home() / ".yookai" / "semut_suite")


def _is_junk(name: str) -> bool:
    for pattern in JUNK_PATTERNS:
        if pattern.match(name):
            return True
    return False


def _should_exclude(path: str) -> bool:
    """Fallback exclude — cek berdasarkan nama folder (FALLBACK_EXCLUDE)."""
    parts = Path(path).parts
    for part in parts:
        if part in FALLBACK_EXCLUDE:
            return True
    return False


def _is_python_file(path: str) -> bool:
    return Path(path).suffix.lower() == ".py"


def _is_data_file(path: str) -> bool:
    return Path(path).suffix.lower() in DATA_EXTS


def _file_size(path: str) -> int:
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def _format_size(size_bytes: int) -> str:
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"


def _get_output_dir() -> str:
    return str(output_dir("tree_printer"))


def _get_output_filename(project_root: str, entry_file: str) -> str:
    project_name = os.path.basename(project_root.rstrip(os.sep))
    entry_name = os.path.splitext(os.path.basename(entry_file))[0]

    if project_name == entry_name:
        base = project_name
    else:
        base = f"{project_name}_{entry_name}"

    return f"{base}_tree.json"


# ============================================================
# INPUT RESOLUTION
# ============================================================

def resolve_input_path(user_input: str) -> tuple:
    """
    Resolve input user jadi (project_root, entry_file, error_msg).
    """
    if not user_input:
        return None, None, "Input kosong"

    path = os.path.expanduser(user_input.strip())

    if os.path.isfile(path):
        if not path.endswith(".py"):
            return None, None, "File bukan Python (.py)"
        return (
            os.path.dirname(path),
            os.path.basename(path),
            None,
        )

    if os.path.isdir(path):
        entries = detect_entry_points(path)

        if not entries:
            return None, None, "Gak ada entry point (file dengan __main__) di folder itu"

        if len(entries) == 1:
            return path, entries[0], None

        for priority_name in ENTRY_PRIORITY:
            for entry in entries:
                if os.path.basename(entry) == priority_name:
                    return path, entry, None

        return path, entries, "MULTIPLE"

    return None, None, f"Path gak ada: {path}"


# ============================================================
# CORE — PARSE IMPORTS
# ============================================================

def parse_imports(file_path: str) -> dict:
    result = {
        "imports":  [],
        "literals": [],
        "error":    None,
    }

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            source = f.read()
    except (OSError, UnicodeDecodeError) as e:
        result["error"] = f"Gagal baca file: {e}"
        return result

    try:
        tree = ast.parse(source, filename=file_path)
    except SyntaxError as e:
        result["error"] = f"Syntax error: {e}"
        return result

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                result["imports"].append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            # Keep relative-import depth so package-local imports can be resolved.
            prefix = "." * int(node.level or 0)
            if node.module or prefix:
                result["imports"].append(prefix + (node.module or ""))
            # `from package import child` can refer to a submodule, not only a symbol.
            for alias in node.names:
                if alias.name != "*":
                    if node.module:
                        result["imports"].append(prefix + node.module + "." + alias.name)
                    elif prefix:
                        result["imports"].append(prefix + alias.name)
        elif isinstance(node, ast.Call):
            # Best-effort support for importlib.import_module() and __import__().
            func = node.func
            is_import_call = (
                isinstance(func, ast.Name) and func.id == "__import__"
            ) or (
                isinstance(func, ast.Attribute) and func.attr == "import_module"
            )
            if is_import_call and node.args and isinstance(node.args[0], ast.Constant):
                value = node.args[0].value
                if isinstance(value, str) and value:
                    result["imports"].append(value)

    ext_pattern = "|".join(
        ext.lstrip(".") for ext in (DATA_EXTS | CODE_EXTS)
    )
    path_pattern = re.compile(
        r"['\"]([^'\"]+\.(" + ext_pattern + r"))['\"]"
    )

    for match in path_pattern.finditer(source):
        literal = match.group(1)
        if "{" not in literal and "%" not in literal:
            result["literals"].append(literal)

    result["imports"] = list(dict.fromkeys(result["imports"]))
    result["literals"] = list(dict.fromkeys(result["literals"]))
    return result


def resolve_import(import_name: str, project_root: str, importer_path: str = "") -> str:
    """Resolve absolute and package-relative Python imports inside project root."""
    if not import_name:
        return None
    level = len(import_name) - len(import_name.lstrip("."))
    module = import_name[level:]
    if not level and module.split(".")[0] in STDLIB_MODULES:
        return None

    bases = [project_root]
    if level and importer_path:
        importer_dir = os.path.dirname(os.path.join(project_root, importer_path))
        # For a module in a package, one dot means current package; two means parent.
        package_dir = importer_dir
        for _ in range(max(0, level - 1)):
            package_dir = os.path.dirname(package_dir)
        bases = [package_dir]
    parts = module.split(".") if module else []
    rel_path = os.path.join(*parts) if parts else ""
    for base in bases:
        candidates = ([os.path.join(base, rel_path + ".py")] if rel_path else [])
        candidates += [os.path.join(base, rel_path, "__init__.py")]
        # A module may be imported from a namespace package without __init__.py.
        if rel_path:
            candidates.append(os.path.join(base, rel_path, "__init__.py"))
        for candidate in candidates:
            try:
                if os.path.isfile(candidate) and os.path.commonpath((os.path.realpath(project_root), os.path.realpath(candidate))) == os.path.realpath(project_root):
                    return os.path.relpath(candidate, project_root)
            except (OSError, ValueError):
                continue
    return None


# ============================================================
# CORE — SCAN DEPENDENCIES
# ============================================================

def scan_dependencies(
    entry_file: str,
    project_root: str,
    max_depth: int = 20,
) -> dict:
    visited = set()

    def _scan(file_path: str, depth: int, imported_by: str) -> dict:
        rel_path = os.path.relpath(file_path, project_root)

        node = {
            "path":        rel_path,
            "abs_path":    file_path,
            "type":        "file",
            "size":        _file_size(file_path),
            "status":      "traversed",
            "depth":       depth,
            "children":    [],
            "imported_by": [imported_by] if imported_by else [],
            "imports":     [],
        }

        if rel_path in visited:
            return node
        visited.add(rel_path)

        if depth >= max_depth:
            return node

        if not _is_python_file(file_path):
            return node

        parsed = parse_imports(file_path)
        if parsed["error"]:
            node["scan_warning"] = parsed["error"]
            return node

        node["imports"] = parsed["imports"]

        for imp in parsed["imports"]:
            resolved = resolve_import(imp, project_root, rel_path)
            if resolved is None:
                continue

            child_abs = os.path.join(project_root, resolved)

            # Fallback exclude (nama folder)
            if _should_exclude(child_abs):
                continue

            # Exclude dari .exclude.json
            if is_excluded(resolved):
                continue

            child_node = _scan(child_abs, depth + 1, rel_path)

            existing = [
                c for c in node["children"]
                if c["path"] == resolved
            ]
            if existing:
                if rel_path not in existing[0]["imported_by"]:
                    existing[0]["imported_by"].append(rel_path)
            else:
                node["children"].append(child_node)

        for literal in parsed["literals"]:
            lit_abs = os.path.join(project_root, literal)
            if not os.path.isfile(lit_abs):
                continue

            lit_rel = os.path.relpath(lit_abs, project_root)
            if lit_rel in visited:
                continue

            # Fallback exclude (nama folder)
            if _should_exclude(lit_abs):
                continue

            # Exclude dari .exclude.json
            if is_excluded(lit_rel):
                continue

            lit_node = {
                "path":        lit_rel,
                "abs_path":    lit_abs,
                "type":        "file",
                "size":        _file_size(lit_abs),
                "status":      "traversed",
                "depth":       depth + 1,
                "children":    [],
                "imported_by": [rel_path],
                "imports":     [],
            }
            visited.add(lit_rel)
            node["children"].append(lit_node)

        return node

    entry_abs = os.path.join(project_root, entry_file)
    root_node = _scan(entry_abs, 0, None)

    return {
        "tree":    root_node,
        "visited": sorted(visited),
    }


def scan_all_files(project_root: str) -> list:
    """Scan semua file di project, exclude yang ada di .exclude.json & FALLBACK_EXCLUDE."""
    found = []

    with Spinner("Scanning project files", show_elapsed=True) as progress:
        for root, dirs, files in os.walk(project_root):
            dirs[:] = [d for d in dirs if d not in FALLBACK_EXCLUDE]
            for f in files:
                full = os.path.join(root, f)
                rel = os.path.relpath(full, project_root)
                if _should_exclude(full) or is_excluded(rel):
                    continue
                found.append(rel)
                progress.tick()

    return sorted(found)


def classify_status(traversed_paths: list, all_files: list) -> dict:
    traversed_set = set(traversed_paths)
    status_map = {}

    for rel in all_files:
        if rel in traversed_set:
            status_map[rel] = "traversed"
        elif _is_junk(os.path.basename(rel)):
            status_map[rel] = "ignored"
        else:
            status_map[rel] = "orphan"

    return status_map


# ============================================================
# RENDER
# ============================================================

def _status_icon(status: str) -> str:
    return {
        "traversed": "✓",
        "orphan":    "○",
        "ignored":   "·",
        "missing":   "✗",
    }.get(status, "?")


def _status_color(status: str) -> str:
    t = get_theme()
    return {
        "traversed": t.GREEN,
        "orphan":    t.YELLOW,
        "ignored":   t.GRAY,
        "missing":   t.RED,
    }.get(status, t.WHITE)


def render_tree_combined(node: dict, project_root: str):
    t = get_theme()

    printer.print_section(
        f"Dependency Tree — {node['path']}",
        icon="🌳",
    )
    printer.print_blank()

    def _render(n: dict, prefix: str = "", is_last: bool = True, is_root: bool = False):
        name = os.path.basename(n["path"])
        size_str = _format_size(n["size"])
        status = n["status"]
        color = _status_color(status)
        icon = _status_icon(status)

        if is_root:
            print(
                f"  {t.BOLD}{t.WHITE}{n['path']}{t.RESET}"
                f"  {t.GRAY}[entry]{t.RESET}"
                f"  {t.GRAY}({size_str}){t.RESET}"
            )
        else:
            branch = "└── " if is_last else "├── "
            line = (
                f"  {t.GRAY}{prefix}{branch}{t.RESET}"
                f"{color}{icon}{t.RESET}  {name}"
                f"  {t.GRAY}({size_str}){t.RESET}"
            )

            if len(n.get("imported_by", [])) > 1:
                by_count = len(n["imported_by"])
                line += f"  {t.GRAY_DIM}[← {by_count} files]{t.RESET}"

            print(line)

        children = n.get("children", [])
        for i, child in enumerate(children):
            child_is_last = (i == len(children) - 1)
            new_prefix = prefix + ("    " if is_last else "│   ")
            _render(child, new_prefix, child_is_last, is_root=False)

    _render(node, is_root=True)


def render_orphans(project_root: str, traversed: list):
    t = get_theme()

    all_files = scan_all_files(project_root)
    status_map = classify_status(traversed, all_files)

    orphans = [f for f, s in status_map.items() if s == "orphan"]
    ignored = [f for f, s in status_map.items() if s == "ignored"]

    if not orphans and not ignored:
        return

    printer.print_blank()

    if orphans:
        printer.print_section(f"Orphan Files ({len(orphans)})", icon="○")
        printer.print_info("File ini ADA di project, tapi GAK di-import:")
        printer.print_blank()

        for path in orphans[:50]:
            size = _format_size(_file_size(os.path.join(project_root, path)))
            print(f"  {t.YELLOW}○{t.RESET}  {path}  {t.GRAY}({size}){t.RESET}")

        if len(orphans) > 50:
            printer.print_info(f"... dan {len(orphans) - 50} file lain")

    if ignored:
        printer.print_blank()
        printer.print_section(f"Ignored Files ({len(ignored)})", icon="·")
        printer.print_info("File sampah yang di-skip otomatis:")
        printer.print_blank()

        for path in ignored[:20]:
            size = _format_size(_file_size(os.path.join(project_root, path)))
            print(f"  {t.GRAY}·{t.RESET}  {t.GRAY}{path}  ({size}){t.RESET}")

        if len(ignored) > 20:
            printer.print_info(f"... dan {len(ignored) - 20} file lain")


def render_summary(project_root: str, traversed: list):
    t = get_theme()

    all_files = scan_all_files(project_root)
    status_map = classify_status(traversed, all_files)

    orphans = [f for f, s in status_map.items() if s == "orphan"]
    ignored = [f for f, s in status_map.items() if s == "ignored"]

    def _total_size(paths):
        total = 0
        for p in paths:
            total += _file_size(os.path.join(project_root, p))
        return total

    traversed_size = _total_size(traversed)
    orphan_size = _total_size(orphans)
    ignored_size = _total_size(ignored)

    printer.print_blank()
    printer.print_separator("═", 56)
    printer.print_section("Summary", icon="📊")
    printer.print_blank()

    print(
        f"  {t.GREEN}✓{t.RESET}  Traversed : "
        f"{len(traversed):>4} file  "
        f"{t.GRAY}({_format_size(traversed_size)}){t.RESET}"
        f"  {t.GREEN}← BACKUP INI{t.RESET}"
    )
    print(
        f"  {t.YELLOW}○{t.RESET}  Orphan    : "
        f"{len(orphans):>4} file  "
        f"{t.GRAY}({_format_size(orphan_size)}){t.RESET}"
    )
    print(
        f"  {t.GRAY}·{t.RESET}  Ignored   : "
        f"{len(ignored):>4} file  "
        f"{t.GRAY}({_format_size(ignored_size)}){t.RESET}"
    )

    printer.print_separator("═", 56)


# ============================================================
# EXPORT
# ============================================================

def export_json(
    tree_data: dict,
    project_root: str,
    entry_file: str,
) -> str:
    all_files = scan_all_files(project_root)
    status_map = classify_status(tree_data["visited"], all_files)

    orphans = [f for f, s in status_map.items() if s == "orphan"]
    ignored = [f for f, s in status_map.items() if s == "ignored"]

    # Orphan means "not reached by this static scan", never a deletion verdict.
    # Keep compatibility arrays and add explicit review metadata for consumers.
    review = {}
    for path in orphans:
        ext = Path(path).suffix.lower()
        if ext == ".py":
            review[path] = {"classification": "possible_orphan", "confidence": "medium", "reason": "Not reached through statically resolved imports; dynamic loading or external invocation may still use it."}
        else:
            review[path] = {"classification": "unreferenced_asset", "confidence": "low", "reason": "Not found through static string-path hints; runtime/config/template use may be missed."}

    payload = {
        "schema_version": 2,
        "scan_note": "Orphan classifications are heuristic review hints and must not be treated as safe-to-delete decisions.",
        "orphan_review": review,
        "entry":      entry_file,
        "project":    project_root,
        "generated":  time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        "traversed":  tree_data["visited"],
        "orphan":     orphans,
        "ignored":    ignored,
        "tree":       tree_data["tree"],
    }

    out_dir = _get_output_dir()
    out_name = _get_output_filename(project_root, entry_file)
    out_path = os.path.join(out_dir, out_name)

    try:
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
        return out_path
    except OSError as e:
        printer.print_error(f"Gagal export: {e}")
        return ""


# ============================================================
# AUTO-DETECT ENTRY POINT
# ============================================================

def detect_entry_points(project_root: str) -> list:
    entries = []

    for root, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in FALLBACK_EXCLUDE]

        for f in files:
            if not f.endswith(".py"):
                continue
            full = os.path.join(root, f)

            # Fallback exclude
            if _should_exclude(full):
                continue

            # Exclude dari .exclude.json
            rel = os.path.relpath(full, project_root)
            if is_excluded(rel):
                continue

            try:
                with open(full, "r", encoding="utf-8") as fh:
                    content = fh.read()
                if "__name__" in content and "__main__" in content:
                    entries.append(rel)
            except (OSError, UnicodeDecodeError):
                continue

    return sorted(entries)


# ============================================================
# WIZARD
# ============================================================


# ============================================================
# API MODE (PR-09)
# ============================================================
def _do_work(params=None):
    params=params or {}; user_input=str(params.get("path") or params.get("project_root") or "")
    if not user_input: return {"ok":False,"error":"path wajib diisi"}
    root,entry,error=resolve_input_path(user_input)
    if error=="MULTIPLE":
        entry=params.get("entry") or entry[0]
    if error and error!="MULTIPLE": return {"ok":False,"error":error}
    max_depth=int(params.get("max_depth",20)); traversed=scan_dependencies(entry,root,max_depth); all_files=scan_all_files(root); status=classify_status(traversed,all_files)
    tree={"project_root":root,"entry_file":entry,"max_depth":max_depth,"traversed":traversed,"all_files":all_files,"status":status}
    result={"ok":True,"project_root":root,"entry_file":entry,"tree":tree,"status":status}
    if params.get("export",False): result["output_path"]=export_json(tree,root,entry)
    return result

def run_api(params=None): return _do_work(params)

def run_wizard():
    """Wizard interaktif — dipanggil dari menu."""
    printer.print_section("Tree Printer", icon="🌳")
    printer.print_info("Scan dependency tree + deteksi orphan file")
    printer.print_info("Ketik '0' di prompt manapun buat batal")
    printer.print_blank()

    printer.print_info("Contoh input:")
    printer.print_bullet("/storage/emulated/0/Project/GhostWriter/main.py")
    printer.print_bullet("/storage/emulated/0/Project/lumoss/")
    printer.print_bullet("semut.py  (relatif ke cwd)")
    printer.print_blank()

    # Prompt path (pake history)
    raw_path = prompt_path_with_history(
        "Path entry point (file .py atau folder)",
        tool_id=TOOL_ID,
    )

    if not raw_path:
        printer.print_warn("Dibatalkan.")
        return

    # Resolve input
    project_root, entry_file, error = resolve_input_path(raw_path)

    if error and error != "MULTIPLE":
        printer.print_error(error)
        return

    if error == "MULTIPLE":
        entries = entry_file
        idx = prompt_choice(
            "Folder punya banyak entry point. Pilih salah satu",
            choices=entries,
            default_index=0,
        )
        if idx == -1:
            printer.print_warn("Dibatalkan.")
            return
        entry_file = entries[idx]

    printer.print_blank()
    printer.print_success(f"File valid: {entry_file}")
    printer.print_kv("Project root", project_root)
    printer.print_kv(
        "Output",
        os.path.join(
            _get_output_dir(),
            _get_output_filename(project_root, entry_file),
        ),
    )
    printer.print_blank()

    printer.print_info(f"Scanning: {entry_file}...")
    printer.print_blank()

    tree_data = scan_dependencies(entry_file, project_root)

    printer.print_blank()
    render_tree_combined(tree_data["tree"], project_root)
    render_orphans(project_root, tree_data["visited"])
    render_summary(project_root, tree_data["visited"])
    printer.print_card(
        "Scan Selesai",
        {
            "Entry": entry_file,
            "Visited": str(len(tree_data.get("visited", []))),
            "Output": os.path.join(_get_output_dir(), _get_output_filename(project_root, entry_file)),
        },
        icon="🌳",
        color=get_theme().GREEN,
    )

    printer.print_blank()
    if prompt_yes_no("Export ke JSON?", default="y"):
        out_path = export_json(tree_data, project_root, entry_file)
        if out_path:
            printer.print_success(f"Exported: {out_path}")
        else:
            printer.print_error("Gagal export.")

    printer.print_blank()
    printer.print_success("Selesai.")


# ============================================================
# SELF-TEST
# ============================================================

if __name__ == "__main__":
    run_wizard()