# Terminal screen navigation

YookAI's interactive configuration and Semut utility menu use a shared
`tools.terminal.clear_screen()` helper to render menus as clean terminal
screens rather than appending every menu to the visible output.

- The helper emits ANSI clear-screen, clear-scrollback, and cursor-home
  sequences only for interactive TTY output (unless explicitly forced).
- Redirected output and `TERM=dumb` remain plain and are not polluted with
  terminal control sequences.
- Entering a Semut utility clears the previous menu before rendering it.
  The utility's completion/status output remains visible until its caller
  pauses and redraws the parent menu.
- Returning from a submenu is still controlled by that menu's existing Back
  or Exit behavior; this change does not reinterpret destructive-operation
  confirmations or tool-specific prompts.
- Clearing scrollback depends on terminal support. Some terminal emulators may
  clear only the visible screen, and cannot guarantee erasure of scrollback.

The interactive configuration screen is redrawn between menu actions. Use
`--no-configure` for non-interactive/server-only startup as before.
