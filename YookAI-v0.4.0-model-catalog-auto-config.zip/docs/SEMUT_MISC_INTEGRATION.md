# Semut utilities integrated into YookAI Miscellaneous

YookAI v0.3.28 includes a vendored snapshot of seven Semut file/folder utilities
as the namespaced `semut_suite` subsystem. Semut is maintained by @nexterade.
The snapshot preserves the dedicated wizard flows while avoiding collisions
with YookAI's `core`, `ui`, and `tools` packages. YookAI invokes Semut through
`semut_suite.adapter`, a narrow allowlisted dispatch boundary, so application
menu code does not need to know the implementation details of individual tools.

## Feature audit and mapping

| Miscellaneous option | Semut module | Capabilities retained |
|---|---|---|
| 1 Tree Printer | `tree_printer` | AST-based import traversal (including relative imports and literal dynamic-import hints), entry-point detection, traversed/orphan/ignored classification with review confidence metadata, JSON export, exclude patterns and path history. Orphan classifications are heuristic only and must never trigger automatic deletion. |
| 2 Ghost Grep | `ghost_grep` | String/regex search, context lines, extension filtering, dependency-tree integration, grouped results and text export |
| 3 File Hasher | `file_hasher` | SHA-256 hashing, manifest creation/parsing, folder-to-folder and folder-to-manifest verification, progress and exclude support |
| 4 Backup Rotator | `backup_rotator` | Smart/clean/mirror project backup, selected-file backup, ZIP plus metadata, list/restore/prune/history and verification |
| 5 Sync Helper | `sync_helper` | Hash-based dry-run compare, one-way sync, optional mirror, verification and reports |
| 6 Sync Remote | `sync_remote` | Mounted-rclone folder validation, one-way and bidirectional sync, watch modes, conflict handling and mount status |
| 7 ColorNote Exporter | `color_note_exporter` | SQLite schema detection, note metadata, locked-note skip, preview, Markdown/HTML export and export rotation |

## Isolation and data handling

- Only Python source modules needed by the seven utilities are vendored.
- Semut's encrypted vault and user state files are intentionally excluded.
- Semut modules are imported as `semut_suite.*`, not as YookAI's top-level
  packages.
- Semut utility state and path history remain in private `~/.yookai/semut_suite/`. Non-sensitive generated outputs use categorized folders under `~/storage/shared/YookAI/` when Termux shared storage is mounted and writable: `TreeReports/`, `SearchReports/`, `FileHashes/`, `Backups/`, `Sync/`, and `ColorNote/`. If shared storage is unavailable, output falls back to `~/.yookai/semut_suite/output/<category>/`. `YOOKAI_SHARED_DIR` can override the mounted shared-storage root for testing or custom setups.
- Sync/backup/restore actions continue to use each tool's own confirmation and
  validation flow. Review mirror/restore targets carefully because they can
  modify or remove files.
- The integrated source retains Semut's own terminology and workflows. YookAI
  currently invokes each tool's interactive `run_wizard()` entry point.

## Shared output storage

Run `termux-setup-storage` once and grant Android storage permission to expose `~/storage/shared`. The Miscellaneous menu displays the resolved output root and whether shared storage passed a temporary file create/delete check or is using the private fallback. The tool creates each category folder on demand. Existing private Backup Rotator archives are copied into the shared `Backups/` folder when first accessed (the original private copies are retained); API keys, settings, sessions, and memory are not moved to shared storage. Sync Remote operates on user-selected local and mounted-remote folders rather than exporting a separate report by default.

## Ownership, licensing, and versioning

- Semut is maintained by @nexterade; the vendored snapshot identifies itself as
  `0.4.0-alpha` in `semut_suite.__version__`. This is snapshot metadata, not a
  promise of API compatibility with a separately published Semut release.
- Keep Semut-specific implementation under `semut_suite/`; YookAI should call
  tools only through `semut_suite.adapter` rather than importing implementation
  modules directly from application code.
- YookAI's repository license does not automatically establish the license of
  separately authored or third-party bundled material. Before public release,
  document the applicable Semut license and retain any required third-party
  notices. Confirm dependency licenses independently.

## Release notes — v0.3.24

- Centralized non-sensitive tool outputs under the user-accessible `YookAI/` shared folder, with a per-tool subfolder.
- Added a safe private fallback when Android shared storage is not mounted or writable.
- Miscellaneous menu now displays the output root and active storage mode.
- Legacy private Backup Rotator archives are copied to the shared backup folder on access; originals are preserved.
- Added unit coverage for shared paths, categorized folders, fallback behavior, and invalid categories.

## Release notes — v0.3.25

- Replaced the two-line milestone progress output with a single dynamically redrawn terminal line.
- Progress width adapts to narrow Termux terminals and truncates labels to avoid wrapping.
- Non-TTY runs omit intermediate progress redraws and retain a final summary.
- Added regression tests for one-line TTY output and concise non-TTY output.


## Release notes — v0.3.27

- Keep the completed determinate progress bar as a 100% terminal history line, with a success/failure marker; non-TTY output retains the elapsed-time summary.
- Verify shared storage using a temporary file create/delete probe and resolve symlinked Android mount paths before displaying status.
- Tighten panel width and visual alignment for narrow Termux terminals and wide Unicode glyphs.

## Release notes — v0.3.26

- Audited progress feedback in the complete Miscellaneous tool set.
- Added the shared adaptive one-line progress indicator to Ghost Grep, ColorNote parsing and export, and Sync Remote operations.
- Tree Printer now provides a lightweight spinner for filesystem traversal with an unknown total.
- Tightened progress-bar sizing for narrow Termux screens and documented determinate versus indeterminate progress behavior.


## Release notes — v0.3.28 integration boundary

- Added explicit Semut snapshot metadata (`0.4.0-alpha`, maintainer `@nexterade`).
- Centralized allowlisted utility loading and wizard dispatch in `semut_suite.adapter`.
- Kept the YookAI Miscellaneous menu as a thin caller of the adapter.
- Added tests for the dispatch boundary, unsupported names, missing wizard entry
  points, and Semut snapshot metadata.
