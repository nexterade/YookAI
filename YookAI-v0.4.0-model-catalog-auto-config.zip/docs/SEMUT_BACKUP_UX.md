# Semut Backup Rotator — UX & Rotation Notes

## Retention policy

Project backups are retained at a maximum of 10 per parsed project name. File-session archives are retained at a maximum of 50. Rotation only removes archives after the configured default threshold is exceeded; creating 5–7 backups is therefore not expected to prune anything.

Project backups are ordered by their `backed_up_at` metadata timestamp. If that value is missing or invalid, rotation falls back to the archive's filesystem modification time, then the date in its name. This avoids date-only sorting treating backups made on the same day as equivalent.

## User-facing changes

- The prune menu states the retention policy before offering automatic or manual cleanup.
- Automatic prune reports when the threshold has not been reached rather than implying a deletion occurred.
- After project backup, the UI reports the detected count, retention limit, removed archive names (up to three), and remaining count.
- The project ZIP continues to contain `.backup_meta.json`; the sidecar `.meta.json` remains available for inspection without opening the ZIP.
- Restore continues to show a confirmation before overwriting and creates a safety backup first when possible. The completion message reports the number restored and any failures.

## Safe testing

Test restore against a disposable copy of a project. To test rotation, create more than 10 backups for the same project, ideally with distinct timestamps, then verify that the newest 10 remain and that their manifests still correspond to the retained ZIP files. Do not test pruning against the only copy of important data.
