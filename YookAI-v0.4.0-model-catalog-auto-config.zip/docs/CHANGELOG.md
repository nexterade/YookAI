# YookAI v0.4.0 — Model Catalog & Auto Configuration

- Added collapsible model categories to reduce initial dropdown clutter.
- Added provider-declared output token limit metadata for safe model-specific max-token clamping.
- Guarded asynchronous provider model loading against stale responses after rapid provider changes.
- Updated `docs/CHECKPOINT.md` with `PLAN FIRST, ACTION LATER`, model catalog, and auto-config rules.

# YookAI v0.3.39 — Rich Model Selector

- Redesigned model picker with visual model tiles, display names, model IDs, type labels, capability badges, descriptions, and selected state.
- Added mobile-friendly responsive sizing and image model aliases for common Gemini image model IDs.
- Capability labels are curated guidance, not runtime guarantees.

## v0.3.39 — Image Model Badges
- Add curated special badges for selected OpenRouter image-generation models in the model dropdown.
- Keep model selection behavior unchanged; badges are descriptive labels and do not assert live endpoint capability.

## v0.3.39 — OpenRouter 402 clarity

- Sanitize upstream URLs and key-like identifiers from OpenRouter error details.
- Explain token-credit affordability errors in user-facing language and suggest reducing the model's Max tokens or reviewing API-key limits.
- Preserve provider details when available without assuming the account balance is empty.

## v0.3.36 — Placeholder rendering and provider error diagnostics

- Prevent unresolved internal code placeholder markers from appearing verbatim in rendered Markdown; show a clear fallback when the associated block is unavailable.
- Preserve structured OpenRouter HTTP error details (short message/code fields) so HTTP 402 is not automatically described as an exhausted balance.
- Update application version metadata to v0.3.36.
- Keep the v0.3.35 header/model repositioning and sidebar interactions unchanged.

## v0.3.35 — Header brand and model selector repositioning

- Moved YookAI branding and its menu to the main header beside the model selector, matching the supplied mobile mockup.
- Removed the duplicate YookAI brand/menu from the sidebar top while preserving the sidebar collapse control and workspace menu.
- Kept the model selector accessible in the header and retained its provider/model dropdown behavior.

## v0.3.35 — Sidebar touch menus and settings consolidation

- Added a working YookAI brand/version menu with About and Settings actions.
- Added a working Local workspace menu with New chat and Export current chat actions.
- Added 44px minimum touch targets, menu ARIA state, outside-click dismissal, Escape dismissal, and arrow-key navigation.
- Consolidated Settings access in the brand dropdown and removed duplicate Settings entries from the sidebar navigation and workspace menu.
- Sidebar open/close behavior intentionally unchanged.

## v0.3.33 — Provider sync, session model dropdown, and mobile settings

- Align active provider/model across Settings, session profiles, header state, and outgoing chat requests.
- Replace the session model profile text field with a provider-aware model dropdown.
- Keep a single general Settings entry point in the sidebar; remove the duplicate header Settings button.
- Improve provider error messaging for payment/credit, authorization, and rate-limit failures.
- Audit existing CLI model catalog selection and preserve it across supported providers.

## v0.3.32 — CLI model catalog selection

- Replaced CLI manual model-ID entry with a numbered provider model catalog for OpenRouter, OpenAI, Anthropic, Google Gemini, and Ollama.
- Added Auto and Keep current selections; unavailable catalogs retain a compatible current/default model.
- Limits displayed catalog to the first 50 models for terminal usability.

## v0.3.32
- Replace the Settings default-model text field with a provider-aware dropdown populated from the provider model catalog.
- Preserve a previously saved model if it is not present in the latest catalog, and show a helpful message when model loading fails.
- Keep the model selection easy to refresh by reopening Settings after provider credentials are configured.

## v0.3.30
- Refresh the Nebula theme with a richer navy, blue, violet, and cyan palette across light and dark modes.
- Improve visual distinction for selected navigation, model controls, composer focus, and primary actions.
- Preserve provider-specific model selection behavior in the Web UI and CLI.
- Align current application, CLI, example-config, and documentation version identifiers to 0.3.30.

## v0.3.28
- Add shared TTY-aware terminal screen clearing for startup configuration and Semut menus, with clean redraw on navigation.
- Preserve operation results until the user returns; avoid ANSI control sequences in redirected or dumb-terminal output.
- Document terminal scrollback limitations and navigation behavior.
- Improve Tree Printer static analysis with package-relative imports, `from package import submodule`, and literal `importlib.import_module()` / `__import__()` detection.
- Add scan warnings for Python parse/read failures and explicit orphan review metadata distinguishing possible Python orphans from low-confidence unreferenced assets.
- Preserve legacy traversed/orphan/ignored arrays; document that orphan status is a review hint, never a safe-to-delete verdict.
- Align current runtime version identifiers and refresh the README for the 0.3.28 source release.
- Require `server.api_key` when binding the HTTP server to a non-loopback address; add bind-security regression tests and CI workflow.

## v0.3.27
- Keep the adaptive progress bar in terminal history after completion; successful determinate tasks finish at 100%, while failed tasks retain their last measured percentage; elapsed time remains in the non-TTY summary.
- Verify shared-storage write access with a temporary create/delete probe and report the resolved mounted path rather than inferring from directory names.
- Make `.yookai Manager` and Miscellaneous panels adapt to narrow Termux widths and account for wide Unicode glyphs when padding rows.
- Refresh README and Semut integration notes for storage status and retained progress history.

## v0.3.26
- Audit progress feedback across all Miscellaneous tools.
- Add adaptive one-line progress to Ghost Grep, ColorNote parsing/exports, and Sync Remote file operations; use a compact live spinner for Tree Printer's unknown-length filesystem walk.
- Preserve the shared progress renderer, narrow-terminal sizing, and concise non-TTY summary behavior.
- Document which operations show determinate progress bars versus indeterminate scan spinners.

## v0.3.22
- Apply a consistent, TTY-aware color palette to the storage manager, file browser, and miscellaneous tools menu.
- Use cyan for navigation and panels, green for regular items/success, yellow for caution, red for destructive actions/errors, and dim text for secondary details.
- Respect `NO_COLOR` and dumb/non-interactive terminals to preserve plain output and alignment.

## v0.3.21
- Polish `.yookai Manager` with a compact responsive panel, per-area storage bars, percentages, and clearer action/status labels.
- Improve file browser readability with a responsive path header, aligned type/size columns, wrapped names, and clearer navigation hints.
- Make the Miscellaneous utilities menu adapt to narrow Termux terminal widths and wrap longer descriptions.
- Keep existing manager safety checks and action behavior intact.

## v0.3.20
- Fix `.yookai Manager` numbered category navigation; selecting a displayed area number opens that area directly.
- Improve browser edit flow: accept a displayed file number or a relative path/name from the current directory.
- Clarify invalid-path and symlink handling, and guard directory traversal within the `.yookai` root.
- Update storage manager documentation and add navigation/edit regression tests.

## v0.3.19
- Add a Miscellaneous file/folder CLI category with Tree Printer, Ghost Grep, File Hasher, Backup Rotator, Sync Helper, Sync Remote (rclone copy), and ColorNote SQLite exporter.
- Keep destructive/sync operations confirmation-gated; remote operation uses non-deleting `rclone copy`.
- Document utility scope and add unit tests for hashing, tree/orphan scan, grep, backup rotation, sync diff/copy, and SQLite export.

## v0.3.18
- Add an interactive `.yookai` storage manager to the startup CLI for storage overview, safe browse/preview/edit, cache cleanup, selective data reset, and ZIP backup.
- Require explicit confirmation for destructive operations, preserve backups, and avoid following symlinks or exposing credential values in summaries.
- Add a standalone entry point via `python -m tools.manager` from the YookAI project directory.

## v0.3.17
- Upgrade Thinking disclosure with explicit live stages: waiting, receiving model-provided Thinking data, generating answer, completed, stopped, and failed.
- Keep elapsed duration accurate at completion and expose status changes to assistive technology.
- Preserve the distinction between provider-supplied reasoning data and application-generated progress labels; never fabricate hidden reasoning.
- Respect reduced-motion preferences for the Thinking indicator.

## v0.3.16
- Update Gemini's default/fallback model suggestion to `gemini-3.8-flash`, matching the model named in the observed upstream deprecation message.
- Gemini Auto selection now prioritizes current catalog candidates, including `gemini-3.8-flash`, over the deprecated `gemini-2.5-flash` default.
- Expand Gemini setup and troubleshooting documentation: model availability is project-dependent, refresh catalog after 404, and distinguish host reachability from API/model validation.

## v0.3.15
- Expose Gemini upstream error status and message from Google JSON responses, while redacting API keys.
- Include the upstream endpoint path (without query parameters) to help diagnose incorrect request routing.

## v0.3.14
- Polished network-test output into readable status, timing, URL, and explanation lines.
- Aligned the CLI Network test menu entry with other numbered options.

## v0.3.13
- Improve CLI network test labels: HTTP 404 is shown as a reachable host with a missing route, not generic OK.
- Separate DNS timing from total response latency and distinguish auth-required, rate-limit, redirect, timeout, TLS, connection, and server errors.
- Clarify that an unauthenticated connectivity probe does not validate API credentials or model availability.

## v0.3.12
- Add CLI option 8 to test configured and standard provider Base URLs from the device running YookAI.
- Report DNS resolution, HTTP status, reachability, and response latency without sending API credentials.
- Treat HTTP 4xx responses as network-reachable (not as proof that the API/model is valid).

## v0.3.11
- Show supported Gemini REST Base URL options in the CLI, including official v1beta and custom Gemini-compatible gateways.
- Preserve the current Gemini Base URL unless a different option is selected.

## v0.3.10
- Keep the mobile sidebar drawer closed on initial load and after server restart, including when the legacy sidebar_default setting is open.
- Preserve explicit sidebar toggle behavior and desktop collapse preference.

## v0.3.8
- Open Start Page on fresh browser visits and after YookAI server restarts instead of auto-opening the most recent chat.
- Preserve the active conversation across a browser refresh in the same tab and same server instance.
- Keep previous conversations in the sidebar for explicit user-selected resume; New Chat clears the tab active-session pointer only.

## v0.3.7
- Fixed Ollama API CLI setup: default server URL is shown and persisted even when left unchanged.
- Ollama model selection now loads models from the configured server, with manual fallback when unreachable.
- Switching providers preserves each provider model separately and initializes Ollama to `llama3.2` instead of reusing a cloud model.
- Clarified Ollama API status and removed duplicate full guide from the credentials screen.

## v0.3.6
- Clarified Ollama as a remote/self-hosted HTTP API provider rather than implying native offline support on Android/Termux.
- Updated CLI and web labels/setup guidance to configure a reachable Ollama server URL.

## v0.3.5
- Label providers as free-tier, local-free, or paid in the CLI provider menu.
- Put free-tier and local options first; clarify that OpenRouter and Gemini free access has model/usage limits and may include paid choices.

## v0.3.4
- Added provider-specific setup guides in the CLI, including official API-key dashboard links, model selection guidance, base URLs, and Ollama local setup notes.

# Changelog

## v0.3.3
- Replace the static CLI benchmark glyph with a live threaded spinner in interactive terminals.
- Keep benchmark/network work outside the animation thread and cleanly stop the spinner on success or error.
- Print a non-animated status line when output is not a terminal.


## v0.3.2
- Improve CLI startup menu with ANSI color styling and clearer section labels; gracefully degrades when color is unavailable.
- Apply CLI-configured browser theme when the saved CLI theme changes.
- Refresh the browser's selected model when the configured CLI default model changes.
- Ignore SSE comments and metadata lines instead of attempting to parse them as JSON.


## 0.3.0-rc1
- Added local tool engine and registry.
- Added safe calculator and workspace-scoped filesystem tools.
- Added opt-in shell execution with command allowlist, workspace confinement, timeout, and one-time confirmation.
- Added `/api/tools` and `/api/tools/execute`.
- Added Tools UI and security regression tests.

## 0.3.0-beta1

- Added smart latency/capability-aware model/provider routing.
- Added pre-token provider/model fallback.
- Added 60-second in-process model catalog cache.
- Added benchmark result caching for routing.
- Added session schema v2 fields for model configuration and routing metadata.
- Promoted bounded ZIP/document processing to the beta baseline.

## 0.2.4

- Fixed retry/repeat to target the clicked user turn and preserve its attachments.
- Fixed upload UI so 100% means server-confirmed completion; the spinner no longer remains at 100%.
- Added direct OpenAI, Anthropic, Google Gemini, and local Ollama provider adapters.
- Added provider switching in the model selector.
- Added per-provider/model session profiles for temperature, top-p, max tokens, reasoning effort, and system prompt.
- Snapshotted model configuration into each conversation session.
- Fixed stop/cancel routing so it targets the active provider.
- Expanded startup configuration to cover all supported providers.

## 0.2.3

- Added interactive pre-listen configuration menu for `python3 server.py`.
- Added `--no-configure` and `--configure` startup flags.
- Added live TTFT benchmarking for free OpenRouter models with six-hour cache.
- Migrated the legacy DeepSeek R1 hard-coded default to latency-based selection.
- Added real attachment upload progress, spinner, percentage and progress bar.
- Prevented sending while attachment uploads are still active.

## 0.2.2

- Persist new chat sessions before model streaming so History is immediately populated.
- Added bounded ZIP attachment extraction for text/document members.
- Added ZIP file picker support.
- Reduced avoidable SSE buffering with `iter_lines(chunk_size=1)`.
- Added OpenRouter stream timing logs for connect/first-event/total latency.
- Advertise `text/event-stream` to the upstream provider.
- Added regression tests for ZIP processing, History persistence, and streaming latency.

## 0.2.1

- Fixed SSE handler closing the HTTP-owned `wfile`, eliminating post-stream `ValueError: I/O operation on closed file`.
- Added immediate animated thinking spinner/timer.
- Forced UTF-8 provider decoding and added conservative mojibake repair.
- Replaced UI Unicode glyph icons with inline SVG controls.
- Fixed mobile sidebar backdrop selector.

# Changelog

## 0.2.0
- Local document extraction for PDF, DOCX, XLSX/XLSM and text formats.
- Deterministic local semantic memory retrieval and memory manager UI.
- Session export/import API and conversation search.
- Attachment lifecycle listing, deletion and orphan cleanup.
- Provider model capability metadata and usage/cost accounting.
- ChatGPT-inspired responsive visual system and composer/sidebar redesign.
- Drag-and-drop attachments, file previews and expanded statistics.

# Changelog

## [0.1.0] - 2026-10-02

### Added

### Fixed

- Settings changes now invalidate stale provider instances and credentials.
- Initial frontend boot no longer fails completely when the model endpoint is unavailable; sessions and Settings remain usable.
- Chat cancellation/new-chat races are guarded so an old stream cannot mutate a newer conversation.
- Session titles are derived from the first user message when still using `New Chat`.
- Concurrent session creation and writes use safer synchronization/atomic replacement.
- Configuration writes use atomic replacement.
- Configuration responses mask credential-like fields beyond provider API keys.
- Default server binding is now loopback-only and wildcard CORS was removed.
- Added baseline HTTP integration tests and expanded the suite to 81 tests.

- Standalone multi-model AI chat client.
- Provider abstraction (`BaseProvider`).
- OpenRouter provider with streaming, stop, model listing, caching, and upstream error mapping.
- Session manager under `~/.yookai/sessions/`.
- Config loader under `~/.yookai/config/`.
- HTTP server using `http.server` and `ThreadingHTTPServer`.
- SSE streamer and normalized reasoning/content/done/error events.
- 10 API endpoint groups for providers, chat, sessions, and config.
- Vanilla HTML/CSS/JS frontend with Jinja2 inheritance.
- Model selector with search, grouping, keyboard navigation, cache, and persistence.
- Thinking block with auto-expand, timer, Markdown rendering, and auto-collapse.
- Dark/light theme and responsive mobile layout.
- Offline-first Markdown renderer with XSS-safe HTML/link handling.
- Accessibility, reduced-motion, loading, toast, error, and keyboard-interaction polish.
- 83 automated tests.

### Security

- API keys are masked by `GET /api/config`.
- Masked API keys submitted by the UI do not overwrite the real credential.
- Markdown output escapes raw HTML and restricts generated links to HTTPS URLs.
- Runtime paths are canonicalized through `core/paths.py`.

### Documentation

- README.md
- docs/ARCHITECTURE.md
- docs/PROVIDERS.md
- docs/SESSIONS.md
- docs/ROADMAP.md
- docs/CONTRIBUTING.md
- docs/CHANGELOG.md

## [0.5.0] - 2026-10-02

### Added

- Functional model selector and reasoning/thinking block from PR VIII–IX.

## [0.4.0] - 2026-10-02

### Added

- Jinja2 frontend with shared base template.
- Responsive HTML/CSS interface.
- Vanilla JavaScript API client, SSE chat flow, session UI, theme handling, and Markdown renderer.

## [0.3.0] - 2026-10-02

### Added

- SSE formatting and streaming helpers.
- Threaded HTTP transport and API routes.

## [0.2.0] - 2026-10-02

### Added

- Provider abstraction and OpenRouter provider.
- Persistent session manager.

## [0.1.0-pre] - 2026-10-02

### Added

- Initial project skeleton, configuration, paths, and logger.


## Audit/refactor
- Fixed sidebar close/collapse behavior across desktop and compact layouts.
- Prevented session switching from racing with an active stream.
- Persisted edit/retry truncations before resending.
- Added local memory, attachment upload, conversation statistics, and actual provider usage capture.
- Fixed clipboard fallback and Markdown inline-code formatting interactions.
- Added regression and integration coverage.

## v0.3.0-alpha1

- Introduced the incremental v0.3 domain architecture without breaking the v0.2.4 API surface.
- Added domain facades for chat, sessions, attachments, memory and documents.
- Added normalized model descriptors and provider/model-scoped profile helpers.
- Added provider health primitives for future latency-aware routing and fallback.
- Added a local tool registry foundation with confirmation metadata.
- Added `tools/doctor.py` for local runtime diagnostics.
- Added dedicated `static/`, `runtime/`, domain package and test subtrees.

## v0.3.0-alpha2
- Added Provider Registry 2.0 with provider metadata and local/remote classification.
- Added live normalized multi-provider model catalog and capability inference.
- Added provider health probing based on model discovery latency.
- Added provider-native latency benchmark orchestration and best-result selection.
- Added API endpoints for provider specs, live model catalog, health, and benchmarks.

## 0.3.0-rc1
- Added local tool engine and tool registry execution API.
- Added safe calculator and workspace-scoped filesystem tools.
- Added opt-in shell tool with confirmation and command sandbox.
- Added tool security regression tests.

## 0.3.0-final

- Added bounded agent-loop orchestration primitives with approval delegation.
- Added project workspace storage and confined project file operations.
- Added deterministic context budgeting and extractive compaction helpers.
- Added persistent task ledger and disabled-by-default interval schedule metadata.
- Added MCP JSON-RPC protocol helpers and bounded public-HTTPS fetch utility.
- Updated release metadata, documentation, and service-level tests.
- Provider-native tool calling, search/citation adapters, MCP process transport, and managed background workers remain explicit integration work; see `V0.3.0_FINAL.md`.


## v0.3.0 final-fix-006
- Show a clear, non-fabricated note in the Thinking disclosure when a model does not provide reasoning data.
- Allow any late reasoning chunks to replace the unavailable-state note.
- Keep Thinking live through content chunks and finalize it on terminal completion/stream close.


## v0.3.23
- Integrate audited Semut implementations for the seven file/folder utilities in Miscellaneous.
- Namespace Semut core/UI/tool modules to avoid import collisions with YookAI.
- Keep Semut user vault and local state out of the YookAI release bundle.
- Update documentation.
