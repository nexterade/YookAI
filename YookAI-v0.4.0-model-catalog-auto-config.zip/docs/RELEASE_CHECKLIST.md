# Release checklist

Use this checklist before publishing a YookAI release. A passing test suite is necessary but does not replace licensing, security, installation, or manual UI review.

## Source and licensing

- [ ] Confirm the applicable license and redistribution terms for the Semut snapshot (`semut_suite/`); project ownership/maintainership alone does not document license terms for users.
- [ ] Add or preserve Semut attribution and all applicable third-party license notices.
- [ ] Confirm the archive contains no credentials, local settings, session data, memory, private keys, or generated user data.
- [ ] Review `.gitignore` and inspect the exact release archive before publishing.

## Version and documentation

- [ ] Align the version in `server.py`, `config.example.json`, HTTP server identification, README badge, and release notes.
- [ ] Update installation instructions, supported Python versions, provider setup, and known limitations.
- [ ] Replace all repository-specific placeholders and add current screenshots where useful.
- [ ] Describe experimental, partial, and opt-in features accurately.
- [ ] Record breaking changes, migration notes, and known issues in `docs/CHANGELOG.md`.

## Security and privacy

- [ ] Verify the default server binds to loopback.
- [ ] If non-loopback binding is supported, configure `server.api_key` and test missing, invalid, and valid credentials using a custom API client. The built-in browser UI currently does not attach this key; keep the browser UI on loopback.
- [ ] Review shell/tool permissions, workspace confinement, upload validation, path handling, and research URL fetching.
- [ ] Confirm logs and API responses do not expose provider keys or private runtime data.
- [ ] Document that the built-in HTTP server is not a hardened multi-user production gateway.

## Build and verification

- [ ] Create a clean virtual environment and install from the release source archive.
- [ ] Run `python -m compileall -q .`.
- [ ] Run `node --check` for `templates/app.js`, `templates/api.js`, and `templates/markdown.js` when Node.js is available.
- [ ] Run `python -m pytest -q` and record the exact result and environment.
- [ ] Test a fresh first launch, provider configuration, chat streaming, session persistence, attachments, and shutdown.
- [ ] Manually inspect the UI on a desktop browser and a narrow/mobile or Termux environment where supported.
- [ ] Review CI results for every supported Python version.

## GitHub publication

- [ ] Review the final diff and generated archive.
- [ ] Publish release notes with installation steps, compatibility, limitations, and security guidance.
- [ ] Use a pre-release tag when important compatibility or operational checks remain outstanding.
